from argparse import ArgumentParser
from pathlib import Path
import logging
import sys

from PySide6.QtCore import QTimer
from PySide6.QtGui import QGuiApplication

from universal_gui.contracts import Request
from universal_gui.runtime import GuiRuntime


def main() -> int:
    parser = ArgumentParser(description="Universal GUI framework showcase")
    parser.add_argument("--themes-dir", action="append", type=Path, default=[])
    parser.add_argument("--quit-after", type=int, default=0)
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--preview-scene", type=Path)
    parser.add_argument("--theme")
    arguments = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    application = QGuiApplication(sys.argv[:1])
    application.setApplicationName("Universal GUI Showcase")
    application.setOrganizationName("WorkingGui")
    example_themes = Path(__file__).resolve().parents[2] / "themes"
    theme_directories = tuple(dict.fromkeys(path.resolve() for path in [*arguments.themes_dir, *sorted(example_themes.glob("*/packs"))]))
    runtime = GuiRuntime(application, theme_directories)
    try:
        if arguments.theme:
            runtime.router.request(Request("themes", "select", arguments.theme))
        if arguments.preview or arguments.preview_scene is not None:
            runtime.load_preview(arguments.preview_scene)
        else:
            runtime.load_showcase()
        if arguments.quit_after > 0:
            QTimer.singleShot(arguments.quit_after, application.quit)
        return application.exec()
    finally:
        runtime.close()


if __name__ == "__main__":
    raise SystemExit(main())
