from dataclasses import is_dataclass
from pathlib import Path
from typing import Callable
import sys

from PySide6.QtGui import QGuiApplication

from universal_gui.contracts import Event, LocaleCatalog, Navigation, PageDefinition, Request, SettingChange, WindowDefinition
from universal_gui.qt.application_facade import ApplicationFacade, EventBinding
from universal_gui.runtime import GuiRuntime
from universal_gui.qt.rendering import configure_rendering


class GuiApplication:
    def __init__(self, name: str, theme_directories: tuple[Path, ...] = (), settings: dict[str, object] | None = None, *, hardware_acceleration: bool = True) -> None:
        self._hardware_acceleration = hardware_acceleration
        self._name = name
        self._theme_directories = theme_directories
        self._settings = tuple(SettingChange(key, value) for key, value in (settings or {}).items())
        self._windows: list[WindowDefinition] = []
        self._pages: list[PageDefinition] = []
        self._bindings: list[EventBinding] = []
        self._catalogs: list[LocaleCatalog] = []
        self._normal_setup: Callable[[GuiRuntime], None] | None = None
        self._preview_setup: Callable[[GuiRuntime], None] | None = None
        self.runtime: GuiRuntime | None = None
        self.gui: ApplicationFacade | None = None
        self._application: QGuiApplication | None = None

    def window(self, key: str, scene: Path | str) -> None:
        self._windows.append(WindowDefinition(key, str(Path(scene).resolve())))

    def page(self, key: str, scene: Path | str) -> None:
        self._pages.append(PageDefinition(key, str(Path(scene).resolve())))

    def translations(self, locale: str, entries: dict[str, str]) -> None:
        self._catalogs.append(LocaleCatalog(locale, tuple(entries.items())))

    def on(self, topic: str, callback: Callable[[Event], None], preview_callback: Callable[[Event], None] | None = None, payload_type: type | None = None) -> None:
        if any(binding.topic == topic for binding in self._bindings):
            raise ValueError(f"Event already declared: {topic}")
        if payload_type is not None and (not is_dataclass(payload_type) or not payload_type.__dataclass_params__.frozen):
            raise TypeError("Event payload must be a frozen dataclass")
        self._bindings.append(EventBinding(topic, callback, preview_callback, payload_type))

    def setup(self, normal: Callable[[GuiRuntime], None] | None = None, preview: Callable[[GuiRuntime], None] | None = None) -> None:
        self._normal_setup = normal
        self._preview_setup = preview

    def start(self, preview: bool = False, application: QGuiApplication | None = None) -> GuiRuntime:
        if self.runtime is not None:
            raise RuntimeError("Application is already started")
        configure_rendering(self._hardware_acceleration)
        self._application = application or QGuiApplication.instance() or QGuiApplication(sys.argv[:1])
        self._application.setApplicationName(self._name)
        runtime = GuiRuntime(self._application, self._theme_directories, self._settings)
        self.runtime = runtime
        try:
            if preview:
                runtime.enable_preview()
            self.gui = ApplicationFacade(runtime.router, tuple(self._bindings), preview)
            runtime.engine.rootContext().setContextProperty("Gui", self.gui)
            for catalog in self._catalogs:
                runtime.router.request(Request("localization", "register", catalog))
            for page in self._pages:
                runtime.router.request(Request("pages", "register", page))
            for window in self._windows:
                runtime.router.request(Request("windows", "register", window))
            configure = self._preview_setup if preview else self._normal_setup
            if configure is not None:
                configure(runtime)
            return runtime
        except Exception:
            self.close()
            raise

    def open_window(self, key: str) -> None:
        self.runtime.router.request(Request("windows", "open", key))

    def close_window(self, key: str) -> None:
        self.runtime.router.request(Request("windows", "close", key))

    def navigate(self, window_key: str, page_key: str) -> None:
        self.runtime.router.request(Request("pages", "navigate", Navigation(window_key, page_key)))

    def run(self, preview: bool | None = None) -> int:
        if self.runtime is None:
            self.start(bool(preview))
        elif preview is not None and preview != self.gui.previewMode:
            raise ValueError("Mode cannot change after start")
        try:
            return self._application.exec()
        finally:
            self.close()

    def close(self) -> None:
        if self.runtime is None:
            return
        if self.gui is not None:
            self.gui.close()
        try:
            self.runtime.close()
        finally:
            self.runtime = None
            self.gui = None
