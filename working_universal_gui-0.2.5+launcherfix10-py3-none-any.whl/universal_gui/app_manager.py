from universal_gui.contracts import Department, Request


class AppManager:
    def __init__(self) -> None:
        self._departments: dict[str, Department] = {}
        self._accepting = True

    def register(self, name: str, department: Department) -> None:
        if name in self._departments:
            raise ValueError(f"Department already registered: {name}")
        self._departments[name] = department

    def request(self, request: Request) -> object:
        if not self._accepting:
            raise RuntimeError("Runtime is closed")
        department = self._departments.get(request.department)
        if department is None:
            raise KeyError(f"Unknown department: {request.department}")
        return department.handle(request.action, request.payload)

    def close(self) -> None:
        if not self._accepting:
            return
        errors = []
        for department in reversed(tuple(self._departments.values())):
            try:
                department.close()
            except Exception as error:
                errors.append(error)
        self._accepting = False
        self._departments.clear()
        if errors:
            raise errors[0]
