from html import escape
from html.parser import HTMLParser
from urllib.parse import urlsplit


class SafeMarkup(HTMLParser):
    allowed_tags = frozenset(("p", "br", "strong", "b", "em", "i", "u", "s", "ul", "ol", "li", "pre", "code", "blockquote", "h1", "h2", "h3", "h4", "hr", "a", "table", "tr", "td", "th", "thead", "tbody"))
    blocked_tags = frozenset(("script", "style", "iframe", "object", "embed", "svg", "math"))

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self._blocked = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.blocked_tags:
            self._blocked += 1
            return
        if self._blocked or tag not in self.allowed_tags:
            return
        attributes = ""
        if tag == "a":
            href = dict(attrs).get("href", "")
            parsed = urlsplit(href)
            if parsed.scheme.lower() in ("https", "http", "mailto"):
                attributes = ' href="' + escape(href, quote=True) + '"'
        self.parts.append("<" + tag + attributes + ">")

    def handle_endtag(self, tag):
        if tag in self.blocked_tags:
            self._blocked = max(0, self._blocked - 1)
            return
        if not self._blocked and tag in self.allowed_tags:
            self.parts.append("</" + tag + ">")

    def handle_data(self, data):
        if not self._blocked:
            self.parts.append(escape(data))


def sanitize_html(source: str) -> str:
    sanitizer = SafeMarkup()
    sanitizer.feed(source)
    sanitizer.close()
    return "".join(sanitizer.parts)
