from PySide6.QtCore import QUrl

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Event, Navigation, PageDefinition, Request


class PageManager:
    def __init__(self, router: AppManager) -> None:
        self._router = router
        self._pages: dict[str, str] = {}
        self._active: dict[str, str] = {}

    def handle(self, action: str, payload: object) -> object:
        if action == "register" and isinstance(payload, PageDefinition):
            if payload.key in self._pages:
                raise ValueError(f"Duplicate page: {payload.key}")
            self._pages[payload.key] = payload.scene
            return None
        if action == "navigate" and isinstance(payload, Navigation):
            if payload.page_key not in self._pages:
                raise KeyError(f"Unknown page: {payload.page_key}")
            self._active[payload.window_key] = payload.page_key
            self._router.request(Request("events", "publish", Event("navigation.changed", payload)))
            return None
        if action == "source" and isinstance(payload, str):
            key = self._active.get(payload)
            return QUrl.fromLocalFile(self._pages[key]).toString() if key is not None else ""
        if action == "available":
            return tuple(self._pages)
        raise ValueError(f"Invalid page request: {action}")

    def close(self) -> None:
        self._active.clear()
        self._pages.clear()
