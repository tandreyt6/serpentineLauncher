from collections import deque
from datetime import datetime, timezone
import logging

from universal_gui.contracts import Diagnostic


class DiagnosticsManager:
    def __init__(self, capacity: int) -> None:
        self._entries: deque[str] = deque(maxlen=capacity)
        self._logger = logging.getLogger("universal_gui")

    def handle(self, action: str, payload: object) -> object:
        if action == "record" and isinstance(payload, Diagnostic):
            timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self._entries.append(f"{timestamp} {payload.level} {payload.code}: {payload.detail}")
            self._logger.log(getattr(logging, payload.level), "%s: %s", payload.code, payload.detail)
            return None
        if action == "snapshot":
            return tuple(self._entries)
        raise ValueError(f"Invalid diagnostics request: {action}")

    def close(self) -> None:
        pass
