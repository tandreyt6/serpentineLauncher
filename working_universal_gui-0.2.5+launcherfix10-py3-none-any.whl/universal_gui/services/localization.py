from pathlib import Path
import json

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Diagnostic, Event, LocaleCatalog, Request, TextQuery


class LocalizationManager:
    def __init__(self, router: AppManager, directory: Path) -> None:
        self._router = router
        self._catalogs = {path.stem: json.loads(path.read_text(encoding="utf-8")) for path in directory.glob("*.json")}
        self._locale = router.request(Request("settings", "get", "locale.initial"))
        if self._locale not in self._catalogs:
            raise ValueError(f"Unknown initial locale: {self._locale}")
        self._missing: set[tuple[str, str]] = set()

    def handle(self, action: str, payload: object) -> object:
        if action == "register" and isinstance(payload, LocaleCatalog):
            self._catalogs.setdefault(payload.locale, {}).update(dict(payload.entries))
            self._router.request(Request("events", "publish", Event("locale.changed", self._locale)))
            return None
        if action == "text" and isinstance(payload, TextQuery):
            value = self._catalogs[self._locale].get(payload.tag)
            if value is None:
                identity = (self._locale, payload.tag)
                if identity not in self._missing:
                    self._missing.add(identity)
                    self._router.request(Request("diagnostics", "record", Diagnostic("WARNING", "locale.missing", f"{self._locale}:{payload.tag}")))
                return payload.tag
            return value.format(**dict(payload.arguments))
        if action == "select" and isinstance(payload, str):
            if payload not in self._catalogs:
                raise ValueError(f"Unknown locale: {payload}")
            if payload != self._locale:
                self._locale = payload
                self._router.request(Request("events", "publish", Event("locale.changed", payload)))
            return None
        if action == "current":
            return self._locale
        if action == "available":
            return tuple(sorted(self._catalogs))
        raise ValueError(f"Invalid localization request: {action}")

    def close(self) -> None:
        self._missing.clear()
