from pathlib import Path
from math import isfinite
from collections import OrderedDict
import json

from PySide6.QtGui import QColor, QFontDatabase

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AppearanceOverride, AppearanceQuery, AssetQuery, Diagnostic, Event, NamedToken, Request, ResolvedAppearance, TokenPalette
from universal_gui.services.resources import PackMount


class ThemeManager:
    def __init__(self, router: AppManager, builtins: Path, external: tuple[Path, ...]) -> None:
        self._router = router
        self._themes: dict[str, dict] = {}
        self._selectors: dict[str, dict] = {}
        self._appearances = OrderedDict()
        self._effective_styles = OrderedDict()
        self._serializations = 0
        self._current = router.request(Request("settings", "get", "theme.initial"))
        self._generation = 0
        self._preview_enabled = False
        self._overrides: list[dict] = []
        self._preview_selectors = {}
        for path in sorted(builtins.glob("*.ugtheme")):
            self._mount(path)
        for directory in external:
            for path in sorted(directory.glob("*.ugtheme")):
                try:
                    self._mount(path)
                except (ValueError, KeyError, OSError) as error:
                    self._router.request(Request("diagnostics", "record", Diagnostic("WARNING", "theme.rejected", f"{path.name}: {error}")))
        if "office" not in self._themes:
            raise ValueError("Missing base office theme")
        if self._current not in self._themes:
            raise ValueError(f"Unknown initial theme: {self._current}")

    def _mount(self, path: Path, replace: bool = False) -> None:
        manifest = self._router.request(Request("resources", "probe", PackMount(path, replace)))
        self._validate_manifest(manifest)
        self._router.request(Request("resources", "mount", PackMount(path, replace)))
        pack_id = manifest["id"]
        self._themes[pack_id] = manifest
        self._selectors[pack_id] = self._index_rules(manifest.get("rules", []))

    def _index_rules(self, rules):
        selectors = {}
        for rule in rules:
            key = (rule.get("type"), rule.get("tag"), rule.get("state"))
            selectors.setdefault(key, []).append(rule)
        return selectors

    def _validate_manifest(self, manifest: dict) -> None:
        pack_id = manifest["id"]
        if manifest.get("format") != 1 or manifest.get("api") != "0.1":
            raise ValueError("Incompatible theme API")
        if pack_id == "office" and manifest.get("extends") is not None:
            raise ValueError("Base theme cannot inherit")
        if pack_id != "office" and manifest.get("extends") != "office":
            raise ValueError("Version 1 themes must inherit office")
        if not isinstance(manifest.get("tokens", {}), dict) or not isinstance(manifest.get("rules", []), list):
            raise ValueError("Invalid theme tokens or rules")
        self._validate_values(manifest.get("tokens", {}))
        for rule in manifest.get("rules", []):
            if not isinstance(rule, dict) or not (rule.get("type") or rule.get("tag")):
                raise ValueError("Rule needs a type or tag selector")
            if not isinstance(rule.get("values", {}), dict):
                raise ValueError("Invalid rule values")
            if "state" in rule and not isinstance(rule["state"], str):
                raise ValueError("State selector must be a string")
            self._validate_values(rule.get("values", {}))

    def _validate_values(self, values: dict) -> None:
        base = self._themes.get("office", {}).get("tokens", {})
        for key, value in values.items():
            if key in ("tabDragDetachDistance", "dockDropEdgeRatio") or key.startswith("workspace."):
                raise ValueError(f"Behavior belongs to application settings, not theme tokens: {key}")
            expected = base.get(key)
            if expected is None:
                continue
            if type(expected) in (int, float):
                if type(value) not in (int, float) or not isfinite(value) or value < 0:
                    raise ValueError(f"Invalid numeric token: {key}")
            elif not isinstance(value, type(expected)):
                raise ValueError(f"Invalid token type: {key}")
            if isinstance(expected, str) and expected.startswith("#") and not QColor(value).isValid():
                raise ValueError(f"Invalid color token: {key}")

    def _notify(self, invalidate_visuals: bool = False) -> None:
        self._appearances.clear()
        self._effective_styles.clear()
        self._preview_selectors = self._index_rules(self._overrides)
        self._router.request(Request("visuals", "invalidate_styles"))
        if invalidate_visuals:
            self._generation += 1
            self._router.request(Request("visuals", "clear"))
        self._router.request(Request("events", "publish", Event("theme.changed", self._current)))

    def _resolve(self, query):
        capacity = self._router.request(Request("settings", "get", "themes.appearance_entries"))
        cached = self._appearances.pop(query, None)
        if cached is not None:
            self._appearances[query] = cached
            while len(self._appearances) > capacity:
                self._appearances.popitem(last=False)
            return cached
        chain = [self._themes["office"]]
        if self._current != "office":
            chain.append(self._themes[self._current])
        indices = [self._selectors[theme["id"]] for theme in chain]
        if self._preview_enabled and self._overrides:
            chain.append({"id": self._current})
            indices.append(self._preview_selectors)
        matching = []
        visual = None
        for component_type, tag in ((query.component_type, None), (None, query.tag), (query.component_type, query.tag)):
            for state in (None, query.state_key):
                for theme, index in zip(chain, indices):
                    for rule in index.get((component_type, tag, state), ()):
                        if rule.get("values"):
                            matching.append(rule)
                        if "visual" in rule:
                            visual = AssetQuery(theme["id"], rule["visual"], self._generation)
        key = (tuple(id(rule) for rule in matching), query.density, query.typography_role)
        encoded = self._effective_styles.pop(key, None)
        if encoded is None:
            values = {}
            for theme in chain:
                values.update(theme.get("tokens", {}))
            for rule in matching:
                values.update(rule["values"])
            values.update(values.pop("densities", {}).get(query.density, {}))
            values.update(values.pop("typography", {}).get(query.typography_role, {}))
            if values.get("monospaceFont") == "monospace":
                values["monospaceFont"] = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont).family()
            encoded = json.dumps(values, sort_keys=True, separators=(",", ":"), allow_nan=False)
            self._serializations += 1
        self._effective_styles[key] = encoded
        while len(self._effective_styles) > capacity:
            self._effective_styles.popitem(last=False)
        resolved = ResolvedAppearance(encoded, visual)
        self._appearances[query] = resolved
        while len(self._appearances) > capacity:
            self._appearances.popitem(last=False)
        return resolved

    def handle(self, action: str, payload: object) -> object:
        if action == "asset_url" and isinstance(payload, AssetQuery):
            for pack in dict.fromkeys((self._current, payload.pack_id, "office")):
                if pack and self._router.request(Request("resources", "contains", AssetQuery(pack, payload.key))):
                    return self._router.request(Request("resources", "native_url", AssetQuery(pack, payload.key, self._generation)))
            raise KeyError(f"Theme asset not found: {payload.key}")
        if action == "palette" and isinstance(payload, AppearanceQuery):
            values, visual = self.handle("appearance", payload)
            return TokenPalette(tuple(NamedToken(key, value) for key, value in values.items() if type(value) in (str, int, float, bool)))
        if action == "resolve" and isinstance(payload, AppearanceQuery):
            return self._resolve(payload)
        if action == "appearance" and isinstance(payload, AppearanceQuery):
            resolved = self._resolve(payload)
            return json.loads(resolved.encoded), resolved.visual
        if action == "stats":
            return {"serializations": self._serializations, "queries": len(self._appearances), "effectiveStyles": len(self._effective_styles)}
        if action == "select" and isinstance(payload, str):
            if payload not in self._themes:
                raise ValueError(f"Unknown theme: {payload}")
            if self._current != payload:
                self._current = payload
                self._overrides.clear()
                self._notify()
            return None
        if action == "preview_enable":
            self._preview_enabled = True
            return None
        if action == "inspect":
            return json.loads(json.dumps(self._themes[self._current]))
        if action == "reload" and isinstance(payload, Path) and self._preview_enabled:
            self._mount(payload, replace=True)
            self._overrides.clear()
            self._notify(True)
            return None
        if action == "override" and isinstance(payload, AppearanceOverride) and self._preview_enabled:
            rule = {"values": dict(payload.values)}
            self._validate_values(rule["values"])
            if payload.component_type:
                rule["type"] = payload.component_type
            if payload.tag:
                rule["tag"] = payload.tag
            if not payload.component_type and not payload.tag:
                raise ValueError("Override needs a selector")
            selector = (payload.component_type, payload.tag)
            for existing in self._overrides:
                if (existing.get("type", ""), existing.get("tag", "")) == selector:
                    rule["values"] = existing["values"] | rule["values"]
            self._overrides = [existing for existing in self._overrides if (existing.get("type", ""), existing.get("tag", "")) != selector]
            self._overrides.append(rule)
            self._notify()
            return None
        if action == "reset_overrides" and self._preview_enabled:
            self._overrides.clear()
            self._notify()
            return None
        if action == "current":
            return self._current
        if action == "available":
            return tuple(self._themes)
        raise ValueError(f"Invalid theme request: {action}")

    def close(self) -> None:
        self._themes.clear()
        self._selectors.clear()
        self._appearances.clear()
        self._effective_styles.clear()
