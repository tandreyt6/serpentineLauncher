from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from hashlib import sha256
from tempfile import TemporaryDirectory
from threading import RLock
import json

from PySide6.QtCore import QUrl

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AssetData, AssetQuery, Event, Request, SettingChange
from universal_gui.pack.format import PackLimits, ThemePack
from universal_gui.services.events import Subscription


@dataclass(frozen=True)
class PackMount:
    path: Path
    replace: bool = False


class ResourceManager:
    def __init__(self, limits: PackLimits, cache_bytes: int, router: AppManager | None = None) -> None:
        self._limits = limits
        self._capacity = cache_bytes
        self._packs: dict[str, ThemePack] = {}
        self._cache: OrderedDict[tuple[str, str], bytes] = OrderedDict()
        self._cache_bytes = 0
        self._lock = RLock()
        self._router = router
        self._native_capacity = router.request(Request("settings", "get", "resources.native_cache_bytes")) if router is not None else 0
        self._native_entries = router.request(Request("settings", "get", "resources.native_cache_entries")) if router is not None else 0
        self._native_directory = None
        self._native_files = {}
        self._native_assets = {}
        self._native_bytes = 0
        self._subscription = router.request(Request("events", "subscribe", Subscription("settings.changed", self._on_settings))) if router is not None else None

    def _on_settings(self, event: Event) -> None:
        change = event.payload
        if isinstance(change, SettingChange) and change.key == "resources.cache_bytes":
            self.handle("cache_budget", change.value)

    def handle(self, action: str, payload: object) -> object:
        with self._lock:
            if action == "image_url" and isinstance(payload, str):
                source = QUrl(payload)
                if source.scheme() == "image" and source.host() == "pack":
                    pack_id, separator, key = source.path().lstrip("/").partition("/")
                    if not separator:
                        raise ValueError("Invalid pack image URL")
                    native = QUrl(self.handle("native_url", AssetQuery(pack_id, key)))
                    native.setQuery(source.query())
                    return native.toString()
                return payload
            if action == "probe" and isinstance(payload, PackMount):
                candidate = ThemePack(payload.path, self._limits)
                try:
                    manifest = json.loads(candidate.read("manifest.json"))
                    if not isinstance(manifest, dict):
                        raise ValueError("Manifest must be an object")
                    for key in candidate.keys():
                        if key.endswith(".qml"):
                            candidate.read(key)
                    for rule in manifest.get("rules", []):
                        if isinstance(rule, dict) and isinstance(rule.get("visual"), str):
                            candidate.read(rule["visual"])
                    return manifest
                finally:
                    candidate.close()
            if action == "mount" and isinstance(payload, PackMount):
                pack = ThemePack(payload.path, self._limits)
                try:
                    manifest = json.loads(pack.read("manifest.json"))
                    pack_id = manifest["id"]
                    if not isinstance(pack_id, str) or not pack_id or not all(character.isalnum() or character in "_-" for character in pack_id):
                        raise ValueError("Invalid pack ID")
                    if pack_id in self._packs and not payload.replace:
                        raise ValueError(f"Duplicate pack ID: {pack_id}")
                except Exception:
                    pack.close()
                    raise
                previous = self._packs.pop(pack_id, None)
                if previous is not None:
                    previous.close()
                    for key in tuple(self._cache):
                        if key[0] == pack_id:
                            self._cache_bytes -= len(self._cache.pop(key))
                self._packs[pack_id] = pack
                self._native_assets = {key: value for key, value in self._native_assets.items() if key[0] != pack_id}
                return manifest
            if action == "native_url" and isinstance(payload, AssetQuery):
                key = (payload.pack_id, payload.key)
                path = self._native_assets.get(key)
                if path is None:
                    content = self.handle("read", payload).content
                    suffix = Path(payload.key).suffix.lower()
                    if len(suffix) > 16 or not suffix[1:].isalnum():
                        suffix = ".asset"
                    digest = sha256(content).hexdigest() + suffix
                    path = self._native_files.get(digest)
                    if path is None:
                        if self._native_bytes + len(content) > self._native_capacity or len(self._native_files) >= self._native_entries:
                            raise ValueError("Native resource cache budget exceeded")
                        if self._native_directory is None:
                            self._native_directory = TemporaryDirectory(prefix="ugf-images-")
                        path = Path(self._native_directory.name) / digest
                        path.write_bytes(content)
                        self._native_files[digest] = path
                        self._native_bytes += len(content)
                    self._native_assets[key] = path
                url = QUrl.fromLocalFile(str(path))
                url.setQuery(f"generation={payload.generation}")
                return url.toString()
            if action == "read" and isinstance(payload, AssetQuery):
                key = (payload.pack_id, payload.key)
                content = self._cache.pop(key, None)
                if content is None:
                    content = self._packs[payload.pack_id].read(payload.key)
                else:
                    self._cache_bytes -= len(content)
                if len(content) <= self._capacity:
                    self._cache[key] = content
                    self._cache_bytes += len(content)
                    while self._cache_bytes > self._capacity:
                        _, removed = self._cache.popitem(last=False)
                        self._cache_bytes -= len(removed)
                return AssetData(content, f"qrc:/ugpack/{payload.pack_id}/{payload.key}")
            if action == "contains" and isinstance(payload, AssetQuery):
                pack = self._packs.get(payload.pack_id)
                return pack is not None and pack.contains(payload.key)
            if action == "cache_budget" and type(payload) is int and payload >= 0:
                self._capacity = payload
                while self._cache_bytes > self._capacity:
                    _, removed = self._cache.popitem(last=False)
                    self._cache_bytes -= len(removed)
                return None
            if action == "keys" and isinstance(payload, str):
                return self._packs[payload].keys()
            if action == "clear_cache":
                self._cache.clear()
                self._cache_bytes = 0
                return None
            if action == "unmount" and isinstance(payload, str):
                pack = self._packs.pop(payload, None)
                if pack is not None:
                    pack.close()
                for key in tuple(self._cache):
                    if key[0] == payload:
                        self._cache_bytes -= len(self._cache.pop(key))
                self._native_assets = {key: value for key, value in self._native_assets.items() if key[0] != payload}
                return None
            if action == "stats":
                return {"packs": len(self._packs), "cacheBytes": self._cache_bytes, "cacheEntries": len(self._cache), "bytesRead": sum(pack.bytes_read for pack in self._packs.values()), "nativeBytes": self._native_bytes, "nativeEntries": len(self._native_files), "nativeCapacity": self._native_capacity, "nativeEntryCapacity": self._native_entries}
        raise ValueError(f"Invalid resource request: {action}")

    def close(self) -> None:
        if self._subscription is not None:
            self._router.request(Request("events", "unsubscribe", self._subscription))
            self._subscription = None
        with self._lock:
            self._cache.clear()
            self._cache_bytes = 0
            for pack in self._packs.values():
                pack.close()
            self._packs.clear()
            self._native_assets.clear()
            self._native_files.clear()
            self._native_bytes = 0
            if self._native_directory is not None:
                self._native_directory.cleanup()
                self._native_directory = None
