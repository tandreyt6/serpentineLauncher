from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable
from time import perf_counter
from uuid import uuid4
from weakref import WeakMethod

from PySide6.QtCore import QObject, QTimer, Qt, Signal, Slot

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Diagnostic, Event, Request


@dataclass(frozen=True)
class Subscription:
    topic: str
    callback: Callable[[Event], None]


class EventManager(QObject):
    incoming = Signal(object)

    def __init__(self, router: AppManager) -> None:
        super().__init__()
        self._router = router
        self._listeners: dict[str, dict[str, WeakMethod]] = defaultdict(dict)
        self._topics: dict[str, str] = {}
        self._pending = deque()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._drain)
        self._closed = False
        self._draining = False
        self.incoming.connect(self._deliver, Qt.ConnectionType.QueuedConnection)

    def handle(self, action: str, payload: object) -> object:
        if action == "subscribe" and isinstance(payload, Subscription):
            token = uuid4().hex
            self._listeners[payload.topic][token] = WeakMethod(payload.callback)
            self._topics[token] = payload.topic
            return token
        if action == "unsubscribe" and isinstance(payload, str):
            topic = self._topics.pop(payload, None)
            if topic is not None:
                self._listeners[topic].pop(payload, None)
                if not self._listeners[topic]:
                    self._listeners.pop(topic)
            return None
        if action == "publish" and isinstance(payload, Event):
            if not self._closed:
                self.incoming.emit(payload)
            return None
        if action == "count":
            return len(self._topics)
        if action == "pending":
            return len(self._pending)
        raise ValueError(f"Invalid event request: {action}")

    @Slot(object)
    def _deliver(self, event: Event) -> None:
        if self._closed:
            return
        if event.topic in self._router.request(Request("settings", "get", "events.coalesced_topics")):
            self._pending = deque((queued, listeners) for queued, listeners in self._pending if queued.topic != event.topic)
        listeners = deque(self._listeners.get(event.topic, {}).items())
        if listeners:
            self._pending.append((event, listeners))
            if not self._timer.isActive():
                self._timer.start(0)

    @Slot()
    def _drain(self) -> None:
        if self._draining:
            return
        self._draining = True
        try:
            deadline = perf_counter() + self._router.request(Request("settings", "get", "events.delivery_budget_ms")) / 1000
            while self._pending and not self._closed:
                event, listeners = self._pending[0]
                token, weak_callback = listeners.popleft()
                if not listeners:
                    self._pending.popleft()
                if token in self._topics:
                    callback = weak_callback()
                    if callback is None:
                        self.handle("unsubscribe", token)
                    else:
                        try:
                            callback(event)
                        except Exception as error:
                            self._router.request(Request("diagnostics", "record", Diagnostic("ERROR", "event.handler_failed", f"{event.topic}: {type(error).__name__}")))
                if perf_counter() >= deadline:
                    break
        finally:
            self._draining = False
            if self._pending and not self._closed:
                self._timer.start(0)

    def close(self) -> None:
        self._closed = True
        self._timer.stop()
        self._pending.clear()
        self._listeners.clear()
        self._topics.clear()
