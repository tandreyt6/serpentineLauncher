from dataclasses import dataclass
from uuid import uuid4
from weakref import ref

from PySide6.QtCore import QObject, Slot

from universal_gui.app_manager import AppManager
from universal_gui.contracts import ComponentIdentity, Diagnostic, Request


@dataclass(frozen=True)
class Registration:
    owner: QObject
    component_type: str
    tag: str


class RegistrationLease(QObject):
    def __init__(self, registry: "RegistryManager", token: str) -> None:
        super().__init__()
        self._registry = ref(registry)
        self._token = token

    @Slot()
    def close(self) -> None:
        registry = self._registry()
        if registry is not None:
            registry.remove(self._token)


class RegistryManager:
    def __init__(self, router: AppManager) -> None:
        self._router = router
        self._records: dict[str, ComponentIdentity] = {}
        self._leases: dict[str, RegistrationLease] = {}
        self._owners: dict[int, tuple[ref, str]] = {}
        self._owner_ids: dict[str, int] = {}

    def handle(self, action: str, payload: object) -> object:
        if action == "register" and isinstance(payload, Registration):
            owner_id = id(payload.owner)
            existing = self._owners.get(owner_id)
            if existing is not None and existing[0]() is payload.owner:
                return existing[1]
            token = uuid4().hex
            identity = ComponentIdentity(payload.component_type, payload.tag, token)
            lease = RegistrationLease(self, token)
            payload.owner.destroyed.connect(lease.close)
            self._records[token] = identity
            self._leases[token] = lease
            self._owners[owner_id] = (ref(payload.owner), token)
            self._owner_ids[token] = owner_id
            self._router.request(Request("diagnostics", "record", Diagnostic("DEBUG", "component.registered", f"{identity.component_type} {identity.tag} {token}")))
            return token
        if action == "unregister" and isinstance(payload, str):
            self.remove(payload)
            return None
        if action == "snapshot":
            return tuple(self._records.values())
        raise ValueError(f"Invalid registry request: {action}")

    def remove(self, token: str) -> None:
        record = self._records.pop(token, None)
        if record is None:
            return
        owner_id = self._owner_ids.pop(token)
        self._owners.pop(owner_id, None)
        lease = self._leases.pop(token)
        lease.deleteLater()
        self._router.request(Request("diagnostics", "record", Diagnostic("DEBUG", "component.unregistered", token)))

    def close(self) -> None:
        for token in tuple(self._records):
            self.remove(token)
