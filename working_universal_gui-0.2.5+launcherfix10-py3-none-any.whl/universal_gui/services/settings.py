from pathlib import Path
from math import isfinite
import json

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Event, Request, SettingChange


class SettingsManager:
    def __init__(self, router: AppManager, defaults_path: Path, initial: tuple[SettingChange, ...] = ()) -> None:
        self._router = router
        self._values = json.loads(defaults_path.read_text(encoding="utf-8"))
        self._schema = json.loads(defaults_path.with_name("settings-schema.json").read_text(encoding="utf-8"))
        self._types = {key: type(value) for key, value in self._values.items()}
        for change in initial:
            self._validate(change)
            self._values[change.key] = change.value

    def _validate(self, change: SettingChange) -> None:
        expected = self._types[change.key]
        if type(change.value) is not expected:
            raise TypeError(f"Expected {expected.__name__} for {change.key}")
        if expected is float and not isfinite(change.value):
            raise ValueError(f"Non-finite setting: {change.key}")
        minimum = self._schema.get(change.key, {}).get("minimum")
        if minimum is not None and change.value < minimum:
            raise ValueError(f"Setting below minimum: {change.key}")
        maximum = self._schema.get(change.key, {}).get("maximum")
        if maximum is not None and change.value > maximum:
            raise ValueError(f"Setting above maximum: {change.key}")
        choices = self._schema.get(change.key, {}).get("choices")
        if choices is not None and change.value not in choices:
            raise ValueError(f"Invalid setting choice: {change.key}")

    def handle(self, action: str, payload: object) -> object:
        if action == "get" and isinstance(payload, str):
            return self._values[payload]
        if action == "set" and isinstance(payload, SettingChange):
            self._validate(payload)
            if self._values[payload.key] != payload.value:
                self._values[payload.key] = payload.value
                self._router.request(Request("events", "publish", Event("settings.changed", payload)))
            return None
        if action == "snapshot":
            return self._values.copy()
        raise ValueError(f"Invalid settings request: {action}")

    def close(self) -> None:
        pass
