from html import escape

from PySide6.QtCore import QObject, Property, QRunnable, QThreadPool, Qt, Signal, Slot
from PySide6.QtGui import QTextDocument

from universal_gui.text_markup import SafeMarkup, sanitize_html
from universal_gui.ui_contracts import PreparedDocument


def prepare_text(source: str, format: str) -> str:
    if format == "plain":
        return escape(source).replace("\n", "<br>")
    if format == "markdown":
        document = QTextDocument()
        document.setMarkdown(source)
        source = document.toHtml()
    elif format != "html":
        raise ValueError("Document format must be plain, markdown or html")
    return sanitize_html(source)


class PreparationSignals(QObject):
    completed = Signal(object)


class PreparationTask(QRunnable):
    def __init__(self, generation, source, format, signals):
        super().__init__()
        self.generation = generation
        self.source = source
        self.format = format
        self.signals = signals

    def run(self):
        try:
            text = prepare_text(self.source, self.format)
            result = PreparedDocument(self.generation, self.format, text)
        except (ValueError, RuntimeError, RecursionError) as error:
            result = PreparedDocument(self.generation, self.format, "", str(error))
        self.signals.completed.emit(result)


class DocumentAdapter(QObject):
    changed = Signal()
    preparedChanged = Signal()
    statusChanged = Signal()
    failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._source = ""
        self._format = "plain"
        self._prepared = ""
        self._generation = 0
        self._threshold = 0
        self._maximum = 0
        self._running = False
        self._busy = False
        self._pending = None
        self._task = None
        self._signals = PreparationSignals()
        self._signals.completed.connect(self._apply, Qt.ConnectionType.QueuedConnection)

    def _prepare(self):
        self._generation += 1
        request = (self._generation, self._source, self._format)
        if self._running:
            self._pending = request
            self._busy = True
            self.statusChanged.emit()
        else:
            self._start(*request)
        self.changed.emit()

    def _start(self, generation, source, format):
        if self._threshold > 0 and len(source) >= self._threshold:
            self._running = True
            self._busy = True
            self.statusChanged.emit()
            self._task = PreparationTask(generation, source, format, self._signals)
            QThreadPool.globalInstance().start(self._task)
        else:
            self._commit(PreparedDocument(generation, format, prepare_text(source, format)))

    @Slot(object)
    def _apply(self, result):
        if not isinstance(result, PreparedDocument):
            raise TypeError("Expected PreparedDocument")
        self._running = False
        self._task = None
        if self._pending is not None:
            request = self._pending
            self._pending = None
            self._start(*request)
        elif result.generation == self._generation:
            self._commit(result)

    def _commit(self, result):
        self._busy = False
        self.statusChanged.emit()
        if result.error:
            self.failed.emit(result.error)
            return
        self._prepared = result.text
        self.preparedChanged.emit()

    def set_source(self, value):
        if self._maximum > 0 and len(value) > self._maximum:
            raise ValueError("Document source exceeds configured capacity")
        if value != self._source:
            self._source = value
            self._prepare()

    def set_format(self, value):
        if value not in ("plain", "markdown", "html"):
            raise ValueError("Document format must be plain, markdown or html")
        if value != self._format:
            self._format = value
            self._prepare()

    def set_threshold(self, value):
        if value < 0:
            raise ValueError("Asynchronous threshold must not be negative")
        self._threshold = value
        self.statusChanged.emit()

    def set_maximum(self, value):
        if value < 0:
            raise ValueError("Document capacity must not be negative")
        self._maximum = value
        self.statusChanged.emit()

    source = Property(str, lambda self: self._source, set_source, notify=changed)
    format = Property(str, lambda self: self._format, set_format, notify=changed)
    prepared = Property(str, lambda self: self._prepared, notify=preparedChanged)
    busy = Property(bool, lambda self: self._busy, notify=statusChanged)
    asynchronousThreshold = Property(int, lambda self: self._threshold, set_threshold, notify=statusChanged)
    maximumCharacters = Property(int, lambda self: self._maximum, set_maximum, notify=statusChanged)
