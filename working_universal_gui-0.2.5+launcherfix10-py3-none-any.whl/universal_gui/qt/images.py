from collections import OrderedDict
from threading import RLock

from PySide6.QtCore import QBuffer, QByteArray, QIODevice, QSize, Qt
from PySide6.QtGui import QImage, QImageReader
from PySide6.QtQuick import QQuickImageProvider

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AssetQuery, Diagnostic, ImageCacheStatistics, Request


class PackImageProvider(QQuickImageProvider):
    def __init__(self, router: AppManager) -> None:
        super().__init__(QQuickImageProvider.ImageType.Image)
        self._router = router
        self._capacity = router.request(Request("settings", "get", "resources.image_cache_bytes"))
        self._cache = OrderedDict()
        self._bytes = 0
        self._lock = RLock()

    def statistics(self):
        with self._lock:
            return ImageCacheStatistics(len(self._cache), self._bytes, self._capacity)

    def requestImage(self, identifier: str, size: QSize, requested_size: QSize) -> QImage:
        try:
            cache_key = (identifier, requested_size.width(), requested_size.height())
            with self._lock:
                cached = self._cache.pop(cache_key, None)
                if cached is not None:
                    self._cache[cache_key] = cached
                    size.setWidth(cached.width())
                    size.setHeight(cached.height())
                    return QImage(cached)
            pack_id, key = identifier.partition("?")[0].split("/", 1)
            asset = self._router.request(Request("resources", "read", AssetQuery(pack_id, key)))
            buffer = QBuffer()
            buffer.setData(QByteArray(asset.content))
            buffer.open(QIODevice.OpenModeFlag.ReadOnly)
            reader = QImageReader(buffer)
            original = reader.size()
            if requested_size.width() > 0 and requested_size.height() > 0 and original.isValid():
                reader.setScaledSize(original.scaled(requested_size, Qt.AspectRatioMode.KeepAspectRatio))
            image = reader.read()
            if image.isNull():
                raise ValueError(reader.errorString())
            with self._lock:
                previous = self._cache.pop(cache_key, None)
                if previous is not None:
                    self._bytes -= previous.sizeInBytes()
                if image.sizeInBytes() <= self._capacity:
                    self._cache[cache_key] = QImage(image)
                    self._bytes += image.sizeInBytes()
                    while self._bytes > self._capacity:
                        key, removed = self._cache.popitem(last=False)
                        self._bytes -= removed.sizeInBytes()
            size.setWidth(image.width())
            size.setHeight(image.height())
            return image
        except (ValueError, KeyError, OSError) as error:
            self._router.request(Request("diagnostics", "record", Diagnostic("WARNING", "asset.image", str(error))))
            return QImage()
