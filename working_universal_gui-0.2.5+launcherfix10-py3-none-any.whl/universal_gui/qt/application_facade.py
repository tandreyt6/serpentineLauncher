from dataclasses import dataclass
from typing import Callable

from PySide6.QtCore import QObject, Property, Signal, Slot

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Diagnostic, Event, Navigation, Request
from universal_gui.services.events import Subscription
from universal_gui.qt.rendering import hardware_acceleration_enabled


@dataclass(frozen=True)
class EventBinding:
    topic: str
    callback: Callable[[Event], None]
    preview_callback: Callable[[Event], None] | None = None
    payload_type: type | None = None


class BoundEvent:
    def __init__(self, router: AppManager, definition: EventBinding, preview: bool) -> None:
        self._router = router
        self._definition = definition
        self._preview = preview

    def receive(self, event: Event) -> None:
        callback = self._definition.preview_callback if self._preview else self._definition.callback
        if callback is not None:
            callback(event)
        else:
            self._router.request(Request("diagnostics", "record", Diagnostic("INFO", "preview.intent", event.topic)))


class ApplicationFacade(QObject):
    navigationChanged = Signal()

    def __init__(self, router: AppManager, bindings: tuple[EventBinding, ...], preview: bool) -> None:
        super().__init__()
        self._router = router
        self._preview = preview
        self._definitions = {binding.topic: binding for binding in bindings}
        self._receivers = [BoundEvent(router, binding, preview) for binding in bindings]
        self._subscriptions = [router.request(Request("events", "subscribe", Subscription(binding.topic, receiver.receive))) for binding, receiver in zip(bindings, self._receivers)]
        self._subscriptions.append(router.request(Request("events", "subscribe", Subscription("navigation.changed", self._on_navigation))))
        self._revision = 0

    previewMode = Property(bool, lambda self: self._preview, constant=True)
    hardwareAcceleration = Property(bool, lambda self: hardware_acceleration_enabled(), constant=True)
    navigationRevision = Property(int, lambda self: self._revision, notify=navigationChanged)

    def _on_navigation(self, event: Event) -> None:
        self._revision += 1
        self.navigationChanged.emit()

    @Slot(str, str)
    def navigate(self, window_key: str, page_key: str) -> None:
        self._router.request(Request("pages", "navigate", Navigation(window_key, page_key)))

    @Slot(str, result=str)
    def pageSource(self, window_key: str) -> str:
        return self._router.request(Request("pages", "source", window_key))

    @Slot(str)
    def openWindow(self, key: str) -> None:
        self._router.request(Request("windows", "open", key))

    @Slot(str)
    def closeWindow(self, key: str) -> None:
        self._router.request(Request("windows", "close", key))

    @Slot(str)
    @Slot(str, "QVariantMap")
    def emitEvent(self, topic: str, values: dict | None = None) -> None:
        definition = self._definitions[topic]
        fields = values or {}
        if definition.payload_type is None:
            if fields:
                raise ValueError(f"Event needs a typed payload contract: {topic}")
            payload = None
        else:
            payload = definition.payload_type(**fields)
        self._router.request(Request("events", "publish", Event(topic, payload)))

    @Slot()
    def cycleTheme(self) -> None:
        themes = self._router.request(Request("themes", "available"))
        current = themes.index(self._router.request(Request("themes", "current")))
        self._router.request(Request("themes", "select", themes[(current + 1) % len(themes)]))

    @Slot()
    def cycleLocale(self) -> None:
        locales = self._router.request(Request("localization", "available"))
        current = locales.index(self._router.request(Request("localization", "current")))
        self._router.request(Request("localization", "select", locales[(current + 1) % len(locales)]))

    def close(self) -> None:
        for token in self._subscriptions:
            self._router.request(Request("events", "unsubscribe", token))
        self._subscriptions.clear()
        self._receivers.clear()
