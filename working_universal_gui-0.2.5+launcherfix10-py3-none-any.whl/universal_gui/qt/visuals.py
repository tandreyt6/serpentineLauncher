from collections import OrderedDict
from dataclasses import dataclass
from hashlib import sha256
from time import perf_counter
from types import MappingProxyType
from weakref import ref
import json

from PySide6.QtCore import QByteArray, QObject, Property, QTimer, QUrl, Signal, Slot
from PySide6.QtQml import QJSValue, QJSValueIterator, QQmlComponent, QQmlContext, QQmlEngine, QQmlProperty, qmlEngine
from PySide6.QtQuick import QQuickItem
from shiboken6 import delete, isValid

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AppearanceQuery, AssetQuery, Diagnostic, Event, Request, VisualFailure


@dataclass(frozen=True)
class VisualCreation:
    source: str
    state: QObject


@dataclass(frozen=True)
class VisualReuse:
    source: str
    item: QQuickItem


class VisualManager(QObject):
    def __init__(self, router: AppManager, engine: QQmlEngine) -> None:
        super().__init__()
        self._router = router
        self._engine = engine
        self._components: OrderedDict[tuple[str, str], QQmlComponent] = OrderedDict()
        self._states: OrderedDict[tuple[str, ...], QQmlComponent] = OrderedDict()
        self._styles = OrderedDict()
        self._sources = OrderedDict()
        self._pending = OrderedDict()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._drain)
        self._draining = False
        self._closed = False
        self._statistics = {"snapshots": 0, "created": 0, "reused": 0, "ticks": 0, "maximumTickMs": 0.0}
        self._freeze_style = engine.evaluate("""
(function(encoded) {
    function rejectWrite() {
        throw new TypeError("Paint style is read-only");
    }
    function freeze(value) {
        if (value === null || typeof value !== "object") return value;
        for (const key of Object.keys(value)) value[key] = freeze(value[key]);
        if (Array.isArray(value)) {
            Object.defineProperty(value, "toJSON", {value() {return Array.from(value)}});
        }
        Object.freeze(value);
        return Array.isArray(value)
            ? new Proxy(value, {set: rejectWrite, deleteProperty: rejectWrite, defineProperty: rejectWrite})
            : value;
    }
    return freeze(JSON.parse(encoded));
})
""")

    def _prepare_style(self, values):
        key = json.dumps(values, sort_keys=True, separators=(",", ":"), allow_nan=False)
        return self._prepare_encoded(key)[1]

    def _prepare_encoded(self, key):
        prepared = self._styles.pop(key, None)
        if prepared is None:
            style = self._freeze_style.call([QJSValue(key)])
            if style.isError():
                self._engine.catchError()
                raise ValueError("Paint style preparation failed: " + style.toString())
            prepared = (MappingProxyType(json.loads(key)), style)
            self._statistics["snapshots"] += 1
        self._styles[key] = prepared
        capacity = self._router.request(Request("settings", "get", "visuals.style_cache_entries"))
        while len(self._styles) > capacity:
            self._styles.popitem(last=False)
        return prepared

    def _source(self, source):
        cached = self._sources.pop(source, None)
        if cached is None:
            pack_id, key = source.partition("?")[0].split("/", 1)
            asset = self._router.request(Request("resources", "read", AssetQuery(pack_id, key)))
            cached = ((sha256(asset.content).hexdigest(), key), asset)
        self._sources[source] = cached
        capacity = self._router.request(Request("settings", "get", "visuals.cache_entries"))
        while len(self._sources) > capacity:
            self._sources.popitem(last=False)
        return cached

    @Slot()
    def _drain(self):
        if self._draining or self._closed:
            return
        self._draining = True
        started = perf_counter()
        budget = self._router.request(Request("settings", "get", "visuals.rebuild_budget_ms")) / 1000
        try:
            while self._pending and not self._closed:
                _, weak_host = self._pending.popitem(last=False)
                host = weak_host()
                if host is not None and isValid(host) and host.isVisible():
                    host._rebuild()
                if perf_counter() - started >= budget:
                    break
        finally:
            self._draining = False
            self._statistics["ticks"] += 1
            self._statistics["maximumTickMs"] = max(self._statistics["maximumTickMs"], (perf_counter() - started) * 1000)
            if self._pending and not self._closed:
                self._timer.start(0)

    def _create_state(self, request):
        fields = QJSValueIterator(self._engine.newQObject(request.state))
        names = []
        while fields.hasNext():
            fields.next()
            if fields.name() not in ("objectName", "style") and not fields.value().isCallable():
                names.append(fields.name())
        names = tuple(names)
        component = self._states.pop(names, None)
        if component is None:
            fields = "\n".join(f"readonly property var {name}: LiveState.{name}" for name in names)
            source = 'import QtQml\nQtObject {required property string packId; required property string generation; readonly property var style: LiveState.style; function assetUrl(key) {style; return AssetResolver.assetUrl(packId, key, generation)} function imageUrl(source) {style; generation; return AssetResolver.imageUrl(source.toString())}\n' + fields + '\n}'
            component = QQmlComponent(self._engine)
            component.setData(QByteArray(source.encode()), QUrl("qrc:/universal_gui/VisualState.qml"))
        self._states[names] = component
        capacity = self._router.request(Request("settings", "get", "visuals.cache_entries"))
        while len(self._states) > capacity:
            _, removed = self._states.popitem(last=False)
            removed.deleteLater()
        context = QQmlContext(self._engine.rootContext())
        context.setContextProperty("LiveState", request.state)
        context.setContextProperty("AssetResolver", self)
        state = component.createWithInitialProperties({"packId": request.source.split("/", 1)[0], "generation": request.source.partition("?")[2]}, context)
        if state is None:
            context.deleteLater()
            raise ValueError("\n".join(error.toString() for error in component.errors()))
        context.setParent(state)
        return state

    @Slot(str, str, str, result=str)
    def assetUrl(self, pack_id, key, generation):
        return self._router.request(Request("themes", "asset_url", AssetQuery(pack_id, key)))

    @Slot(str, result=str)
    def imageUrl(self, source):
        return self._router.request(Request("resources", "image_url", source))

    def handle(self, action: str, payload: object) -> object:
        if action == "style" and isinstance(payload, AppearanceQuery):
            resolved = self._router.request(Request("themes", "resolve", payload))
            return self._prepare_encoded(resolved.encoded)[1]
        if action == "appearance" and isinstance(payload, AppearanceQuery):
            resolved = self._router.request(Request("themes", "resolve", payload))
            values, style = self._prepare_encoded(resolved.encoded)
            return values, style, resolved.visual
        if action == "prepare_style" and isinstance(payload, dict):
            return self._prepare_style(payload)
        if action == "schedule" and isinstance(payload, VisualHost):
            if not self._closed:
                self._pending[id(payload)] = ref(payload)
                if not self._timer.isActive() and not self._draining:
                    self._timer.start(0)
            return None
        if action == "pending":
            return len(self._pending)
        if action == "stats":
            return dict(self._statistics, pending=len(self._pending), sources=len(self._sources))
        if action == "reuse" and isinstance(payload, VisualReuse):
            if tuple(payload.item.property("_ugfVisualFingerprint")) != self._source(payload.source)[0]:
                return False
            state = payload.item.property("viewState")
            state.setProperty("packId", payload.source.split("/", 1)[0])
            state.setProperty("generation", payload.source.partition("?")[2])
            self._statistics["reused"] += 1
            return True
        if action == "create" and isinstance(payload, VisualCreation):
            fingerprint, asset = self._source(payload.source)
            component = self._components.pop(fingerprint, None)
            if component is None:
                component = QQmlComponent(self._engine)
                component.setData(QByteArray(asset.content), QUrl(asset.url))
                if component.isError():
                    detail = "\n".join(error.toString() for error in component.errors())
                    self._router.request(Request("diagnostics", "record", Diagnostic("ERROR", "visual.compile", detail)))
                    raise ValueError(detail)
            self._components[fingerprint] = component
            capacity = self._router.request(Request("settings", "get", "visuals.cache_entries"))
            while len(self._components) > capacity:
                _, removed = self._components.popitem(last=False)
                removed.deleteLater()
            state = self._create_state(payload)
            item = component.createWithInitialProperties({"viewState": state})
            if not isinstance(item, QQuickItem):
                state.deleteLater()
                if item is not None:
                    delete(item)
                detail = "\n".join(error.toString() for error in component.errors())
                raise ValueError(f"Visual must create an Item: {payload.source} {detail}")
            state.setParent(item)
            item.setProperty("_ugfVisualFingerprint", list(fingerprint))
            self._statistics["created"] += 1
            return item
        if action == "invalidate_styles":
            self._styles.clear()
            return None
        if action == "clear":
            self._styles.clear()
            self._sources.clear()
            for component in self._components.values():
                component.deleteLater()
            self._components.clear()
            for component in self._states.values():
                component.deleteLater()
            self._states.clear()
            return None
        if action == "state_count":
            return len(self._states)
        if action == "style_count":
            return len(self._styles)
        if action == "count":
            return len(self._components)
        raise ValueError(f"Invalid visual request: {action}")

    def close(self) -> None:
        self._closed = True
        self._timer.stop()
        self._pending.clear()
        self.handle("clear", None)


class VisualHost(QQuickItem):
    router: AppManager
    sourceChanged = Signal()
    stateChanged = Signal()

    def __init__(self, parent: QQuickItem | None = None) -> None:
        super().__init__(parent)
        self._source = ""
        self._state: QObject | None = None
        self._item: QQuickItem | None = None
        self._paint_source = ""
        self._paint_state = None
        self._ready = False
        self.setEnabled(False)
        self.visibleChanged.connect(self._schedule_rebuild)

    def get_source(self) -> str:
        return self._source

    def set_source(self, value: str) -> None:
        if value != self._source:
            self._source = value
            self.sourceChanged.emit()
            self._schedule_rebuild()

    source = Property(str, get_source, set_source, notify=sourceChanged)

    def get_state(self) -> QObject | None:
        return self._state

    def set_state(self, value: QObject | None) -> None:
        if value is self._state:
            return
        self._state = value
        self.stateChanged.emit()
        self._schedule_rebuild()

    viewState = Property(QObject, get_state, set_state, notify=stateChanged)

    def componentComplete(self) -> None:
        super().componentComplete()
        self._ready = True
        self._schedule_rebuild()

    @Slot()
    def _schedule_rebuild(self):
        if self._ready and self.isVisible():
            self.router.request(Request("visuals", "schedule", self))

    def _rebuild(self) -> None:
        if not self._ready or self._state is None or qmlEngine(self) is None:
            return
        if self._item is not None and self._paint_source == self._source and self._paint_state is self._state:
            return
        if self._item is not None and self._source and self._paint_state is self._state:
            try:
                if self.router.request(Request("visuals", "reuse", VisualReuse(self._source, self._item))):
                    self._paint_source = self._source
                    return
            except (ValueError, KeyError, OSError) as error:
                self.router.request(Request("diagnostics", "record", Diagnostic("ERROR", "visual.load", str(error))))
                self.router.request(Request("events", "publish", Event("visual.failed", VisualFailure(self._source, str(error)))))
                return
        if self._item is not None:
            self._item.setVisible(False)
            self._item.setParentItem(None)
            self._item.deleteLater()
            self._item = None
        if not self._source:
            return
        try:
            item = self.router.request(Request("visuals", "create", VisualCreation(self._source, self._state)))
            item.setParent(self)
            item.setParentItem(self)
            QQmlProperty(item, "anchors.fill").write(self)
            self._item = item
            self._paint_source = self._source
            self._paint_state = self._state
        except (ValueError, KeyError, OSError) as error:
            self.router.request(Request("diagnostics", "record", Diagnostic("ERROR", "visual.load", str(error))))
            self.router.request(Request("events", "publish", Event("visual.failed", VisualFailure(self._source, str(error)))))
