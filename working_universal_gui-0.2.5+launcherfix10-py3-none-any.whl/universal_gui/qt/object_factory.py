from weakref import WeakValueDictionary

from PySide6.QtCore import QObject, Slot
from shiboken6 import getCppPointer, isValid

from universal_gui.qt.bridge import ComponentBridge
from universal_gui.qt.native_windows import WindowChromeBridge


class ObjectFactory(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._component_ports = WeakValueDictionary()
        self._chrome_ports = WeakValueDictionary()

    @Slot(QObject, result=QObject)
    def componentBridge(self, owner):
        key = getCppPointer(owner)[0]
        bridge = self._component_ports.get(key)
        if bridge is None or not isValid(bridge):
            bridge = ComponentBridge(owner)
            self._component_ports[key] = bridge
        return bridge

    @Slot(QObject, result=QObject)
    def windowChromeBridge(self, owner):
        key = getCppPointer(owner)[0]
        bridge = self._chrome_ports.get(key)
        if bridge is None or not isValid(bridge):
            bridge = WindowChromeBridge(owner)
            self._chrome_ports[key] = bridge
        return bridge
