from PySide6.QtCore import QObject, QTimer, Qt
from PySide6.QtQml import QQmlIncubationController


class BudgetController(QQmlIncubationController):
    def __init__(self, scheduler):
        super().__init__()
        self.scheduler = scheduler

    def incubatingObjectCountChanged(self, count):
        if not self.scheduler.closed:
            if count:
                self.scheduler.timer.start()
            else:
                self.scheduler.timer.stop()


class IncubationScheduler(QObject):
    """Advance asynchronous QML construction without monopolizing the GUI loop."""
    def __init__(self, engine):
        super().__init__(engine)
        self.closed = False
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.timer.setInterval(4)
        self.controller = BudgetController(self)
        self.timer.timeout.connect(self.advance)
        engine.setIncubationController(self.controller)

    def advance(self):
        if not self.closed:
            self.controller.incubateFor(4)

    def close(self):
        self.closed = True
        self.timer.stop()
