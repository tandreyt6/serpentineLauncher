from dataclasses import dataclass

from PySide6.QtCore import QObject, QRegularExpression
from PySide6.QtGui import QColor, QSyntaxHighlighter, QTextCharFormat

from universal_gui.contracts import AppearanceQuery, Request
from universal_gui.services.events import Subscription


@dataclass(frozen=True)
class HighlightRule:
    pattern: str
    color_role: str


class SyntaxHighlighter(QSyntaxHighlighter):
    def __init__(self, rules: tuple[HighlightRule, ...], palette: dict[str, str], parent=None):
        super().__init__(parent)
        self._rules = []
        self._palette = dict(palette)
        for rule in rules:
            expression = QRegularExpression(rule.pattern)
            if not expression.isValid():
                raise ValueError(expression.errorString())
            self._rules.append((expression, rule.color_role))

    def set_palette(self, palette: dict[str, str]):
        self._palette = dict(palette)
        self.rehighlight()

    def highlightBlock(self, text):
        for expression, role in self._rules:
            color = self._palette[role]
            formatting = QTextCharFormat()
            formatting.setForeground(QColor(color))
            matches = expression.globalMatch(text)
            while matches.hasNext():
                match = matches.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), formatting)


class HighlighterPaletteBinding(QObject):
    def __init__(self, router, highlighter, query: AppearanceQuery, roles: tuple[tuple[str, str], ...], parent=None):
        super().__init__(parent)
        self._router = router
        self._highlighter = highlighter
        self._query = query
        self._roles = roles
        self._subscription = router.request(Request("events", "subscribe", Subscription("theme.changed", self._on_theme)))
        self.destroyed.connect(self.close)
        self.refresh()

    def refresh(self):
        palette = self._router.request(Request("themes", "palette", self._query))
        self._highlighter.set_palette({role: palette.text(token) for role, token in self._roles})

    def _on_theme(self, event):
        self.refresh()

    def close(self):
        if self._subscription:
            self._router.request(Request("events", "unsubscribe", self._subscription))
            self._subscription = ""
