from dataclasses import dataclass

from PySide6.QtCore import QPointF
from PySide6.QtQuick import QQuickItem


@dataclass(frozen=True)
class DockPanel:
    key: str
    title_tag: str
    source: str
    area: str = "center"


@dataclass(frozen=True)
class DockSetup:
    key: str
    panels: tuple[DockPanel, ...]
    item: QQuickItem
    enabled: bool = True


@dataclass(frozen=True)
class DockGeometry:
    key: str
    width: float
    height: float
    gap: float
    minimum: float


@dataclass(frozen=True)
class DockHover:
    position: QPointF
    source: str
    edge_ratio: float


@dataclass(frozen=True)
class DockDrop:
    source: str
    tabs: tuple[str, ...]


@dataclass(frozen=True)
class DockRatio:
    key: str
    split: str
    ratio: float
