from collections import OrderedDict
from dataclasses import dataclass
from math import isfinite

from PySide6.QtCore import QObject, Property, Signal, Slot


@dataclass(frozen=True)
class DelegateState:
    key: str
    values: tuple[tuple[str, str | int | float | bool | None], ...]


class LocalStateStore(QObject):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._states = OrderedDict()
        self._capacity = 256

    @Slot(str, "QVariantMap")
    def save(self, key, values):
        if not key:
            return
        for name, value in values.items():
            if not isinstance(name, str) or type(value) not in (str, int, float, bool, type(None)) or isinstance(value, float) and not isfinite(value):
                raise TypeError("Delegate state values must be named finite scalar values")
        self._states.pop(key, None)
        self._states[key] = DelegateState(key, tuple(values.items()))
        while len(self._states) > self._capacity:
            self._states.popitem(last=False)
        self.changed.emit()

    @Slot(str, result="QVariantMap")
    def load(self, key):
        state = self._states.pop(key, None)
        if state is None:
            return {}
        self._states[key] = state
        return dict(state.values)

    def set_capacity(self, value):
        if value < 1:
            raise ValueError("State cache capacity must be positive")
        self._capacity = value
        while len(self._states) > value:
            self._states.popitem(last=False)
        self.changed.emit()

    @Slot()
    def clear(self):
        self._states.clear()
        self.changed.emit()

    capacity = Property(int, lambda self: self._capacity, set_capacity, notify=changed)
    count = Property(int, lambda self: len(self._states), notify=changed)
