from pathlib import Path
import json

from PySide6.QtCore import QObject, Property, Signal, Slot
from PySide6.QtQuick import QQuickWindow

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AppearanceOverride, AppearanceQuery, Diagnostic, Event, Request, SettingChange
from universal_gui.services.events import Subscription


class PreviewController(QObject):
    changed = Signal()
    errorChanged = Signal()

    def __init__(self, router: AppManager) -> None:
        super().__init__()
        self._router = router
        self._error = ""
        self._subscriptions = []
        router.request(Request("themes", "preview_enable"))
        for topic in ("theme.changed", "locale.changed", "settings.changed"):
            self._subscriptions.append(router.request(Request("events", "subscribe", Subscription(topic, self._on_event))))

    def _on_event(self, event: Event) -> None:
        self.changed.emit()

    style = Property("QVariantMap", lambda self: self._router.request(Request("themes", "appearance", AppearanceQuery("PreviewShell", "preview.shell")))[0], notify=changed)
    theme = Property(str, lambda self: self._router.request(Request("themes", "current")), notify=changed)
    locale = Property(str, lambda self: self._router.request(Request("localization", "current")), notify=changed)
    themes = Property("QStringList", lambda self: list(self._router.request(Request("themes", "available"))), notify=changed)
    lastError = Property(str, lambda self: self._error, notify=errorChanged)

    @Slot(str)
    def selectTheme(self, theme: str) -> None:
        self._router.request(Request("themes", "select", theme))

    @Slot()
    def cycleTheme(self) -> None:
        current = self.themes.index(self.theme)
        self.selectTheme(self.themes[(current + 1) % len(self.themes)])

    @Slot()
    def cycleLocale(self) -> None:
        locales = self._router.request(Request("localization", "available"))
        current = locales.index(self.locale)
        self._router.request(Request("localization", "select", locales[(current + 1) % len(locales)]))

    @Slot()
    def toggleGeometry(self) -> None:
        current = self._router.request(Request("settings", "get", "diagnostics.geometry"))
        self._router.request(Request("settings", "set", SettingChange("diagnostics.geometry", not current)))

    @Slot(str, str, result="QVariantMap")
    def inspect(self, component_type: str, tag: str) -> dict:
        values, visual = self._router.request(Request("themes", "appearance", AppearanceQuery(component_type, tag)))
        return {"componentType": component_type, "tag": tag, "values": values, "visual": f"{visual.pack_id}/{visual.key}" if visual is not None else ""}

    @Slot(result="QVariantList")
    def registeredComponents(self) -> list[dict]:
        records = self._router.request(Request("registry", "snapshot"))
        return [{"componentType": record.component_type, "tag": record.tag, "token": record.token} for record in records]

    @Slot(result="QVariantMap")
    def manifest(self) -> dict:
        return self._router.request(Request("themes", "inspect"))

    @Slot(str, str, str, "QVariant")
    def setValue(self, component_type: str, tag: str, key: str, value: object) -> None:
        json.dumps(value)
        self._router.request(Request("themes", "override", AppearanceOverride(component_type, tag, ((key, value),))))

    @Slot()
    def reset(self) -> None:
        self._router.request(Request("themes", "reset_overrides"))

    @Slot(str, result=bool)
    def reloadPack(self, path: str) -> bool:
        try:
            self._router.request(Request("themes", "reload", Path(path)))
            self._error = ""
            self.errorChanged.emit()
            return True
        except (ValueError, KeyError, OSError) as error:
            self._error = str(error)
            self._router.request(Request("diagnostics", "record", Diagnostic("WARNING", "preview.reload", self._error)))
            self.errorChanged.emit()
            return False

    @Slot(QObject, str, result=bool)
    def capture(self, window: QObject, destination: str) -> bool:
        if not isinstance(window, QQuickWindow):
            raise TypeError("Capture needs a QQuickWindow")
        return window.grabWindow().save(destination)

    def close(self) -> None:
        for subscription in self._subscriptions:
            self._router.request(Request("events", "unsubscribe", subscription))
        self._subscriptions.clear()
