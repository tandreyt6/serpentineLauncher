from dataclasses import dataclass
from math import isfinite

from PySide6.QtCore import Property, QSize, Signal, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QTransform
from PySide6.QtQml import QJSValue
from PySide6.QtQuick import QQuickPaintedItem, QQuickRhiItem, QQuickRhiItemRenderer
from PySide6.QtCanvasPainter import QCanvasPainterFactory, QCanvasPath


@dataclass(frozen=True)
class PaintBatch:
    color: QColor
    stroke: bool
    line_width: float
    gpu_path: QCanvasPath
    cpu_path: QPainterPath


def numbers(values, count):
    if len(values) != count:
        raise ValueError('Incorrect coordinate count')
    result = tuple(float(value) for value in values)
    if not all(isfinite(value) for value in result):
        raise ValueError('Coordinates must be finite')
    return result


def compile_commands(commands, software):
    batches = []
    key = None
    count = 0
    for command in commands:
        color = QColor(command.get('color', '#ffffff'))
        if not color.isValid():
            raise ValueError('Invalid paint color')
        stroke = bool(command.get('stroke', False))
        line_width = float(command.get('lineWidth', 1))
        if not isfinite(line_width) or line_width < 0:
            raise ValueError('Invalid stroke width')
        current = (color.rgba(), stroke, line_width)
        if current != key:
            gpu = None if software else QCanvasPath()
            cpu = QPainterPath() if software else None
            if cpu is not None:
                cpu.setFillRule(Qt.FillRule.WindingFill)
            batches.append(PaintBatch(color, stroke, line_width, gpu, cpu))
            key = current
        operation = command['op']
        args = command.get('args', [])
        if operation == 'rects':
            if len(args) % 4:
                raise ValueError('Rectangle batch needs groups of four coordinates')
            for index in range(0, len(args), 4):
                x, y, w, h = numbers(args[index:index + 4], 4)
                if gpu is not None:
                    gpu.rect(x, y, w, h)
                if cpu is not None:
                    cpu.addRect(x, y, w, h)
            count += len(args) // 4 - 1
        elif operation == 'rect':
            x, y, w, h = numbers(args, 4)
            if gpu is not None:
                gpu.rect(x, y, w, h)
            if cpu is not None:
                cpu.addRect(x, y, w, h)
        elif operation == 'roundRect':
            x, y, w, h, radius = numbers(args, 5)
            if gpu is not None:
                gpu.roundRect(x, y, w, h, radius)
            if cpu is not None:
                cpu.addRoundedRect(x, y, w, h, radius, radius)
        elif operation == 'ellipse':
            x, y, w, h = numbers(args, 4)
            if gpu is not None:
                gpu.ellipse(x + w / 2, y + h / 2, w / 2, h / 2)
            if cpu is not None:
                cpu.addEllipse(x, y, w, h)
        elif operation == 'path':
            if gpu is not None:
                gpu.beginSolidSubPath()
            for segment in command['segments']:
                kind, values = segment[0], segment[1:]
                if kind in ('moveTo', 'lineTo'):
                    values = numbers(values, 2)
                    if gpu is not None:
                        getattr(gpu, kind)(*values)
                    if cpu is not None:
                        getattr(cpu, kind)(*values)
                elif kind == 'bezierTo':
                    values = numbers(values, 6)
                    if gpu is not None:
                        gpu.bezierCurveTo(*values)
                    if cpu is not None:
                        cpu.cubicTo(*values)
                elif kind == 'quadTo':
                    values = numbers(values, 4)
                    if gpu is not None:
                        gpu.quadraticCurveTo(*values)
                    if cpu is not None:
                        cpu.quadTo(*values)
                elif kind == 'close':
                    if gpu is not None:
                        gpu.closePath()
                    if cpu is not None:
                        cpu.closeSubpath()
                else:
                    raise ValueError('Unknown path segment: ' + kind)
        else:
            raise ValueError('Unknown paint operation: ' + operation)
        count += 1
    return tuple(batches), count


class PaintState:
    software = False
    def initialize_paint_state(self):
        self._commands = []
        self._batches = ()
        self._count = 0
        self._offset_x, self._offset_y = 0.0, 0.0
        self._scale_x, self._scale_y, self._rotation = 1.0, 1.0, 0.0
        self._clear_color = QColor('transparent')

    def set_commands(self, value):
        if isinstance(value, QJSValue):
            value = value.toVariant()
        try:
            batches, count = compile_commands(value, self.software)
        except (ValueError, TypeError, KeyError, OverflowError) as error:
            self.paintError.emit(str(error))
            return
        self._commands, self._batches, self._count = value, batches, count
        self.commandsChanged.emit()
        self.update()

    def set_scalar(self, key, value):
        value = float(value)
        if not isfinite(value):
            return
        if getattr(self, key) != value:
            setattr(self, key, value)
            self.transformChanged.emit()
            self.update()

    def set_clear_color(self, value):
        value = QColor(value)
        if value.isValid() and value != self._clear_color:
            self._clear_color = value
            self.clearColorChanged.emit()
            self.update()

    def matrix(self):
        matrix = QTransform()
        matrix.translate(self._offset_x, self._offset_y)
        matrix.rotate(self._rotation)
        matrix.scale(self._scale_x, self._scale_y)
        return matrix


class GpuPaintItem(QQuickRhiItem, PaintState):
    commandsChanged = Signal()
    transformChanged = Signal()
    clearColorChanged = Signal()
    paintError = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initialize_paint_state()
        self.setAlphaBlending(True)

    commands = Property('QVariantList', lambda self: self._commands, PaintState.set_commands, notify=commandsChanged)
    commandCount = Property(int, lambda self: self._count, notify=commandsChanged)
    batchCount = Property(int, lambda self: len(self._batches), notify=commandsChanged)
    offsetX = Property(float, lambda self: self._offset_x, lambda self, v: self.set_scalar('_offset_x', v), notify=transformChanged)
    offsetY = Property(float, lambda self: self._offset_y, lambda self, v: self.set_scalar('_offset_y', v), notify=transformChanged)
    scaleX = Property(float, lambda self: self._scale_x, lambda self, v: self.set_scalar('_scale_x', v), notify=transformChanged)
    scaleY = Property(float, lambda self: self._scale_y, lambda self, v: self.set_scalar('_scale_y', v), notify=transformChanged)
    paintRotation = Property(float, lambda self: self._rotation, lambda self, v: self.set_scalar('_rotation', v), notify=transformChanged)
    clearColor = Property(QColor, lambda self: self._clear_color, PaintState.set_clear_color, notify=clearColorChanged)

    def createRenderer(self):
        self._renderer = PaintRenderer()
        return self._renderer


class PaintRenderer(QQuickRhiItemRenderer):
    def initialize(self, command_buffer):
        self._factory = QCanvasPainterFactory.sharedInstance(self.rhi())
        self._painter = self._factory.painter()
        self._driver = self._factory.paintDriver()

    def synchronize(self, item):
        self._batches = item._batches
        self._matrix = item.matrix()
        self._clear_color = item._clear_color
        self._size = QSize(round(item.width()), round(item.height()))
        self._dpr = item.window().devicePixelRatio()
        self._antialias = item.antialiasing()

    def render(self, command_buffer):
        self._driver.beginPaint(command_buffer, self.renderTarget(), self._clear_color, self._size, self._dpr)
        painter = self._painter
        painter.setAntialias(1 if self._antialias else 0)
        painter.transform(self._matrix)
        for batch in self._batches:
            if batch.stroke:
                painter.setStrokeStyle(batch.color)
                painter.setLineWidth(batch.line_width)
                painter.stroke(batch.gpu_path)
            else:
                painter.setFillStyle(batch.color)
                painter.fill(batch.gpu_path)
        self._driver.endPaint()


class SoftwarePaintItem(QQuickPaintedItem, PaintState):
    software = True
    commandsChanged = Signal()
    transformChanged = Signal()
    clearColorChanged = Signal()
    paintError = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initialize_paint_state()

    commands = Property('QVariantList', lambda self: self._commands, PaintState.set_commands, notify=commandsChanged)
    commandCount = Property(int, lambda self: self._count, notify=commandsChanged)
    batchCount = Property(int, lambda self: len(self._batches), notify=commandsChanged)
    offsetX = Property(float, lambda self: self._offset_x, lambda self, v: self.set_scalar('_offset_x', v), notify=transformChanged)
    offsetY = Property(float, lambda self: self._offset_y, lambda self, v: self.set_scalar('_offset_y', v), notify=transformChanged)
    scaleX = Property(float, lambda self: self._scale_x, lambda self, v: self.set_scalar('_scale_x', v), notify=transformChanged)
    scaleY = Property(float, lambda self: self._scale_y, lambda self, v: self.set_scalar('_scale_y', v), notify=transformChanged)
    paintRotation = Property(float, lambda self: self._rotation, lambda self, v: self.set_scalar('_rotation', v), notify=transformChanged)
    clearColor = Property(QColor, lambda self: self._clear_color, PaintState.set_clear_color, notify=clearColorChanged)

    def paint(self, painter):
        painter.fillRect(self.boundingRect(), self._clear_color)
        painter.setRenderHint(QPainter.Antialiasing, self.antialiasing())
        painter.setWorldTransform(self.matrix())
        for batch in self._batches:
            if batch.stroke:
                painter.setPen(QPen(batch.color, batch.line_width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.FlatCap, Qt.PenJoinStyle.MiterJoin))
                painter.strokePath(batch.cpu_path, painter.pen())
            else:
                painter.fillPath(batch.cpu_path, batch.color)
