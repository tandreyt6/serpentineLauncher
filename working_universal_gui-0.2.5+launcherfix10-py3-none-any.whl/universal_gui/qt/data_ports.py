from dataclasses import dataclass
import json

from PySide6.QtCore import Slot

from universal_gui.contracts import Diagnostic, Event, Request
from universal_gui.qt.bridge import ComponentBridge
from universal_gui.ui_contracts import ActionIntent


@dataclass(frozen=True)
class FileIntent:
    component: str
    action: str
    path: str
    keys: tuple[str, ...] = ()
    urls: tuple[str, ...] = ()
    value: str = ""


@dataclass(frozen=True)
class DropIntent:
    component: str
    text: str
    urls: tuple[str, ...]
    keys: tuple[str, ...]
    action: str


class DataBridge(ComponentBridge):
    @Slot(str, str)
    def action(self, key, context):
        self.router.request(Request("events", "publish", Event("ui.action", ActionIntent(self._tag, key, context))))

    @Slot(str, str, "QVariantList", "QVariantList", str)
    def fileAction(self, action: str, path: str, keys: list, urls: list, value: str) -> None:
        if action not in {"open", "navigate", "rename", "delete", "upload", "download", "create_folder", "copy", "move", "refresh", "import", "context", "children", "back"}:
            raise ValueError(f"Unknown file intent: {action}")
        if not all(isinstance(key, str) for key in keys) or not all(isinstance(url, str) for url in urls):
            raise TypeError("File intent keys and URLs must be strings")
        intent = FileIntent(self._tag, action, path, tuple(keys), tuple(urls), value)
        self.router.request(Request("events", "publish", Event("files.intent", intent)))

    @Slot(str, "QVariantList", str, str, result="QVariantMap")
    def receiveDrop(self, text: str, urls: list, encoded_keys: str, action: str) -> dict:
        try:
            keys = json.loads(encoded_keys) if encoded_keys else []
            if not isinstance(keys, list) or not all(isinstance(key, str) for key in keys):
                raise ValueError("Drag keys must be a JSON string array")
            if not all(isinstance(url, str) for url in urls):
                raise ValueError("Drag URLs must be strings")
        except (ValueError, TypeError) as error:
            self.router.request(Request("diagnostics", "record", Diagnostic("WARNING", "drag.rejected", str(error))))
            return {}
        intent = DropIntent(self._tag, text, tuple(urls), tuple(keys), action)
        self.router.request(Request("events", "publish", Event("drag.dropped", intent)))
        return {"text": intent.text, "urls": list(intent.urls), "keys": list(intent.keys), "action": intent.action}
