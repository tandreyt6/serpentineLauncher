from PySide6.QtCore import QObject, Property, Signal, Slot
from PySide6.QtGui import QColor
from PySide6.QtQml import QJSValue
from copy import deepcopy

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AppearanceQuery, AssetQuery, Event, Request, TextQuery
from universal_gui.services.events import Subscription
from universal_gui.services.registry import Registration


class ComponentBridge(QObject):
    router: AppManager
    changed = Signal()
    textChanged = Signal()
    localeChanged = Signal()
    styleChanged = Signal()
    visualChanged = Signal()
    optionsChanged = Signal()
    suspendedChanged = Signal()
    identityChanged = Signal()
    presentationChanged = Signal()
    textKeyChanged = Signal()
    displayTextChanged = Signal()
    displayModeChanged = Signal()

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._component_type = ""
        self._tag = ""
        self._token = ""
        self._text = ""
        self._locale_revision = 0
        self._style: dict = {}
        self._paint_style = None
        self._visual = ""
        self._suspended = False
        self._reduced_motion = False
        self._geometry_visible = False
        self._subscriptions: list[str] = []
        self._state_key = ""
        self._density = "normal"
        self._typography_role = "body"
        self._text_key = ""
        self._display_text = ""
        self._use_display_text = False
        self._text_from_tag = True
        self._settings_revision = 0

    def set_state_key(self, value: str) -> None:
        if value != self._state_key:
            self._state_key = value
            self.presentationChanged.emit()
            if self._component_type and self._tag:
                self.refresh("theme.changed")

    def set_density(self, value: str) -> None:
        if value != self._density:
            self._density = value
            self.presentationChanged.emit()
            if self._component_type and self._tag:
                self.refresh("theme.changed")

    def set_typography_role(self, value: str) -> None:
        if value != self._typography_role:
            self._typography_role = value
            self.presentationChanged.emit()
            if self._component_type and self._tag:
                self.refresh("theme.changed")

    def set_text_key(self, value: str) -> None:
        if value == self._text_key:
            return
        self._text_key = value
        self.textKeyChanged.emit()
        self.presentationChanged.emit()
        if self._token:
            self.refresh("locale.changed")

    def set_display_text(self, value: str) -> None:
        if value == self._display_text and self._use_display_text:
            return
        self._display_text = value
        self._use_display_text = True
        self.displayTextChanged.emit()
        self.displayModeChanged.emit()
        self.presentationChanged.emit()
        if self._token:
            self.refresh("locale.changed")

    def set_use_display_text(self, value: bool) -> None:
        if value == self._use_display_text:
            return
        self._use_display_text = value
        self.displayModeChanged.emit()
        self.presentationChanged.emit()
        if self._token:
            self.refresh("locale.changed")

    stateKey = Property(str, lambda self: self._state_key, set_state_key, notify=presentationChanged)
    density = Property(str, lambda self: self._density, set_density, notify=presentationChanged)
    typographyRole = Property(str, lambda self: self._typography_role, set_typography_role, notify=presentationChanged)
    textKey = Property(str, lambda self: self._text_key, set_text_key, notify=textKeyChanged)
    displayText = Property(str, lambda self: self._display_text, set_display_text, notify=displayTextChanged)
    useDisplayText = Property(bool, lambda self: self._use_display_text, set_use_display_text, notify=displayModeChanged)
    textFromTag = Property(bool, lambda self: self._text_from_tag, lambda self, value: self.set_text_from_tag(value), notify=displayModeChanged)
    settingsRevision = Property(int, lambda self: self._settings_revision, notify=optionsChanged)

    def set_text_from_tag(self, value):
        if value != self._text_from_tag:
            self._text_from_tag = value
            self.displayModeChanged.emit()
            if self._token:
                self.refresh("locale.changed")

    @Slot(str, result="QVariant")
    def setting(self, key):
        return self.router.request(Request("settings", "get", key))

    @Slot(str, result=float)
    def numberToken(self, name):
        if not self._style:
            self.refresh("theme.changed")
        value = self._style[name]
        if type(value) not in (int, float):
            raise TypeError(f"Token is not numeric: {name}")
        return float(value)

    @Slot(str, result=QColor)
    def colorToken(self, name):
        if not self._style:
            self.refresh("theme.changed")
        value = self._style[name]
        if not isinstance(value, str) or not QColor(value).isValid():
            raise TypeError(f"Token is not a color: {name}")
        return QColor(value)

    def get_component_type(self) -> str:
        return self._component_type

    def set_component_type(self, value: str) -> None:
        if self._token:
            raise RuntimeError("Component type is immutable after registration")
        self._component_type = value
        if self._tag:
            self.refresh("theme.changed")
        self.identityChanged.emit()

    componentType = Property(str, get_component_type, set_component_type, notify=identityChanged)

    def get_tag(self) -> str:
        return self._tag

    def set_tag(self, value: str) -> None:
        if value == self._tag:
            return
        attached = bool(self._token)
        if attached:
            raise RuntimeError("Tag is immutable after registration; recreate the component")
        self._tag = value
        if self._component_type:
            self.refresh("theme.changed")
        self.identityChanged.emit()

    tag = Property(str, get_tag, set_tag, notify=identityChanged)
    token = Property(str, lambda self: self._token, notify=identityChanged)
    text = Property(str, lambda self: self._text, notify=textChanged)
    localeRevision = Property(int, lambda self: self._locale_revision, notify=localeChanged)
    localeName = Property(str, lambda self: self.router.request(Request("localization", "current")), notify=localeChanged)
    style = Property("QVariantMap", lambda self: deepcopy(dict(self._style)), notify=styleChanged)
    paintStyle = Property(QJSValue, lambda self: self.get_paint_style(), notify=styleChanged)
    visual = Property(str, lambda self: self._visual, notify=visualChanged)
    reducedMotion = Property(bool, lambda self: self._reduced_motion, notify=optionsChanged)
    geometryVisible = Property(bool, lambda self: self._geometry_visible, notify=optionsChanged)
    suspended = Property(bool, lambda self: self._suspended, notify=suspendedChanged)

    def get_paint_style(self):
        return self._paint_style if self._paint_style is not None else QJSValue()

    @Slot(QObject)
    def attach(self, owner: QObject) -> None:
        if self._token:
            return
        if not self._component_type or not self._tag:
            raise ValueError(f"Every public component needs a type and a tag: {self._component_type!r}, {self._tag!r}")
        self._token = self.router.request(Request("registry", "register", Registration(owner, self._component_type, self._tag)))
        owner.destroyed.connect(self.detach)
        for topic in ("theme.changed", "locale.changed", "settings.changed"):
            token = self.router.request(Request("events", "subscribe", Subscription(topic, self._on_event)))
            self._subscriptions.append(token)
        if self._style and self._paint_style is not None:
            self.refresh("locale.changed")
            self.refresh("settings.changed")
        else:
            self.refresh()
        self.identityChanged.emit()

    @Slot()
    def detach(self) -> None:
        if not self._token:
            return
        for subscription in self._subscriptions:
            self.router.request(Request("events", "unsubscribe", subscription))
        self._subscriptions.clear()
        self.router.request(Request("registry", "unregister", self._token))
        self._token = ""
        self._paint_style = None
        self.identityChanged.emit()

    def _on_event(self, event: Event) -> None:
        if self._token:
            self.refresh(event.topic)

    @Slot()
    @Slot(str)
    def refresh(self, topic: str = "") -> None:
        if topic in ("", "locale.changed"):
            self._locale_revision += 1
            key = self._text_key or (self._tag if self._text_from_tag else "")
            text = self._display_text if self._use_display_text else self.router.request(Request("localization", "text", TextQuery(key))) if key else ""
            if text != self._text:
                self._text = text
                self.textChanged.emit()
            self.localeChanged.emit()
        if topic in ("", "theme.changed"):
            style, paint_style, asset = self.router.request(Request("visuals", "appearance", AppearanceQuery(self._component_type, self._tag, self._state_key, self._density, self._typography_role)))
            visual = f"{asset.pack_id}/{asset.key}?generation={asset.generation}" if asset is not None else ""
            style_changed = style != self._style or self._paint_style is None
            visual_changed = visual != self._visual
            self._style = style
            self._paint_style = paint_style
            self._visual = visual
            if style_changed:
                self.styleChanged.emit()
            if visual_changed:
                self.visualChanged.emit()
        if topic in ("", "settings.changed"):
            self._settings_revision += 1
            reduced = bool(self.router.request(Request("settings", "get", "motion.reduced")))
            geometry = bool(self.router.request(Request("settings", "get", "diagnostics.geometry")))
            if reduced != self._reduced_motion or geometry != self._geometry_visible:
                self._reduced_motion = reduced
                self._geometry_visible = geometry
            self.optionsChanged.emit()
        self.changed.emit()

    @Slot(str, result=str)
    def textFor(self, tag: str) -> str:
        return self.router.request(Request("localization", "text", TextQuery(tag)))

    @Slot(str, result=str)
    def assetUrl(self, key: str) -> str:
        pack_id = self._visual.split("/", 1)[0] if self._visual else ""
        return self.router.request(Request("themes", "asset_url", AssetQuery(pack_id, key)))

    @Slot(str, result=str)
    def imageUrl(self, source: str) -> str:
        return self.router.request(Request("resources", "image_url", source))

    @Slot(bool)
    def suspend(self, value: bool) -> None:
        if value != self._suspended:
            self._suspended = value
            self.suspendedChanged.emit()
