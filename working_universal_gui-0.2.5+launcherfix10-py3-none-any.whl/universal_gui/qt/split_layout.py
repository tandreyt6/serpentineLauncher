from dataclasses import dataclass
from math import isfinite

from PySide6.QtCore import QObject, Slot


@dataclass(frozen=True)
class PaneSpec:
    minimum: float = 0
    maximum: float = float("inf")
    preferred: float = 1
    weight: float | None = None
    collapsed: bool = False


def layout_panes(available: float, panes: tuple[PaneSpec, ...]) -> tuple[float, ...]:
    if not isfinite(available) or available < 0:
        raise ValueError("Invalid available split size")
    for pane in panes:
        if not isfinite(pane.minimum) or pane.minimum < 0 or pane.maximum < pane.minimum or pane.maximum != pane.maximum:
            raise ValueError("Invalid pane limits")
        if not isfinite(pane.preferred) or pane.preferred < 0 or pane.weight is not None and (not isfinite(pane.weight) or pane.weight < 0):
            raise ValueError("Invalid pane preference")
    minimum = [0 if pane.collapsed else pane.minimum for pane in panes]
    maximum = [0 if pane.collapsed else pane.maximum for pane in panes]
    weights = [0 if pane.collapsed else pane.preferred if pane.weight is None else pane.weight for pane in panes]
    if sum(minimum) > available:
        return tuple(value * available / sum(minimum) for value in minimum)
    if not sum(weights):
        weights = [0 if pane.collapsed else 1 for pane in panes]
    total_weight = sum(weights)
    sizes = [max(low, min(high, available * weight / total_weight if total_weight else 0)) for low, high, weight in zip(minimum, maximum, weights)]
    for attempt in range(len(panes) + 1):
        remaining = available - sum(sizes)
        if abs(remaining) < 0.000001:
            break
        indices = [index for index in range(len(panes)) if sizes[index] < maximum[index] - 0.000001] if remaining > 0 else [index for index in range(len(panes)) if sizes[index] > minimum[index] + 0.000001]
        if not indices:
            break
        divisor = sum(weights[index] for index in indices)
        for index in indices:
            share = weights[index] / divisor if divisor else 1 / len(indices)
            sizes[index] = max(minimum[index], min(maximum[index], sizes[index] + remaining * share))
    return tuple(sizes)


class SplitLayout(QObject):
    @Slot(float, "QVariantList", "QVariantList", "QVariantList", "QVariantList", "QVariantList", result="QVariantList")
    def solve(self, available, minimum, maximum, preferred, weights, collapsed):
        count = max(len(minimum), len(maximum), len(preferred), len(weights), len(collapsed))
        panes = tuple(PaneSpec(minimum[index] if index < len(minimum) else 0, maximum[index] if index < len(maximum) else float("inf"), preferred[index] if index < len(preferred) else 1, weights[index] if index < len(weights) else None, collapsed[index] if index < len(collapsed) else False) for index in range(count))
        return list(layout_panes(available, panes))
