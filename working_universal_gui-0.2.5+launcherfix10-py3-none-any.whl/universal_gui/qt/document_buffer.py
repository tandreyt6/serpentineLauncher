from collections import OrderedDict, deque

from PySide6.QtCore import QObject, Property, QTimer, Signal, Slot
from PySide6.QtGui import QTextCursor, QTextDocument
from PySide6.QtQuick import QQuickTextDocument

from universal_gui.contracts import Event, Request
from universal_gui.ui_contracts import DocumentSnapshot, SaveIntent


class DocumentBuffer(QObject):
    router = None
    changed = Signal()
    saveRequested = Signal(object)
    closeRequested = Signal()
    appendFinished = Signal()
    appendingChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._document = QTextDocument(self)
        self._document.documentLayout()
        self._document.contentsChange.connect(self._on_contents_change)
        self._key = ""
        self._revision = 0
        self._saved_revision = 0
        self._saved_text = ""
        self._loading = False
        self._pending = OrderedDict()
        self._highlighter = None
        self._saved_characters = self._document.characterCount()
        self._dirty = False
        self._append_queue = deque()
        self._append_offset = 0
        self._append_characters = 0
        self._append_timer = QTimer(self)
        self._append_timer.setSingleShot(True)
        self._append_timer.timeout.connect(self._append_next)

    def _update_dirty(self):
        self._dirty = self._document.characterCount() != self._saved_characters or self._document.toPlainText() != self._saved_text

    def _on_contents_change(self, position, removed, added):
        if removed or added:
            self._on_changed()

    def _on_changed(self):
        if not self._loading:
            self._revision += 1
            self._update_dirty()
        self.changed.emit()

    def load_snapshot(self, snapshot: DocumentSnapshot):
        if not isinstance(snapshot, DocumentSnapshot):
            raise TypeError("Expected DocumentSnapshot")
        self.cancelAppend()
        self._loading = True
        self._key = snapshot.key
        self._revision = snapshot.revision
        self._saved_revision = snapshot.revision
        self._saved_text = snapshot.text
        self._pending.clear()
        self._document.setPlainText(snapshot.text)
        self._saved_text = self._document.toPlainText()
        self._saved_characters = self._document.characterCount()
        self._dirty = False
        self._document.clearUndoRedoStacks()
        self._loading = False
        self.changed.emit()

    @Slot(str, str, int)
    def reset(self, key, text, revision):
        self.load_snapshot(DocumentSnapshot(key, text, revision))

    @Slot(QObject)
    def attachEditor(self, adapter):
        if not isinstance(adapter, QQuickTextDocument):
            raise TypeError("Expected QQuickTextDocument")
        adapter.setTextDocument(self._document)

    @Slot()
    def requestSave(self):
        intent = SaveIntent(self._key, self._revision, self._document.toPlainText())
        self._pending[intent.revision] = intent.text
        capacity = self.router.request(Request("settings", "get", "documents.pending_saves"))
        while len(self._pending) > capacity:
            self._pending.popitem(last=False)
        self.saveRequested.emit(intent)
        self.router.request(Request("events", "publish", Event("documents.save", intent)))

    @Slot(int, result=bool)
    def acknowledge(self, revision):
        if revision not in self._pending or revision < self._saved_revision:
            return False
        self._saved_text = self._pending.pop(revision)
        self._saved_revision = revision
        self._saved_characters = len(self._saved_text.encode("utf-16-le")) // 2 + 1
        self._update_dirty()
        for previous in tuple(self._pending):
            if previous <= revision:
                self._pending.pop(previous)
        self.changed.emit()
        return True

    @Slot()
    def requestClose(self):
        self.closeRequested.emit()

    @Slot()
    def undo(self):
        self._document.undo()

    @Slot()
    def redo(self):
        self._document.redo()

    @Slot(str, str, result=int)
    def replaceAll(self, search, replacement):
        if not search:
            return 0
        cursor = QTextCursor(self._document)
        cursor.beginEditBlock()
        found = self._document.find(search, cursor)
        count = 0
        while not found.isNull():
            found.insertText(replacement)
            cursor = found
            count += 1
            found = self._document.find(search, cursor)
        cursor.endEditBlock()
        return count

    @Slot(str)
    def append(self, text):
        cursor = QTextCursor(self._document)
        cursor.movePosition(QTextCursor.MoveOperation.End)
        layout_enabled = self._document.isLayoutEnabled()
        self._document.setLayoutEnabled(False)
        cursor.beginEditBlock()
        try:
            cursor.insertText(text)
        finally:
            cursor.endEditBlock()
            self._document.setLayoutEnabled(layout_enabled)

    @Slot(str)
    def appendIncremental(self, text):
        limit = self.router.request(Request("settings", "get", "documents.pending_characters"))
        if len(text) + self._append_characters > limit:
            raise ValueError("Pending document text exceeds configured capacity")
        if not text:
            return
        was_appending = bool(self._append_queue)
        self._append_queue.append(text)
        self._append_characters += len(text)
        if not was_appending:
            self.appendingChanged.emit()
        if not self._append_timer.isActive():
            self._append_timer.start(1)

    def _append_next(self):
        if not self._append_queue:
            return
        size = self.router.request(Request("settings", "get", "documents.chunk_characters"))
        text = self._append_queue[0]
        end = min(len(text), self._append_offset + size)
        self.append(text[self._append_offset:end])
        self._append_characters -= end - self._append_offset
        self._append_offset = end
        if end == len(text):
            self._append_queue.popleft()
            self._append_offset = 0
        if self._append_queue:
            self._append_timer.start(1)
        else:
            self.appendingChanged.emit()
            self.appendFinished.emit()

    @Slot()
    def cancelAppend(self):
        was_appending = bool(self._append_queue)
        self._append_timer.stop()
        self._append_queue.clear()
        self._append_offset = 0
        self._append_characters = 0
        if was_appending:
            self.appendingChanged.emit()

    @Slot(int)
    def limitBlocks(self, count):
        if count < 0:
            raise ValueError("Maximum document blocks must not be negative")
        self._document.setMaximumBlockCount(count)

    def set_highlighter(self, value):
        if self._highlighter is not None:
            self._highlighter.setDocument(None)
        self._highlighter = value
        if value is not None:
            value.setDocument(self._document)
        self.changed.emit()

    key = Property(str, lambda self: self._key, notify=changed)
    text = Property(str, lambda self: self._document.toPlainText(), notify=changed)
    lineCount = Property(int, lambda self: self._document.blockCount(), notify=changed)
    appending = Property(bool, lambda self: bool(self._append_queue), notify=appendingChanged)
    revision = Property(int, lambda self: self._revision, notify=changed)
    acknowledgedRevision = Property(int, lambda self: self._saved_revision, notify=changed)
    dirty = Property(bool, lambda self: self._dirty, notify=changed)
    document = Property(QObject, lambda self: self._document, constant=True)
    highlighter = Property(QObject, lambda self: self._highlighter, set_highlighter, notify=changed)
