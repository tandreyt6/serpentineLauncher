from PySide6.QtCore import Property, QRectF, QSize, QUrl, Signal
from PySide6.QtGui import QColor, QImage, QImageReader, QPainter, QPainterPath
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtQml import QQmlEngine
from PySide6.QtQuick import QQuickPaintedItem


class SoftwareImageItem(QQuickPaintedItem):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._source = QUrl()
        self._image = QImage()
        self._tint = QColor('white')
        self._tinted = False
        self._radius = 0.0
        self._fit = 1
        self._network = QNetworkAccessManager(self)
        self._reply = None
        self.setAntialiasing(True)

    def set_source(self, source):
        source = QUrl(source)
        if source == self._source:
            return
        self._source = source
        if self._reply is not None:
            self._reply.abort()
        if source.scheme() in ('http', 'https'):
            reply = self._network.get(QNetworkRequest(source))
            self._reply = reply
            def ready():
                if self._reply is reply:
                    self._image = QImage.fromData(reply.readAll())
                    self._reply = None
                    self.update()
                reply.deleteLater()
            reply.finished.connect(ready)
        elif source.scheme() == 'image':
            context = QQmlEngine.contextForObject(self)
            provider = context.engine().imageProvider(source.host()) if context else None
            self._image = provider.requestImage(source.path().lstrip('/') + ('?' + source.query() if source.hasQuery() else ''), QSize(), QSize()) if provider else QImage()
        else:
            self._image = QImageReader(source.toLocalFile() if source.isLocalFile() else source.toString()).read() if not source.isEmpty() else QImage()
        self.changed.emit()
        self.update()

    def set_value(self, key, value):
        if getattr(self, key) != value:
            setattr(self, key, value)
            self.changed.emit()
            self.update()

    source = Property(QUrl, lambda self: self._source, set_source, notify=changed)
    tint = Property(QColor, lambda self: self._tint, lambda self, value: self.set_value('_tint', QColor(value)), notify=changed)
    tinted = Property(bool, lambda self: self._tinted, lambda self, value: self.set_value('_tinted', value), notify=changed)
    radius = Property(float, lambda self: self._radius, lambda self, value: self.set_value('_radius', value), notify=changed)
    fillMode = Property(int, lambda self: self._fit, lambda self, value: self.set_value('_fit', value), notify=changed)

    def paint(self, painter):
        if self._image.isNull() or self.width() <= 0 or self.height() <= 0:
            return
        image = self._image
        if self._tinted:
            image = image.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
            tint = QPainter(image)
            tint.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
            tint.fillRect(image.rect(), self._tint)
            tint.end()
        target = self.boundingRect()
        clip = QPainterPath()
        clip.addRoundedRect(target, self._radius, self._radius)
        painter.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        painter.setClipPath(clip)
        if self._fit in (1, 2):
            ratio = (max if self._fit == 2 else min)(target.width() / image.width(), target.height() / image.height())
            w, h = image.width() * ratio, image.height() * ratio
            target = QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)
        painter.drawImage(target, image)
