from collections import OrderedDict

from PySide6.QtCore import QEasingCurve, QObject, Property, QPropertyAnimation, Signal, Slot, Qt
from PySide6.QtQml import QQmlProperty
from PySide6.QtQuick import QQuickItem
from shiboken6 import getCppPointer, isValid


class StackHost(QQuickItem):
    selectionChanged = Signal()
    policyChanged = Signal()
    pagePrepared = Signal(str, QQuickItem)
    pageShown = Signal(str, QQuickItem)
    pageHidden = Signal(str, QQuickItem)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._destroying = False
        self.destroyed.connect(lambda: setattr(self, "_destroying", True))
        self._pages = OrderedDict()
        self._creating = set()
        self._requested_key = ""
        self._page_serial = 0
        self._page_generations = {}
        self._containers = {}
        self._current = None
        self._key = ""
        self._capacity = 8
        self._duration = 0
        self._policy = "keep"
        self._animations = []
        self._mode = "crossfade"
        self._orientation = Qt.Orientation.Horizontal.value
        self._direction = 1
        self._easing = QEasingCurve.Type.OutQuad.value
        self.widthChanged.connect(self._resize_containers)
        self.heightChanged.connect(self._resize_containers)

    def _resize_containers(self):
        for container in self._containers.values():
            container.setWidth(self.width())
            container.setHeight(self.height())

    def _stop_animations(self):
        for animation in self._animations:
            animation.stop()
            animation.deleteLater()
        self._animations.clear()

    def _animate(self, target, name, start, end):
        animation = QPropertyAnimation(target, name, self)
        animation.setStartValue(start)
        animation.setEndValue(end)
        animation.setDuration(self._duration)
        animation.setEasingCurve(QEasingCurve.Type(self._easing))
        animation.finished.connect(self._finish_transition)
        self._animations.append(animation)

    @Slot(str, result=QQuickItem)
    def retainedItem(self, key):
        return self._pages.get(key)

    def _same_item(self, left, right):
        return left is right or left is not None and right is not None and isValid(left) and isValid(right) and getCppPointer(left)[0] == getCppPointer(right)[0]

    @Slot(str, bool, result=bool)
    def beginCreation(self, key, activate):
        if not key:
            raise ValueError("Stack page needs a key")
        if activate:
            self._requested_key = key
        if key in self._creating:
            return False
        self._creating.add(key)
        return True

    @Slot(str)
    def endCreation(self, key):
        self._creating.discard(key)

    @Slot(QObject, str)
    def selectKey(self, control, key):
        control.setProperty("currentKey", key)

    @Slot(str, QQuickItem)
    def showCreated(self, key, item):
        if not isinstance(item, QQuickItem) or not isValid(item):
            raise ValueError("Stack page factory must create an Item")
        if self._requested_key != key:
            if self._policy == "discard":
                item.deleteLater()
            elif key not in self._pages:
                self.prepareItem(key, item)
            return
        self.showItem(key, item)

    def _prepare_item(self, key, item):
        container = QQuickItem(self)
        container.setParentItem(self)
        container.setFlag(QQuickItem.Flag.ItemIsFocusScope, True)
        container.setWidth(self.width())
        container.setHeight(self.height())
        container.setVisible(False)
        container.setEnabled(False)
        item.setParent(container)
        item.setParentItem(container)
        QQmlProperty(item, "anchors.fill").write(container)
        self._containers[key] = container
        self._pages[key] = item
        self._page_serial += 1
        serial = self._page_serial
        self._page_generations[key] = serial
        item.destroyed.connect(lambda: self._page_destroyed(key, serial))
        self.pagePrepared.emit(key, item)

    def _page_destroyed(self, key, serial):
        if self._destroying or not isValid(self) or self._page_generations.get(key) != serial:
            return
        self._stop_animations()
        self._page_generations.pop(key)
        self._pages.pop(key, None)
        container = self._containers.pop(key, None)
        if self._key == key:
            self._key = ""
            self._current = None
        if container is not None and isValid(container):
            container.setVisible(False)
            container.deleteLater()
        for entry, candidate in self._containers.items():
            candidate.setVisible(entry == self._key)
            candidate.setEnabled(entry == self._key)
            candidate.setOpacity(1)
            candidate.setX(0)
            candidate.setY(0)
        self.selectionChanged.emit()

    @Slot(str, QQuickItem, result=QQuickItem)
    def prepareItem(self, key, item):
        if not isinstance(item, QQuickItem) or not isValid(item) or not key:
            raise ValueError("Prepared page needs a key and an Item")
        retained = self._pages.get(key)
        if retained is not None:
            if not self._same_item(retained, item):
                raise ValueError("Stack key already belongs to a retained page")
            return retained
        if self._policy == "discard":
            raise ValueError("Discard policy does not retain prepared pages")
        if self._policy == "bounded" and self._capacity == 1 and self._current is not None:
            raise ValueError("Preparation needs capacity for the active and prepared page")
        self._prepare_item(key, item)
        self._trim()
        self.selectionChanged.emit()
        return item

    @Slot(str, QQuickItem)
    def showItem(self, key, item):
        if not isinstance(item, QQuickItem) or not isValid(item) or not key:
            raise ValueError("Stack page must be an Item")
        self._requested_key = key
        if key == self._key and self._same_item(self._current, item):
            return
        retained = self._pages.get(key)
        if retained is not None and not self._same_item(retained, item):
            raise ValueError("Stack key already belongs to a retained page")
        if retained is not None:
            item = retained
        self._stop_animations()
        previous_key = self._key
        previous_container = self._containers.get(self._key)
        for container in self._containers.values():
            container.setEnabled(False)
            container.setOpacity(1)
            container.setX(0)
            container.setY(0)
        self._pages.pop(key, None)
        if retained is None:
            self._prepare_item(key, item)
            if self._requested_key != key or self._key == key and self._same_item(self._current, item):
                return
        previous = self._current
        self._pages[key] = item
        self._current = item
        self._key = key
        container = self._containers[key]
        animated = self._duration and self._mode != "none" and previous is not None and previous is not item
        for candidate in self._containers.values():
            candidate.setVisible(candidate is container or bool(animated and candidate is previous_container))
        container.setVisible(True)
        container.setEnabled(True)
        container.forceActiveFocus()
        if previous is not None:
            self.pageHidden.emit(previous_key, previous)
        self.pageShown.emit(key, item)
        if animated:
            previous_container.setVisible(True)
            previous_container.setOpacity(1)
            container.setOpacity(0)
            self._animate(previous_container, b"opacity", 1, 0)
            self._animate(container, b"opacity", 0, 1)
            if self._mode == "slide":
                name = b"x" if self._orientation == Qt.Orientation.Horizontal.value else b"y"
                extent = self.width() if name == b"x" else self.height()
                self._animate(previous_container, name, 0, -extent * self._direction)
                self._animate(container, name, extent * self._direction, 0)
            for animation in self._animations:
                animation.start()
        else:
            self._trim()
        self.selectionChanged.emit()

    def _finish_transition(self):
        if any(animation.state() == QPropertyAnimation.State.Running for animation in self._animations):
            return
        for key, container in self._containers.items():
            container.setVisible(key == self._key)
            container.setX(0)
            container.setY(0)
        self._stop_animations()
        self._trim()

    def _trim(self):
        if self._policy == "keep":
            return
        previous_count = len(self._pages)
        capacity = 1 if self._policy == "discard" else self._capacity
        while len(self._pages) > capacity:
            key = next(key for key, page in self._pages.items() if page is not self._current)
            self._pages.pop(key)
            self._page_generations.pop(key, None)
            container = self._containers.pop(key)
            container.setVisible(False)
            container.deleteLater()
        if len(self._pages) != previous_count:
            self.selectionChanged.emit()

    @Slot(str)
    def forget(self, key):
        item = self._pages.pop(key, None)
        if item is not None:
            self._page_generations.pop(key, None)
            self._stop_animations()
            if item is self._current:
                self._current = None
                self._key = ""
                self.selectionChanged.emit()
            self._containers.pop(key).deleteLater()
            for entry, container in self._containers.items():
                container.setVisible(entry == self._key)
                container.setEnabled(entry == self._key)
                container.setOpacity(1)
                container.setX(0)
                container.setY(0)
            self.selectionChanged.emit()

    def set_duration(self, value):
        self._duration = max(0, value)
        if not value:
            self._stop_animations()
            for key, container in self._containers.items():
                container.setVisible(key == self._key)
                container.setOpacity(1)
                container.setX(0)
                container.setY(0)
            self._trim()
        self.policyChanged.emit()

    def set_capacity(self, value):
        if value < 1:
            raise ValueError("Stack capacity must be positive")
        self._capacity = value
        self._trim()
        self.policyChanged.emit()

    def set_policy(self, value):
        if value not in ("keep", "bounded", "discard"):
            raise ValueError("Invalid stack retention policy")
        self._policy = value
        self._trim()
        self.policyChanged.emit()

    def set_mode(self, value):
        if value not in ("crossfade", "slide", "none"):
            raise ValueError("Invalid stack transition")
        self._mode = value
        self.policyChanged.emit()

    def set_orientation(self, value):
        if value not in (Qt.Orientation.Horizontal.value, Qt.Orientation.Vertical.value):
            raise ValueError("Invalid stack orientation")
        self._orientation = value
        self.policyChanged.emit()

    def set_direction(self, value):
        if value not in (-1, 1):
            raise ValueError("Stack direction must be -1 or 1")
        self._direction = value
        self.policyChanged.emit()

    def set_easing(self, value):
        QEasingCurve.Type(value)
        self._easing = value
        self.policyChanged.emit()

    currentItem = Property(QQuickItem, lambda self: self._current, notify=selectionChanged)
    currentKey = Property(str, lambda self: self._key, notify=selectionChanged)
    retainedCount = Property(int, lambda self: len(self._pages), notify=selectionChanged)
    capacity = Property(int, lambda self: self._capacity, set_capacity, notify=policyChanged)
    duration = Property(int, lambda self: self._duration, set_duration, notify=policyChanged)
    retentionPolicy = Property(str, lambda self: self._policy, set_policy, notify=policyChanged)
    transitionMode = Property(str, lambda self: self._mode, set_mode, notify=policyChanged)
    orientation = Property(int, lambda self: self._orientation, set_orientation, notify=policyChanged)
    direction = Property(int, lambda self: self._direction, set_direction, notify=policyChanged)
    easing = Property(int, lambda self: self._easing, set_easing, notify=policyChanged)
