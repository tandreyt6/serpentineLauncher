from dataclasses import dataclass

from PySide6.QtCore import QObject


@dataclass(frozen=True)
class WindowOwnerContext:
    key: str
    scope_key: str = "default"


@dataclass(frozen=True)
class FloatingWindowSpec:
    close_policy: str = "default"
    empty_policy: str = "close"
    header_left: QObject | None = None
    header_right: QObject | None = None
    header_content: QObject | None = None
    owner_context: WindowOwnerContext | None = None
    body_content: QObject | None = None


@dataclass(frozen=True)
class WindowCloseDecision:
    group_key: str
    accepted: bool
    policy: str = "default"


@dataclass(frozen=True)
class PageContext:
    group_key: str
    tab_key: str
    scope_key: str = "default"
    window_key: str = ""


@dataclass(frozen=True)
class WindowLifecycle:
    window_key: str
    group_key: str
    scope_key: str
    phase: str
    tab_keys: tuple[str, ...] = ()
    selected_key: str = ""
