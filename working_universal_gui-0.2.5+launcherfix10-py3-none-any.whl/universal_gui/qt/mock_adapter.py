from universal_gui.app_manager import AppManager
from universal_gui.contracts import Event, OperationIntent, OperationState, Request
from universal_gui.services.events import Subscription
from universal_gui.showcase_core.mock import MockCore


class MockAdapter:
    def __init__(self, router: AppManager) -> None:
        self._router = router
        self._states: dict[str, OperationState] = {}
        self._subscription = router.request(Request("events", "subscribe", Subscription("mock.state", self._receive)))
        capacity = router.request(Request("settings", "get", "showcase.mock_queue_capacity"))
        steps = router.request(Request("settings", "get", "showcase.mock_steps"))
        interval = router.request(Request("settings", "get", "showcase.mock_interval_ms"))
        self._core = MockCore(self._publish, capacity, steps, interval)

    def _publish(self, state: OperationState) -> None:
        self._router.request(Request("events", "publish", Event("mock.state", state)))

    def _receive(self, event: Event) -> None:
        self._states[event.payload.operation_id] = event.payload
        self._router.request(Request("events", "publish", Event("operations.changed", event.payload)))

    def handle(self, action: str, payload: object) -> object:
        if action == "submit" and isinstance(payload, OperationIntent):
            return self._core.submit(payload)
        if action == "snapshot":
            return tuple(self._states.values())
        raise ValueError(f"Invalid mock request: {action}")

    def close(self) -> None:
        self._core.close()
        self._router.request(Request("events", "unsubscribe", self._subscription))
