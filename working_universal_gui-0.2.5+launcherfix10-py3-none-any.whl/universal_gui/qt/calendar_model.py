from PySide6.QtCore import QDate, QLocale, QObject, Property, Signal, Slot


class CalendarModel(QObject):
    changed = Signal()
    selectionChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        today = QDate.currentDate()
        self._year = today.year()
        self._month = today.month()
        self._selected = ""
        self._available = []
        self._minimum = ""
        self._maximum = ""
        self._locale = QLocale()

    def get_days(self):
        first = QDate(self._year, self._month, 1)
        first = first.addDays(-((first.dayOfWeek() - int(self._locale.firstDayOfWeek().value)) % 7))
        available = frozenset(self._available)
        days = []
        for index in range(42):
            date = first.addDays(index)
            key = date.toString("yyyy-MM-dd")
            enabled = (not available or key in available) and (not self._minimum or key >= self._minimum) and (not self._maximum or key <= self._maximum)
            days.append({"date": key, "day": date.day(), "currentMonth": date.month() == self._month, "enabled": enabled, "selected": key == self._selected})
        return days

    @Slot(str, result=bool)
    def isAvailable(self, value):
        return QDate.fromString(value, "yyyy-MM-dd").isValid() and (not self._available or value in self._available) and (not self._minimum or value >= self._minimum) and (not self._maximum or value <= self._maximum)

    @Slot(str, result=bool)
    def selectDate(self, value):
        if not self.isAvailable(value):
            return False
        self.set_selected(value)
        return True

    @Slot(str)
    def showDate(self, value):
        date = QDate.fromString(value, "yyyy-MM-dd")
        if not date.isValid():
            raise ValueError("Date must be ISO yyyy-MM-dd")
        if (date.year(), date.month()) != (self._year, self._month):
            self._year, self._month = date.year(), date.month()
            self.changed.emit()

    @Slot(str, int, result=str)
    def moveDate(self, value, days):
        date = QDate.fromString(value, "yyyy-MM-dd")
        if not date.isValid():
            raise ValueError("Date must be ISO yyyy-MM-dd")
        return date.addDays(days).toString("yyyy-MM-dd")

    @Slot(int)
    def moveMonth(self, delta):
        date = QDate(self._year, self._month, 1).addMonths(delta)
        self._year, self._month = date.year(), date.month()
        self.changed.emit()

    def set_selected(self, value):
        if value and not QDate.fromString(value, "yyyy-MM-dd").isValid():
            raise ValueError("Date must be ISO yyyy-MM-dd")
        if value == self._selected:
            return
        self._selected = value
        self.selectionChanged.emit()
        self.changed.emit()

    def set_locale(self, value):
        self._locale = QLocale(value)
        self.changed.emit()

    selectedDate = Property(str, lambda self: self._selected, set_selected, notify=selectionChanged)
    availableDates = Property("QVariantList", lambda self: self._available, lambda self, value: self._set_dates(value), notify=changed)
    minimumDate = Property(str, lambda self: self._minimum, lambda self, value: self._set_range("_minimum", value), notify=changed)
    maximumDate = Property(str, lambda self: self._maximum, lambda self, value: self._set_range("_maximum", value), notify=changed)
    locale = Property(str, lambda self: self._locale.name(), set_locale, notify=changed)
    title = Property(str, lambda self: self._locale.toString(QDate(self._year, self._month, 1), "MMMM yyyy"), notify=changed)
    days = Property("QVariantList", get_days, notify=changed)
    displayedDate = Property(str, lambda self: QDate(self._year, self._month, 1).toString("yyyy-MM-dd"), notify=changed)
    today = Property(str, lambda self: QDate.currentDate().toString("yyyy-MM-dd"), constant=True)
    weekdays = Property("QVariantList", lambda self: [self._locale.dayName((int(self._locale.firstDayOfWeek().value) - 1 + index) % 7 + 1, QLocale.FormatType.ShortFormat) for index in range(7)], notify=changed)

    def _set_dates(self, values):
        if not all(isinstance(value, str) and QDate.fromString(value, "yyyy-MM-dd").isValid() for value in values):
            raise ValueError("Available dates must be ISO dates")
        self._available = list(values)
        self.changed.emit()

    def _set_range(self, name, value):
        if value and not QDate.fromString(value, "yyyy-MM-dd").isValid():
            raise ValueError("Date range must use ISO dates")
        minimum = value if name == "_minimum" else self._minimum
        maximum = value if name == "_maximum" else self._maximum
        if minimum and maximum and minimum > maximum:
            raise ValueError("Date minimum exceeds maximum")
        setattr(self, name, value)
        self.changed.emit()
