from copy import deepcopy
from weakref import ref

from PySide6.QtCore import Property, QSize, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QWindow
from PySide6.QtQuick import QQuickItem
from shiboken6 import isValid

from universal_gui.contracts import Event, Request
from universal_gui.qt.bridge import ComponentBridge
from universal_gui.qt.dock_contracts import DockDrop, DockGeometry, DockHover, DockPanel, DockRatio, DockSetup
from universal_gui.qt.workspace import TabAction, TabDefinition, TabGroup, TabInsert
from universal_gui.services.events import Subscription


class DockManager:
    def __init__(self, router):
        self._router = router
        self._layouts = {}
        self._subscriptions = {}
        self._preview = None
        self._saved = None
        self._serial = 0
        self._batch = False
        self._pending = set()
        self._disposed = False

    def _request(self, action, payload=None):
        return self._router.request(Request("workspace", action, payload))

    def _publish(self, key, preview=False):
        topic = "dock.preview." if preview else "dock.layout."
        self._router.request(Request("events", "publish", Event(topic + key, key)))

    def _split(self, first, second, edge, ratio=0.5):
        self._serial += 1
        children = (second, first) if edge in ("left", "top") else (first, second)
        return {"id": "split." + str(self._serial), "axis": "horizontal" if edge in ("left", "right") else "vertical", "ratio": ratio, "children": children}

    def _groups(self, node):
        if isinstance(node, str):
            return [node]
        return self._groups(node["children"][0]) + self._groups(node["children"][1]) if node else []

    def _subscribe(self, group):
        self._subscriptions[group] = self._router.request(Request("events", "subscribe", Subscription("tabs.changed." + group, self._on_tabs)))

    def _initial(self, key, panels, item, enabled):
        groups = [key + "." + area for area in ("left", "center", "right", "top", "bottom")]
        keys = [panel.key for panel in panels]
        if len(keys) != len(set(keys)) or any(not panel or panel in self._request("keys") for panel in keys):
            raise ValueError("Duplicate or empty dock panel key")
        if any(not panel.title_tag or not QUrl(panel.source).isLocalFile() for panel in panels):
            raise ValueError("Dock panel needs a title tag and a local QML source URL")
        if any(self._request("group", group) is not None for group in groups + [key + ".hidden"]):
            raise ValueError("Duplicate dock group key")
        for area, group in zip(("left", "center", "right", "top", "bottom"), groups):
            tabs = tuple(TabDefinition(panel.key, panel.title_tag, panel.source) for panel in panels if panel.area == area)
            self._request("register", TabGroup(group, tabs, enabled, "dock"))
            self._subscribe(group)
        layout = {"item": ref(item), "groups": groups, "tree": key + ".center", "enabled": enabled, "geometry": (0, 0, 0, 0), "rectangles": {}, "splits": []}
        layout["hidden"] = key + ".hidden"
        layout["closed"] = {}
        layout["panels"] = {panel.key for panel in panels}
        layout["animate"] = False
        layout["placements"] = {}
        self._request("register", TabGroup(layout["hidden"], (), True, "hidden"))
        self._layouts[key] = layout
        for area in ("left", "right", "top", "bottom"):
            group = key + "." + area
            if self._request("snapshot", group)[0]:
                layout["tree"] = self._split(layout["tree"], group, area, 0.75 if area in ("right", "bottom") else 0.25)
        self._reconcile(key)

    def _prune(self, node):
        if isinstance(node, str):
            return node if self._request("snapshot", node)[0] else None
        if node is None:
            return None
        first, second = (self._prune(child) for child in node["children"])
        if first is None or second is None:
            return first or second
        node["children"] = (first, second)
        return node

    def _reconcile(self, key):
        layout = self._layouts[key]
        for group in self._groups(layout["tree"]):
            if not self._request("snapshot", group)[0]:
                location = self._location(layout["tree"], group)
                if location is not None:
                    layout["placements"][group] = location
        tree = self._prune(layout["tree"])
        visible = self._groups(tree)
        for group in layout["groups"]:
            if self._request("snapshot", group)[0] and group not in visible:
                location = layout["placements"].get(group)
                if tree and location and location["anchor"] in self._node_keys(tree):
                    anchor = self._node(tree, location["anchor"])
                    tree = self._replace(tree, location["anchor"], self._split(anchor, group, location["edge"], location["ratio"]))
                else:
                    tree = self._split(tree, group, location["edge"] if location else "right") if tree else group
                visible.append(group)
        layout["tree"] = tree or key + ".center"
        self._compute(layout)

    def _compute(self, layout):
        width, height, gap, minimum = layout["geometry"]
        rectangles = {}
        splits = []

        def visit(node, x, y, w, h):
            if isinstance(node, str):
                rectangles[node] = {"x": x, "y": y, "width": w, "height": h}
                return
            horizontal = node["axis"] == "horizontal"
            span = max(0, (w if horizontal else h) - gap)
            lower = min(minimum, span / 2)
            first = max(lower, min(span - lower, span * node["ratio"]))
            second = span - first
            splits.append({"key": node["id"], "horizontal": horizontal, "x": x + first if horizontal else x, "y": y if horizontal else y + first, "width": gap if horizontal else w, "height": h if horizontal else gap, "origin": x if horizontal else y, "span": span})
            visit(node["children"][0], x, y, first if horizontal else w, h if horizontal else first)
            visit(node["children"][1], x + first + gap if horizontal else x, y if horizontal else y + first + gap, second if horizontal else w, h if horizontal else second)

        visit(layout["tree"], 0, 0, max(0, width), max(0, height))
        layout["rectangles"] = rectangles
        layout["splits"] = splits

    def _on_tabs(self, event):
        if self._batch or self._disposed:
            return
        group = event.payload
        for key, layout in self._layouts.items():
            if group in layout["groups"]:
                if not self._pending:
                    QTimer.singleShot(0, self._flush)
                self._pending.add(key)

    def _flush(self):
        pending = tuple(self._pending)
        self._pending.clear()
        for key in pending:
            if key in self._layouts:
                layout = self._layouts[key]
                previous = deepcopy(layout["tree"])
                self._reconcile(key)
                removed = self._compact(key)
                if previous != layout["tree"] or removed:
                    layout["animate"] = True
                    self._publish(key)


    def _commit_layout(self, key):
        self._reconcile(key)
        self._compact(key)
        self._layouts[key]["animate"] = True
        self._publish(key)

    def _compact(self, key):
        if self._saved is not None:
            return False
        layout = self._layouts[key]
        homes = self._request("home_groups")
        visible = self._groups(layout["tree"])
        removed = False
        for group in tuple(layout["groups"]):
            if ".group." in group and group not in homes and group not in visible and not self._request("snapshot", group)[0]:
                layout["groups"].remove(group)
                layout["placements"].pop(group, None)
                self._router.request(Request("events", "unsubscribe", self._subscriptions.pop(group)))
                self._request("unregister", group)
                removed = True
        return removed

    def _replace(self, node, target, replacement):
        if node == target or isinstance(node, dict) and node["id"] == target:
            return replacement
        if isinstance(node, dict):
            node["children"] = tuple(self._replace(child, target, replacement) for child in node["children"])
        return node

    def _node_keys(self, node):
        if isinstance(node, str):
            return [node]
        return [node["id"]] + self._node_keys(node["children"][0]) + self._node_keys(node["children"][1])

    def _node(self, node, key):
        if node == key or isinstance(node, dict) and node["id"] == key:
            return node
        if isinstance(node, dict):
            for child in node["children"]:
                if key in self._node_keys(child):
                    return self._node(child, key)
        return None

    def _location(self, node, group):
        if not isinstance(node, dict):
            return None
        for index, child in enumerate(node["children"]):
            if child == group:
                sibling = node["children"][1 - index]
                edge = ("left", "right") if node["axis"] == "horizontal" else ("top", "bottom")
                return {"anchor": sibling["id"] if isinstance(sibling, dict) else sibling, "edge": edge[index], "ratio": node["ratio"]}
            location = self._location(child, group)
            if location is not None:
                return location
        return None

    def _clear_preview(self):
        previous = self._preview
        self._preview = None
        if previous is not None:
            self._publish(previous["host"], True)

    def _hover(self, query):
        source = self._request("group", query.source)
        if source is None or source.kind == "ordinary" or not source.detachable:
            self._clear_preview()
            return False
        candidates = []
        for key, layout in self._layouts.items():
            item = layout["item"]()
            if not layout["enabled"] or item is None or not isValid(item) or not item.isVisible():
                continue
            window = item.window()
            if window is None or not window.isVisible() or window.visibility() == QWindow.Visibility.Minimized:
                continue
            local = item.mapFromGlobal(query.position)
            parent = item.parentItem()
            clipped = False
            while parent is not None:
                if parent.clip() and not parent.contains(parent.mapFromGlobal(query.position)):
                    clipped = True
                    break
                parent = parent.parentItem()
            if clipped:
                continue
            for group, rect in layout["rectangles"].items():
                target_group = self._request("group", group)
                if target_group is None or target_group.scope_key != source.scope_key:
                    continue
                x, y = local.x() - rect["x"], local.y() - rect["y"]
                w, h = rect["width"], rect["height"]
                if group == query.source or not 0 <= x < w or not 0 <= y < h:
                    continue
                distances = {"left": x / max(1, w), "right": 1 - x / max(1, w), "top": y / max(1, h), "bottom": 1 - y / max(1, h)}
                edge = min(distances, key=distances.get)
                if distances[edge] >= query.edge_ratio or not self._request("snapshot", group)[0]:
                    edge = "center"
                preview = dict(rect)
                if edge in ("left", "right"):
                    preview["width"] = w / 2
                    preview["x"] += w / 2 if edge == "right" else 0
                elif edge in ("top", "bottom"):
                    preview["height"] = h / 2
                    preview["y"] += h / 2 if edge == "bottom" else 0
                candidates.append((int(window.winId()), {"host": key, "target": group, "edge": edge, **preview}))
        if not candidates:
            self._clear_preview()
            return False
        handles = tuple(dict.fromkeys(handle for handle, preview in candidates))
        order = self._router.request(Request("platform_windows", "window_order", handles)) if len(handles) > 1 else handles
        preview = next(preview for handle, preview in candidates if handle == order[0])
        if preview != self._preview:
            old = self._preview
            self._preview = preview
            if old is not None and old["host"] != preview["host"]:
                self._publish(old["host"], True)
            self._publish(preview["host"], True)
        return True

    def _drop(self, request):
        preview = self._preview
        self._clear_preview()
        if preview is None:
            return False
        source = self._request("group", request.source)
        if source is None or source.kind == "ordinary" or not source.detachable:
            return False
        keys = {tab.key for tab in source.tabs}
        if not request.tabs or len(request.tabs) != len(set(request.tabs)) or not set(request.tabs) <= keys:
            raise ValueError("Dock drop needs distinct panels from its source group")
        layout = self._layouts[preview["host"]]
        target_group = self._request("group", preview["target"])
        if target_group is None or target_group.scope_key != source.scope_key:
            return False
        self._adopt(layout, request.tabs)
        target = preview["target"]
        self._batch = True
        try:
            if preview["edge"] != "center":
                candidate = preview["host"] + "." + preview["edge"]
                if candidate in layout["groups"] and not self._request("snapshot", candidate)[0] and candidate not in self._groups(layout["tree"]):
                    group = candidate
                else:
                    self._serial += 1
                    group = preview["host"] + ".group." + str(self._serial)
                    self._request("register", TabGroup(group, (), layout["enabled"], "dock"))
                    layout["groups"].append(group)
                    self._subscribe(group)
                layout["tree"] = self._replace(layout["tree"], target, self._split(target, group, preview["edge"]))
                target = group
            for key in request.tabs:
                self._request("move", TabAction(request.source, key, target))
                self._request("home_set", TabAction(target, key))
        finally:
            self._batch = False
        for host in self._layouts:
            self._reconcile(host)
            self._compact(host)
            self._layouts[host]["animate"] = True
            self._publish(host)
        return True

    def _adopt(self, target, panels):
        for layout in self._layouts.values():
            if layout is not target:
                layout["panels"].difference_update(panels)
                for panel in panels:
                    layout["closed"].pop(panel, None)
        target["panels"].update(panels)

    def handle(self, action, payload):
        if self._disposed:
            return None
        if action == "initialize" and isinstance(payload, DockSetup):
            if payload.key in self._layouts:
                raise ValueError("Duplicate dock host: " + payload.key)
            if any(panel.area not in ("left", "center", "right", "top", "bottom") for panel in payload.panels):
                raise ValueError("Unknown initial dock area")
            self._initial(payload.key, payload.panels, payload.item, payload.enabled)
            return None
        if action == "geometry" and isinstance(payload, DockGeometry):
            layout = self._layouts.get(payload.key)
            if layout is not None:
                geometry = (payload.width, payload.height, payload.gap, payload.minimum)
                if geometry != layout["geometry"]:
                    layout["geometry"] = geometry
                    layout["animate"] = False
                    self._compute(layout)
                    self._publish(payload.key)
            return None
        if action == "snapshot" and isinstance(payload, str):
            layout = self._layouts.get(payload)
            if layout is None:
                return {"panels": [], "splits": []}
            panels = [{"key": group, "modelVisible": group in layout["rectangles"], "animate": layout["animate"], **{"model" + name[0].upper() + name[1:]: value for name, value in layout["rectangles"].get(group, {"x": 0, "y": 0, "width": 0, "height": 0}).items()}} for group in layout["groups"]]
            return {"panels": panels, "splits": [{("model" + name[0].upper() + name[1:] if name in ("x", "y", "width", "height") else name): value for name, value in split.items()} for split in layout["splits"]]}
        if action == "floating_size" and isinstance(payload, str):
            for layout in self._layouts.values():
                if payload in layout["groups"]:
                    rectangle = layout["rectangles"].get(payload)
                    item = layout["item"]()
                    if rectangle and item is not None and isValid(item):
                        inset = item.property("floatingInset") or 0
                        title = item.property("floatingTitleHeight") or 0
                        return QSize(int(rectangle["width"] + inset * 2), int(rectangle["height"] + inset * 2 + title))
            return None
        if action == "preview" and isinstance(payload, str):
            return self._preview if self._preview and self._preview["host"] == payload else {}
        if action == "hover" and isinstance(payload, DockHover):
            return self._hover(payload)
        if action == "drop" and isinstance(payload, DockDrop):
            return self._drop(payload)
        if action == "settle" and isinstance(payload, DockDrop):
            for layout in self._layouts.values():
                if payload.source in layout["groups"]:
                    self._adopt(layout, payload.tabs)
                    for panel in payload.tabs:
                        self._request("home_set", TabAction(payload.source, panel))
                    return True
            return False
        if action == "clear_preview":
            self._clear_preview()
            return None
        if action == "begin":
            self._saved = {key: deepcopy(layout["tree"]) for key, layout in self._layouts.items()}
            return None
        if action in ("finish", "cancel"):
            self._clear_preview()
            if action == "cancel" and self._saved is not None:
                for key, tree in self._saved.items():
                    if key in self._layouts:
                        self._layouts[key]["tree"] = tree
                        self._reconcile(key)
                        self._publish(key)
            self._saved = None
            for key in self._layouts:
                if self._compact(key):
                    self._publish(key)
            return None
        if action == "ratio" and isinstance(payload, DockRatio):
            layout = self._layouts[payload.key]

            def update(node):
                if isinstance(node, dict):
                    if node["id"] == payload.split:
                        node["ratio"] = max(0.05, min(0.95, payload.ratio))
                    for child in node["children"]:
                        update(child)

            update(layout["tree"])
            layout["animate"] = False
            self._compute(layout)
            self._publish(payload.key)
            return None
        if action == "policy" and isinstance(payload, tuple):
            key, enabled = payload
            layout = self._layouts[key]
            layout["enabled"] = enabled
            for group in layout["groups"]:
                self._request("policy", TabGroup(group, (), enabled))
            if not enabled:
                self._clear_preview()
            return None
        if action == "hide_panel" and isinstance(payload, tuple):
            key, group, panel = payload
            layout = self._layouts[key]
            layout["closed"][panel] = group
            self._request("hide_panel", TabAction(group, panel, layout["hidden"]))
            self._commit_layout(key)
            return None
        if action == "hide_any" and isinstance(payload, tuple):
            group, panel = payload
            for key, layout in self._layouts.items():
                if panel in layout["panels"]:
                    home = self._request("home", panel)
                    layout["closed"][panel] = home if home in layout["groups"] else key + ".center"
                    self._request("hide_panel", TabAction(group, panel, layout["hidden"]))
                    self._commit_layout(key)
                    return None
            return False
        if action == "show_panel" and isinstance(payload, tuple):
            key, panel = payload
            layout = self._layouts[key]
            group = layout["closed"].get(panel)
            if group is None:
                return False
            self._request("restore_hidden", TabAction(layout["hidden"], panel, group))
            layout["closed"].pop(panel)
            self._commit_layout(key)
            return True
        if action == "add_panel" and isinstance(payload, tuple):
            key, panel = payload
            layout = self._layouts[key]
            if panel.area not in ("left", "center", "right", "top", "bottom"):
                raise ValueError("Unknown initial dock area")
            definition = TabDefinition(panel.key, panel.title_tag, panel.source)
            self._request("add", TabInsert(key + "." + panel.area, definition))
            self._adopt(layout, (panel.key,))
            self._commit_layout(key)
            return None
        if action == "remove_panel" and isinstance(payload, tuple):
            key, panel = payload
            layout = self._layouts[key]
            if panel not in layout["panels"]:
                return False
            group = self._request("find_group", panel)
            self._request("remove", TabAction(group, panel))
            layout["panels"].discard(panel)
            layout["closed"].pop(panel, None)
            self._commit_layout(key)
            return True
        if action == "release" and isinstance(payload, str):
            layout = self._layouts.pop(payload, None)
            self._pending.discard(payload)
            if layout is not None:
                self._clear_preview()
                for group in layout["groups"]:
                    self._router.request(Request("events", "unsubscribe", self._subscriptions.pop(group)))
                    self._request("unregister", group)
                self._request("unregister", layout["hidden"])
            return None
        if action == "dispose":
            self.close()
            return None
        raise ValueError("Invalid docking request: " + action)

    def close(self):
        for token in self._subscriptions.values():
            self._router.request(Request("events", "unsubscribe", token))
        self._subscriptions.clear()
        self._layouts.clear()
        self._preview = None
        self._saved = None
        self._pending.clear()
        self._disposed = True


class DockBridge(ComponentBridge):
    layoutChanged = Signal()
    previewChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._key = ""
        self._subscriptions = []

    def get_layout(self):
        return self.router.request(Request("docking", "snapshot", self._key)) if self._key else {"panels": [], "splits": []}

    layout = Property("QVariantMap", get_layout, notify=layoutChanged)
    preview = Property("QVariantMap", lambda self: self.router.request(Request("docking", "preview", self._key)) if self._key else {}, notify=previewChanged)

    def _on_layout(self, event):
        self.layoutChanged.emit()

    def _on_preview(self, event):
        self.previewChanged.emit()

    @Slot(str, "QVariantList", QQuickItem, bool)
    def initialize(self, key, model, item, enabled):
        panels = tuple(DockPanel(row["key"], row["titleTag"], str(row["source"]), row.get("area", "center")) for row in model)
        self.router.request(Request("docking", "initialize", DockSetup(key, panels, item, enabled)))
        self._key = key
        self._subscriptions.append(self.router.request(Request("events", "subscribe", Subscription("dock.layout." + key, self._on_layout))))
        self._subscriptions.append(self.router.request(Request("events", "subscribe", Subscription("dock.preview." + key, self._on_preview))))
        self.layoutChanged.emit()

    @Slot(float, float, float, float)
    def resize(self, width, height, gap, minimum):
        if self._key:
            self.router.request(Request("docking", "geometry", DockGeometry(self._key, width, height, gap, minimum)))

    @Slot(str, float)
    def setRatio(self, key, ratio):
        self.router.request(Request("docking", "ratio", DockRatio(self._key, key, ratio)))

    @Slot(bool)
    def setEnabled(self, enabled):
        if self._key:
            self.router.request(Request("docking", "policy", (self._key, enabled)))

    @Slot(str, str)
    def hidePanel(self, group, panel):
        self.router.request(Request("docking", "hide_panel", (self._key, group, panel)))

    @Slot(str, result=bool)
    def showPanel(self, panel):
        return self.router.request(Request("docking", "show_panel", (self._key, panel)))

    @Slot(str, str, str, str)
    def addPanel(self, key, title, source, area):
        self.router.request(Request("docking", "add_panel", (self._key, DockPanel(key, title, source, area))))

    @Slot(str, result=bool)
    def removePanel(self, key):
        return self.router.request(Request("docking", "remove_panel", (self._key, key)))

    @Slot()
    def release(self):
        for token in self._subscriptions:
            self.router.request(Request("events", "unsubscribe", token))
        self._subscriptions.clear()
        if self._key:
            self.router.request(Request("docking", "release", self._key))
            self._key = ""


class DockSurface(QQuickItem):
    pass
