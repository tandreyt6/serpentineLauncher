from PySide6.QtCore import QObject, Slot
from PySide6.QtQuick import QQuickItem


class DocumentViewport(QObject):
    @Slot(QQuickItem)
    def observe(self, item):
        if not isinstance(item, QQuickItem):
            raise TypeError("Expected a text presentation Item")
        item.setFlag(QQuickItem.Flag.ItemObservesViewport, True)
