import os

from PySide6.QtQuick import QQuickWindow


def configure_rendering(hardware_acceleration):
    os.environ['QSG_RENDER_LOOP'] = 'basic'
    QQuickWindow.setSceneGraphBackend('rhi' if hardware_acceleration else 'software')
    QQuickWindow.setTextRenderType(QQuickWindow.TextRenderType.QtTextRendering if hardware_acceleration else QQuickWindow.TextRenderType.NativeTextRendering)


def hardware_acceleration_enabled():
    return QQuickWindow.sceneGraphBackend() != 'software'
