from PySide6.QtCore import QObject, Slot
from PySide6.QtGui import QTextDocument


class DocumentLines(QObject):
    @Slot(QObject, int, int, int, result="QVariantList")
    def visibleLines(self, document, begin, end, maximum):
        if not isinstance(document, QTextDocument):
            raise TypeError("Expected QTextDocument")
        if maximum < 1:
            raise ValueError("Maximum visible lines must be positive")
        begin = max(0, min(begin, document.characterCount() - 1))
        end = max(begin, min(end, document.characterCount() - 1))
        first = document.findBlock(begin)
        last = document.findBlock(end)
        result = []
        block = first
        while block.isValid() and block.blockNumber() <= last.blockNumber() + 1 and len(result) < maximum:
            result.append({"number": block.blockNumber() + 1, "position": block.position()})
            block = block.next()
        return result
