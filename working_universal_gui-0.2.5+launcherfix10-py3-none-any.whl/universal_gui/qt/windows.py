from PySide6.QtCore import QObject, QUrl
from PySide6.QtQml import QQmlComponent, QQmlEngine
from PySide6.QtQuick import QQuickWindow
from shiboken6 import isValid
from pathlib import Path

from universal_gui.contracts import Diagnostic, Event, Request, WindowDefinition
from universal_gui.qt.window_contracts import WindowLifecycle, WindowOwnerContext
from universal_gui.qt.workspace import FloatingTab


class WindowManager:
    def __init__(self, engine: QQmlEngine, router=None) -> None:
        self._engine = engine
        self._router = router
        self._definitions: dict[str, str] = {}
        self._windows: dict[str, QQuickWindow] = {}
        self._window_serial = 0
        self._window_generations = {}
        self._opening = set()
        self._scene_root = Path(__file__).resolve().parents[1] / "qml"

    def _track_window(self, key, window):
        self._window_serial += 1
        generation = self._window_serial
        self._window_generations[key] = generation
        self._windows[key] = window
        window.destroyed.connect(lambda: self._window_destroyed(key, generation))

    def _window_destroyed(self, key, generation):
        if self._window_generations.get(key) == generation:
            self._window_generations.pop(key)
            self._windows.pop(key, None)

    def handle(self, action: str, payload: object) -> object:
        if action == "cancel_loading":
            # Leave window destruction to its engine, but cancel pending QML
            # construction while both the Loader and the engine are alive.
            for window in tuple(self._windows.values()):
                if not isValid(window):
                    continue
                for item in reversed(window.findChildren(QObject)):
                    if isValid(item) and item.inherits("QQuickLoader"):
                        item.setProperty("active", False)
            return None
        if action == "float_tab" and isinstance(payload, FloatingTab):
            key = "workspace/" + payload.group
            if key in self._windows:
                raise ValueError(f"Duplicate floating window: {payload.tab}")
            scene = self._scene_root / "Working/Gui/navigation/DetachedTabWindow.qml"
            component = QQmlComponent(self._engine, QUrl.fromLocalFile(str(scene)))
            properties = {"groupKey": payload.group, "tag": payload.title_tag, "dockPresentation": payload.dock, "scopeKey": payload.scope_key}
            for name, value in (("captionLeft", payload.options.header_left), ("captionRight", payload.options.header_right), ("captionComponent", payload.options.header_content)):
                if value is not None:
                    properties[name] = value
            owner = payload.options.owner_context or WindowOwnerContext(payload.group, payload.scope_key)
            properties.update(ownerContext={"key": owner.key, "scopeKey": owner.scope_key}, bodyComponent=payload.options.body_content)
            if payload.width and payload.height:
                properties.update(width=payload.width, height=payload.height)
            window = component.createWithInitialProperties(properties)
            if not isinstance(window, QQuickWindow):
                raise ValueError("\n".join(error.toString() for error in component.errors()))
            QObject.setParent(window, self._engine)
            component.setParent(window)
            self._track_window(key, window)
            window.show()
            window.raise_()
            window.requestActivate()
            return window
        if action == "floating_window" and isinstance(payload, str):
            return self._windows.get("workspace/" + payload)
        if action == "release_tab" and isinstance(payload, str):
            window = self._windows.pop("workspace/" + payload, None)
            if window is not None:
                if self._router is not None:
                    self._router.request(Request("events", "publish", Event("windows.lifecycle", WindowLifecycle("workspace/" + payload, payload, window.property("scopeKey"), "final-closed"))))
                window.hide()
                window.deleteLater()
            return None
        if action == "register" and isinstance(payload, WindowDefinition):
            if payload.key in self._definitions:
                raise ValueError(f"Duplicate window: {payload.key}")
            self._definitions[payload.key] = payload.scene
            return None
        if action == "floating_snapshot":
            return tuple(key for key in self._windows if key.startswith("workspace/"))
        if action == "instance" and isinstance(payload, str):
            return self._windows.get(payload)
        if action == "open" and isinstance(payload, str):
            if payload in self._windows:
                window = self._windows[payload]
                window.show()
                window.raise_()
                window.requestActivate()
                return None
            if payload in self._opening:
                raise RuntimeError(f"Recursive window creation: {payload}")
            self._opening.add(payload)
            try:
                self._record("windows.open_started", payload)
                component = QQmlComponent(self._engine, QUrl.fromLocalFile(self._definitions[payload]))
                self._record("windows.scene_ready", payload)
                window = component.create()
                self._record("windows.instance_ready", payload)
            finally:
                self._opening.discard(payload)
            if not isinstance(window, QQuickWindow):
                if window is not None:
                    window.deleteLater()
                detail = "\n".join(error.toString() for error in component.errors())
                component.deleteLater()
                raise ValueError("Window scene must create a Window: " + detail)
            QObject.setParent(window, self._engine)
            component.setParent(window)
            self._track_window(payload, window)
            window.show()
            window.raise_()
            window.requestActivate()
            return None
        if action == "scene_root" and isinstance(payload, Path):
            self._scene_root = payload
            return None
        if action == "configure" and isinstance(payload, WindowDefinition):
            if payload.key not in self._definitions or payload.key in self._windows:
                raise ValueError("Configure requires a registered, unopened window")
            self._definitions[payload.key] = payload.scene
            return None
        if action == "replace" and isinstance(payload, WindowDefinition):
            if payload.key not in self._definitions:
                raise KeyError(payload.key)
            component = QQmlComponent(self._engine, QUrl.fromLocalFile(payload.scene))
            candidate = component.createWithInitialProperties({"visible": False})
            if not isinstance(candidate, QQuickWindow):
                if candidate is not None:
                    candidate.deleteLater()
                detail = "\n".join(error.toString() for error in component.errors())
                component.deleteLater()
                raise ValueError("Replacement scene must create a Window: " + detail)
            previous = self._windows.get(payload.key)
            QObject.setParent(candidate, self._engine)
            component.setParent(candidate)
            if previous is not None:
                candidate.setGeometry(previous.geometry())
                candidate.setVisibility(previous.visibility())
            self._definitions[payload.key] = payload.scene
            self._track_window(payload.key, candidate)
            if previous is not None:
                previous.hide()
                previous.deleteLater()
            return candidate
        if action == "close":
            windows = [self._windows[payload]] if isinstance(payload, str) else self._windows.values()
            for window in windows:
                window.close()
            return None
        raise ValueError(f"Invalid window request: {action}")

    def _record(self, code, key):
        if self._router is not None:
            self._router.request(Request("diagnostics", "record", Diagnostic("INFO", code, key)))

    def close(self) -> None:
        self._windows.clear()
        self._window_generations.clear()
        self._definitions.clear()
        self._opening.clear()

