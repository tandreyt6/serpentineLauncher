from dataclasses import dataclass, replace
from weakref import ref
from uuid import uuid4

from PySide6.QtCore import QObject, QPointF, Property, QSize, QUrl, Signal, Slot
from PySide6.QtGui import QWindow
from PySide6.QtQml import QJSValue, QQmlComponent, QQmlContext, QQmlEngine, QQmlProperty
from PySide6.QtQuick import QQuickItem
from shiboken6 import isValid

from universal_gui.contracts import Event, Request, TextQuery
from universal_gui.qt.bridge import ComponentBridge
from universal_gui.qt.dock_contracts import DockDrop, DockHover
from universal_gui.qt.tab_drag import TabDragFilter, TabDragStart, TabHandle, TabTarget
from universal_gui.qt.window_contracts import FloatingWindowSpec, PageContext, WindowCloseDecision, WindowLifecycle, WindowOwnerContext
from universal_gui.services.events import Subscription


@dataclass(frozen=True)
class TabDefinition:
    key: str
    title_tag: str
    source: str


@dataclass(frozen=True)
class TabGroup:
    key: str
    tabs: tuple[TabDefinition, ...]
    detachable: bool
    kind: str = "detachable"
    scope_key: str = "default"
    floating: FloatingWindowSpec = FloatingWindowSpec()


@dataclass(frozen=True)
class TabAction:
    group: str
    tab: str
    target: str = ""
    index: int = -1


@dataclass(frozen=True)
class TabInsert:
    group: str
    definition: TabDefinition
    index: int = -1


@dataclass(frozen=True)
class TabPlacement:
    group: str
    tab: str
    host: QQuickItem


@dataclass(frozen=True)
class FloatingTab:
    group: str
    tab: str
    title_tag: str
    width: int = 0
    height: int = 0
    dock: bool = False
    scope_key: str = "default"
    options: FloatingWindowSpec = FloatingWindowSpec()


class WorkspaceManager:
    def __init__(self, router, engine: QQmlEngine) -> None:
        self._router = router
        self._engine = engine
        self._groups: dict[str, TabGroup] = {}
        self._selected: dict[str, str] = {}
        self._floating_groups: set[str] = set()
        self._pending_closes: set[str] = set()
        self._homes: dict[str, str] = {}
        self._pages: dict[str, QQuickItem] = {}
        self._components: dict[str, QQmlComponent] = {}
        self._page_contexts: dict[str, QQmlContext] = {}
        self._disposed = False
        self._targets: dict[int, tuple[str, object, bool, int]] = {}
        self._handles = {}
        self._drag_filter = TabDragFilter(router)
        self._drag = None
        self._capture_window = None

    def _notify(self, group: str) -> None:
        self._router.request(Request("events", "publish", Event(f"tabs.changed.{group}", group)))
        current = self._groups.get(group)
        if current is not None and group in self._floating_groups:
            phase = "composition" if current.tabs else "empty"
            self._router.request(Request("events", "publish", Event("windows.lifecycle", WindowLifecycle("workspace/" + group, group, current.scope_key, phase, tuple(tab.key for tab in current.tabs), self._selected[group]))))

    def _tab(self, group: str, key: str) -> TabDefinition:
        for tab in self._groups[group].tabs:
            if tab.key == key:
                return tab
        raise KeyError(f"Unknown tab: {key}")

    def _select_available(self, group: str) -> None:
        visible = [tab.key for tab in self._groups[group].tabs]
        if self._selected[group] not in visible:
            self._selected[group] = visible[0] if visible else ""

    def _park(self, page):
        page.setVisible(False)
        QQmlProperty(page, "anchors.fill").write(None)
        page.setParentItem(None)

    def handle(self, action: str, payload: object) -> object:
        if action == "dispose":
            self._disposed = True
            for page in self._pages.values():
                self._park(page)
                page.deleteLater()
            for component in self._components.values():
                component.deleteLater()
            self.close()
            return None
        if self._disposed:
            return ((), "") if action == "snapshot" else None
        if action == "register" and isinstance(payload, TabGroup):
            if not payload.scope_key:
                raise ValueError("Workspace scope must be nonempty")
            if payload.floating.close_policy not in ("default", "return-home", "hide", "request", "remove") or payload.floating.empty_policy not in ("close", "keep"):
                raise ValueError("Invalid floating window policy")
            if payload.floating.owner_context is not None and payload.floating.owner_context.scope_key != payload.scope_key:
                raise ValueError("Window owner context must use the group scope")
            if payload.key in self._groups:
                raise ValueError(f"Duplicate tab group: {payload.key}")
            keys = [tab.key for group in self._groups.values() for tab in group.tabs]
            for tab in payload.tabs:
                if not tab.key or tab.key in keys:
                    raise ValueError(f"Duplicate or empty tab key: {tab.key}")
                if not tab.title_tag or not QUrl(tab.source).isLocalFile():
                    raise ValueError("Tab needs a title tag and a local QML source URL")
                keys.append(tab.key)
            self._groups[payload.key] = payload
            self._homes.update({tab.key: payload.key for tab in payload.tabs})
            self._selected[payload.key] = payload.tabs[0].key if payload.tabs else ""
            return None
        if action == "snapshot" and isinstance(payload, str):
            group = self._groups.get(payload)
            return (group.tabs, self._selected[payload]) if group is not None else ((), "")
        if action == "group" and isinstance(payload, str):
            return self._groups.get(payload)
        if action == "context" and isinstance(payload, TabAction):
            group = self._groups[payload.group]
            self._tab(group.key, payload.tab)
            return PageContext(group.key, payload.tab, group.scope_key, "workspace/" + group.key if group.key in self._floating_groups else "")
        if action == "home" and isinstance(payload, str):
            return self._homes.get(payload, "")
        if action == "home_set" and isinstance(payload, TabAction):
            self._tab(payload.group, payload.tab)
            self._homes[payload.tab] = payload.group
            return None
        if action == "keys":
            return tuple(self._homes)
        if action == "home_groups":
            return frozenset(self._homes.values())
        if action == "find_group" and isinstance(payload, str):
            return self._find_group(payload)
        if action == "target" and isinstance(payload, TabTarget):
            self._targets[id(payload.item)] = (payload.group, ref(payload.item), payload.header, payload.priority)
            return None
        if action == "drag_handle" and isinstance(payload, TabHandle):
            self._handles[(payload.group, payload.tab, bool(payload.item.property("wholeGroup")))] = ref(payload.item)
            self._sync_drag_visual()
            return None
        if action == "drag_refresh":
            self._sync_drag_visual()
            return None
        if action == "drag_begin" and isinstance(payload, TabDragStart):
            return self._begin_drag(payload)
        if action == "drag_update" and isinstance(payload, QPointF):
            return self._update_drag(payload)
        if action in ("drag_finish", "drag_cancel"):
            return self._finish_drag(action == "drag_cancel")
        if action == "dragging":
            return self._drag_filter.active
        if action == "close_float" and isinstance(payload, str):
            return self._close_floating(payload)
        if action == "respond_close" and isinstance(payload, WindowCloseDecision):
            if payload.policy not in ("default", "return-home", "hide", "remove"):
                raise ValueError("Invalid confirmed close policy")
            if payload.group_key not in self._pending_closes:
                return False
            self._pending_closes.remove(payload.group_key)
            return self._apply_close(payload.group_key, payload.policy) if payload.accepted else True
        if action == "add" and isinstance(payload, TabInsert):
            group = self._groups[payload.group]
            tab = payload.definition
            if not tab.key or any(tab.key == existing.key for other in self._groups.values() for existing in other.tabs):
                raise ValueError(f"Duplicate or empty tab key: {tab.key}")
            if not tab.title_tag or not QUrl(tab.source).isLocalFile():
                raise ValueError("Tab needs a title tag and local QML source URL")
            tabs = list(group.tabs)
            tabs.insert(len(tabs) if payload.index < 0 else min(payload.index, len(tabs)), tab)
            self._groups[group.key] = replace(group, tabs=tuple(tabs))
            self._homes[tab.key] = group.key
            self._selected[group.key] = tab.key
            self._notify(group.key)
            return None
        if action == "remove" and isinstance(payload, TabAction):
            if self._drag is not None and self._drag["tab"] == payload.tab:
                self._finish_drag(False)
            group = self._groups[payload.group]
            self._tab(group.key, payload.tab)
            self._groups[group.key] = replace(group, tabs=tuple(tab for tab in group.tabs if tab.key != payload.tab))
            self._select_available(group.key)
            page = self._pages.pop(payload.tab, None)
            if page is not None:
                self._park(page)
                page.deleteLater()
            component = self._components.pop(payload.tab, None)
            self._page_contexts.pop(payload.tab, None)
            if component is not None:
                component.deleteLater()
            self._notify(group.key)
            self._homes.pop(payload.tab, None)
            for identity in tuple(self._handles):
                if identity[1] == payload.tab:
                    self._handles.pop(identity)
            self._clean_floating()
            return None
        if action == "policy" and isinstance(payload, TabGroup):
            current = self._groups[payload.key]
            if current.kind == "ordinary" and payload.detachable:
                raise ValueError("Ordinary tabs never detach")
            self._groups[payload.key] = replace(current, detachable=payload.detachable)
            return None
        if action == "select" and isinstance(payload, TabAction):
            self._tab(payload.group, payload.tab)
            if self._selected[payload.group] == payload.tab:
                return None
            self._selected[payload.group] = payload.tab
            self._notify(payload.group)
            return None
        if action == "detach" and isinstance(payload, TabAction):
            group = self._groups[payload.group]
            if group.kind == "ordinary" or not group.detachable:
                return False
            tab = self._tab(payload.group, payload.tab)
            if group.key in self._floating_groups and len(group.tabs) == 1:
                return False
            key = "floating/" + tab.key
            if key in self._groups:
                key += "/" + uuid4().hex
            self._groups[key] = TabGroup(key, (), True, group.kind, group.scope_key, group.floating)
            self._selected[key] = ""
            self._floating_groups.add(key)
            try:
                width = int(self._drag["size"].width()) if self._drag else 0
                height = int(self._drag["size"].height()) if self._drag else 0
                if self._drag is None and group.kind == "dock":
                    size = self._router.request(Request("docking", "floating_size", group.key))
                    if size is None:
                        handle = self._handles.get((group.key, tab.key, False))
                        item = handle() if handle is not None else None
                        size = self._dock_size(item)
                    if size is not None:
                        width, height = size.width(), size.height()
                self.handle("move", TabAction(group.key, tab.key, key))
                self._router.request(Request("windows", "float_tab", FloatingTab(key, tab.key, tab.title_tag, width, height, group.kind == "dock", group.scope_key, group.floating)))
            except Exception:
                self.handle("move", TabAction(key, tab.key, group.key))
                self._groups.pop(key, None)
                self._selected.pop(key, None)
                self._floating_groups.discard(key)
                raise
            return True
        if action == "reattach" and isinstance(payload, TabAction):
            current = self._find_group(payload.tab)
            if current not in self._floating_groups:
                return False
            return self.handle("return_home", TabAction(current, payload.tab, self._homes[payload.tab]))
        if action in ("move", "return_home", "restore_hidden", "hide_panel") and isinstance(payload, TabAction):
            source = self._groups[payload.group]
            target = self._groups[payload.target]
            if source.scope_key != target.scope_key:
                return False
            tab = self._tab(source.key, payload.tab)
            returning = action == "return_home" and target.key == self._homes.get(tab.key) or action == "restore_hidden" and source.kind == "hidden" or action == "hide_panel" and target.kind == "hidden"
            if action == "restore_hidden" and source.kind != "hidden":
                raise ValueError("Only a hidden panel can be restored")
            if action == "hide_panel" and target.kind != "hidden":
                raise ValueError("A hidden panel needs a parking group")
            if action == "return_home" and not returning:
                raise ValueError("Tab can only return to its own home group")
            if source.key != target.key and (source.kind == "ordinary" or target.kind == "ordinary" or not returning and (not source.detachable or not target.detachable)):
                return False
            if source.key == target.key and payload.index >= 0:
                current_index = next(index for index, item in enumerate(source.tabs) if item.key == tab.key)
                if current_index == min(payload.index, len(source.tabs) - 1):
                    return True
            source_tabs = tuple(item for item in source.tabs if item.key != tab.key)
            target_tabs = list(source_tabs if source.key == target.key else target.tabs)
            index = len(target_tabs) if payload.index < 0 else min(payload.index, len(target_tabs))
            target_tabs.insert(index, tab)
            self._groups[source.key] = replace(source, tabs=source_tabs)
            self._groups[target.key] = replace(target, tabs=tuple(target_tabs))
            self._selected[target.key] = tab.key
            self._select_available(source.key)
            self._notify(source.key)
            if target.key != source.key:
                for identity in tuple(self._handles):
                    if identity[:2] == (source.key, tab.key):
                        self._handles.pop(identity)
                self._notify(target.key)
            self._clean_floating()
            return True
        if action == "place" and isinstance(payload, TabPlacement):
            tab = self._tab(payload.group, payload.tab)
            page = self._pages.get(tab.key)
            context = self.handle("context", TabAction(payload.group, payload.tab))
            context_map = {"groupKey": context.group_key, "tabKey": context.tab_key, "scopeKey": context.scope_key, "windowKey": context.window_key}
            if page is None:
                component = QQmlComponent(self._engine, QUrl(tab.source))
                page_context = QQmlContext(self._engine.rootContext())
                page_context.setContextProperty("TabContext", context_map)
                page = component.create(page_context)
                if not isinstance(page, QQuickItem):
                    if page is not None:
                        page.deleteLater()
                    page_context.deleteLater()
                    raise ValueError("Tab source must create an Item: " + "\n".join(error.toString() for error in component.errors()))
                QObject.setParent(page, self._engine)
                page_context.setParent(page)
                self._page_contexts[tab.key] = page_context
                self._components[tab.key] = component
                self._pages[tab.key] = page
            if QQmlProperty(page, "pageContext").isValid():
                page.setProperty("pageContext", context_map)
            self._page_contexts[tab.key].setContextProperty("TabContext", context_map)
            for candidate in self._pages.values():
                if candidate.parentItem() is payload.host and candidate is not page:
                    self._park(candidate)
            QQmlProperty(page, "anchors.fill").write(None)
            page.setParentItem(payload.host)
            QQmlProperty(page, "anchors.fill").write(payload.host)
            page.setVisible(True)
            return None
        if action == "hide_host" and isinstance(payload, QQuickItem):
            for page in self._pages.values():
                if page.parentItem() is payload:
                    self._park(page)
            return None
        if action == "resize" and isinstance(payload, QQuickItem):
            for page in payload.childItems():
                page.setSize(payload.size())
            return None
        if action == "unregister" and isinstance(payload, str):
            if self._drag is not None and (self._drag["source"] == payload or self._find_group(self._drag["tab"]) == payload):
                self._finish_drag(False)
            group = self._groups.get(payload)
            if group is None:
                return None
            for tab in group.tabs:
                page = self._pages.pop(tab.key, None)
                if page is not None:
                    self._park(page)
                    page.deleteLater()
                component = self._components.pop(tab.key, None)
                self._page_contexts.pop(tab.key, None)
                if component is not None:
                    component.deleteLater()
                self._homes.pop(tab.key, None)
            self._groups.pop(payload)
            self._selected.pop(payload)
            for identity in tuple(self._handles):
                if identity[0] == payload:
                    self._handles.pop(identity)
            return None
        raise ValueError(f"Invalid workspace request: {action}")

    def _find_group(self, key):
        for group in self._groups.values():
            if any(tab.key == key for tab in group.tabs):
                return group.key
        raise KeyError(f"Unknown tab: {key}")

    def _set_capture(self, window, force=False):
        if self._capture_window is window and not force:
            return
        if self._capture_window is not window and self._capture_window is not None and isValid(self._capture_window):
            self._capture_window.setMouseGrabEnabled(False)
        self._capture_window = window
        if window is not None:
            window.setMouseGrabEnabled(True)

    def _begin_drag(self, request):
        self._finish_drag(False)
        group = self._groups[request.group]
        self._tab(group.key, request.tab)
        index = next(i for i, tab in enumerate(group.tabs) if tab.key == request.tab)
        size = request.item.window().size()
        if group.kind == "dock":
            size = self._dock_size(request.item) or size
        self._drag = {"tab": request.tab, "tabs": tuple(tab.key for tab in group.tabs) if request.whole_group else (request.tab,), "groupDrag": request.whole_group, "edgeRatio": request.edge_ratio, "source": group.key, "index": 0 if request.whole_group else index, "item": ref(request.item), "offset": request.offset, "grabRatio": request.offset.x() / max(1, request.item.width()), "position": request.position, "size": size}
        self._router.request(Request("docking", "begin"))
        request.item.setProperty("activeDrag", True)
        request.item.grabMouse()
        self._drag_filter.active = True
        self._set_capture(request.item.window())
        self._router.request(Request("events", "publish", Event("workspace.drag.changed", True)))
        self._update_drag(request.position)
        return True

    def _dock_size(self, item):
        if item is None or not isValid(item):
            return None
        width = item.property("floatingWidth")
        height = item.property("floatingHeight")
        return QSize(int(width), int(height)) if width and height else None

    def _sync_drag_visual(self):
        if self._drag is None:
            return
        key = self._drag["tab"]
        group = self._find_group(key)
        weak_item = self._handles.get((group, key, self._drag["groupDrag"]))
        item = weak_item() if weak_item is not None else None
        if item is None or not isValid(item):
            return
        previous = self._drag["item"]()
        if previous is not item:
            if previous is not None and isValid(previous):
                previous.ungrabMouse()
                previous.setProperty("activeDrag", False)
                previous.setProperty("dragOffset", 0)
            self._drag["item"] = ref(item)
            item.setProperty("activeDrag", True)
            item.grabMouse()
            self._set_capture(item.window(), True)
        if self._drag["groupDrag"]:
            return
        for target_group, weak_header, header, priority in self._targets.values():
            strip = weak_header()
            if target_group == group and header and strip is not None and isValid(strip):
                local = strip.mapFromGlobal(self._drag["position"])
                offset = local.x() + float(strip.property("scrollOffset")) - item.width() * self._drag["grabRatio"] - float(item.property("slotX"))
                item.setProperty("dragOffset", 0 if group in self._floating_groups and len(self._groups[group].tabs) == 1 else offset)
                break

    def _target_at(self, position, current):
        candidates = []
        stale = []
        for token, (group, weak_item, header, priority) in self._targets.items():
            item = weak_item()
            if item is None or not isValid(item):
                stale.append(token)
                continue
            if group not in self._groups or not item.isVisible() or item.width() <= 0 or item.height() <= 0:
                continue
            if header and group == current and self._drag["groupDrag"] and not item.property("groupCaption"):
                continue
            window = item.window()
            if window is None or not window.isVisible() or window.visibility() == QWindow.Visibility.Minimized:
                continue
            local = item.mapFromGlobal(position)
            sticky = header and group == current
            tolerance = float(item.property("detachDistance") or 0) if sticky else 0
            if sticky:
                inside = -tolerance <= local.x() < item.width() + tolerance and abs(local.y() - item.height() / 2) <= max(item.height() / 2, tolerance)
            else:
                inside = 0 <= local.x() < item.width() and 0 <= local.y() < item.height()
            if not inside:
                continue
            if group == current and not header:
                continue
            parent = item.parentItem()
            clipped = False
            probe = item.mapToGlobal(QPointF(max(0, min(item.width() - 1, local.x())), max(0, min(item.height() - 1, local.y())))) if sticky else position
            while parent is not None:
                if parent.clip() and not parent.contains(parent.mapFromGlobal(probe)):
                    clipped = True
                    break
                parent = parent.parentItem()
            if clipped:
                continue
            target = self._groups[group]
            source = self._groups[current]
            if target.scope_key != source.scope_key:
                continue
            if group != current and (source.kind == "ordinary" or target.kind == "ordinary" or not source.detachable or not target.detachable):
                continue
            rank = (header and group != current, group != current if current in self._floating_groups else False, int(window.winId()), priority + (3 if header else 0))
            candidates.append((rank, group, item, header, local))
        for token in stale:
            self._targets.pop(token)
        handles = tuple(dict.fromkeys(candidate[0][2] for candidate in candidates))
        order = self._router.request(Request("platform_windows", "window_order", handles)) if len(handles) > 1 else handles
        ranks = {handle: len(order) - index for index, handle in enumerate(order)}
        candidates = [((rank[1], ranks.get(rank[2], 0), rank[0], rank[3]), group, item, header, local) for rank, group, item, header, local in candidates]
        return max(candidates, key=lambda candidate: candidate[0]) if candidates else None

    def _update_drag(self, position):
        if self._drag is None:
            return
        self._drag["position"] = position
        key = self._drag["tab"]
        current = self._find_group(key)
        hit = self._target_at(position, current)
        if hit is not None and hit[1] == current and current in self._floating_groups and (len(self._groups[current].tabs) == 1 or self._drag["groupDrag"]):
            hit = None
        sticky = hit is not None and hit[1] == current and hit[3]
        if not sticky:
            if self._router.request(Request("docking", "hover", DockHover(position, current, self._drag["edgeRatio"]))):
                if hit is None or not hit[3]:
                    self._move_floating(position, current)
                    return
        else:
            self._router.request(Request("docking", "clear_preview"))
        if hit is not None:
            rank, target, item, header, local = hit
            if header:
                self._router.request(Request("docking", "clear_preview"))
                stride = float(item.property("tabStride"))
                content_x = float(item.property("scrollOffset"))
                geometry = item.property("tabGeometry")
                if isinstance(geometry, QJSValue):
                    geometry = geometry.toVariant()
                width = next((bounds["width"] for bounds in geometry if bounds["key"] == key), float(item.property("tabWidth"))) if geometry else float(item.property("tabWidth"))
                center = local.x() + content_x - width * self._drag["grabRatio"] + width / 2 if target == current else local.x() + content_x
                index = next((offset for offset, bounds in enumerate(geometry) if center < bounds["x"] + bounds["width"]), len(geometry) - 1) if geometry else max(0, int(center / stride))
            else:
                index = -1
            if target != current or header:
                self._move_drag_tabs(current, target, index)
                self._set_capture(item.window())
                self._clean_floating(True)
            self._sync_drag_visual()
            return
        group = self._groups[current]
        if group.kind == "ordinary" or not group.detachable:
            return
        if current not in self._floating_groups or len(group.tabs) > len(self._drag["tabs"]):
            self.handle("detach", TabAction(current, key))
            floating_group = self._find_group(key)
            for index, sibling in enumerate(self._drag["tabs"]):
                self.handle("move", TabAction(self._find_group(sibling), sibling, floating_group, index))
            self.handle("select", TabAction(floating_group, key))
            current = floating_group
        self._move_floating(position, current)

    def _move_drag_tabs(self, source, target, index=-1):
        if self._drag["groupDrag"] and source == target:
            return
        for offset, key in enumerate(self._drag["tabs"]):
            self.handle("move", TabAction(source, key, target, index + offset if index >= 0 else -1))

    def _move_floating(self, position, current):
        window = self._router.request(Request("windows", "floating_window", current))
        if window is not None:
            self._set_capture(window)
            offset = self._drag["offset"]
            item = self._drag["item"]()
            if item is not None and isValid(item) and item.window() is window:
                origin = item.mapToScene(QPointF(0, 0))
            else:
                style = window.property("appearance")
                if isinstance(style, QJSValue):
                    style = style.toVariant()
                origin = QPointF(float(window.property("frameInset") or 0), float(style["titlebarHeight"]) + float(window.property("frameInset") or 0))
            grab_x = item.width() * self._drag["grabRatio"] if item is not None and isValid(item) and item.window() is window else offset.x()
            window.setPosition(int(position.x() - grab_x - origin.x()), int(position.y() - offset.y() - origin.y()))
            self._sync_drag_visual()

    def _finish_drag(self, cancel):
        if self._drag is None:
            return
        drag = self._drag
        if not cancel:
            current = self._find_group(drag["tab"])
            accepted = self._router.request(Request("docking", "drop", DockDrop(current, drag["tabs"])))
            if not accepted:
                self._router.request(Request("docking", "settle", DockDrop(current, drag["tabs"])))
        self._drag_filter.active = False
        self._set_capture(None)
        self._drag = None
        original = drag["item"]()
        if original is not None and isValid(original):
            original.ungrabMouse()
            original.setProperty("activeDrag", False)
            original.setProperty("dragOffset", 0)
        if cancel and drag["source"] in self._groups:
            current = self._find_group(drag["tab"])
            if drag["source"] in self._floating_groups:
                window = self._router.request(Request("windows", "floating_window", drag["source"]))
                window.show()
            for offset, key in enumerate(drag["tabs"]):
                self.handle("move", TabAction(self._find_group(key), key, drag["source"], drag["index"] + offset))
        self._router.request(Request("docking", "cancel" if cancel else "finish"))
        self._clean_floating(True)
        self._router.request(Request("events", "publish", Event("workspace.drag.changed", False)))

    def _clean_floating(self, during_drag=False):
        if self._drag is not None and not during_drag:
            return
        for key in tuple(self._floating_groups):
            if not self._groups[key].tabs and self._groups[key].floating.empty_policy == "close":
                if self._drag is not None and key == self._drag["source"]:
                    window = self._router.request(Request("windows", "floating_window", key))
                    if window is not self._capture_window and window is not None:
                        window.hide()
                    continue
                self._router.request(Request("windows", "release_tab", key))
                self._floating_groups.remove(key)
                self._pending_closes.discard(key)
                self._groups.pop(key)
                self._selected.pop(key)
                for identity in tuple(self._handles):
                    if identity[0] == key:
                        self._handles.pop(identity)

    def _close_floating(self, key):
        if key not in self._floating_groups or key in self._pending_closes:
            return False
        group = self._groups[key]
        if group.floating.close_policy == "request":
            self._pending_closes.add(key)
        self._router.request(Request("events", "publish", Event("windows.lifecycle", WindowLifecycle("workspace/" + key, key, group.scope_key, "request-close", tuple(tab.key for tab in group.tabs), self._selected[key]))))
        if group.floating.close_policy == "request":
            return False
        return self._apply_close(key, group.floating.close_policy)

    def _apply_close(self, key, policy):
        if key not in self._floating_groups:
            return False
        group = self._groups[key]
        if policy == "hide":
            window = self._router.request(Request("windows", "floating_window", key))
            if window is not None:
                window.hide()
            return True
        if policy == "remove":
            for tab in tuple(group.tabs):
                self.handle("remove", TabAction(key, tab.key))
            return True
        if policy == "default" and group.kind == "dock":
            for tab in tuple(self._groups[key].tabs):
                self._router.request(Request("docking", "hide_any", (key, tab.key)))
            window = self._router.request(Request("windows", "floating_window", key))
            if window is not None:
                window.hide()
            return True
        for tab in tuple(self._groups[key].tabs):
            home = self._homes.get(tab.key)
            if home in self._groups:
                self.handle("return_home", TabAction(key, tab.key, home))
            else:
                self.handle("remove", TabAction(key, tab.key))
        return True

    def close(self) -> None:
        self._page_contexts.clear()
        self._groups.clear()
        self._selected.clear()
        self._drag_filter.close()
        self._set_capture(None)
        self._drag = None
        self._floating_groups.clear()
        self._pending_closes.clear()
        self._homes.clear()
        self._targets.clear()
        self._handles.clear()
        self._pages.clear()
        self._components.clear()


class WorkspaceBridge(ComponentBridge):
    workspaceChanged = Signal()
    dragStateChanged = Signal()
    interactionChanged = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._group = ""
        self._owns_group = False
        self._workspace_subscription = ""
        self._drag_subscription = ""
        self._can_detach = False
        self._scope_key = "default"
        self._close_policy = "default"
        self._empty_policy = "close"
        self._header_left = None
        self._header_right = None
        self._header_content = None
        self._body_content = None
        self._owner_key = ""

    def set_scope_key(self, value):
        if self._group and value != self._scope_key:
            raise ValueError("Scope is immutable after group initialization")
        self._scope_key = value
        self.workspaceChanged.emit()

    scopeKey = Property(str, lambda self: self._scope_key, set_scope_key, notify=workspaceChanged)
    floatingClosePolicy = Property(str, lambda self: self._close_policy, lambda self, value: setattr(self, "_close_policy", value), notify=workspaceChanged)
    floatingEmptyPolicy = Property(str, lambda self: self._empty_policy, lambda self, value: setattr(self, "_empty_policy", value), notify=workspaceChanged)
    floatingHeaderLeft = Property(QObject, lambda self: self._header_left, lambda self, value: setattr(self, "_header_left", value), notify=workspaceChanged)
    floatingHeaderRight = Property(QObject, lambda self: self._header_right, lambda self, value: setattr(self, "_header_right", value), notify=workspaceChanged)
    floatingHeaderContent = Property(QObject, lambda self: self._header_content, lambda self, value: setattr(self, "_header_content", value), notify=workspaceChanged)
    floatingBodyContent = Property(QObject, lambda self: self._body_content, lambda self, value: setattr(self, "_body_content", value), notify=workspaceChanged)
    ownerContextKey = Property(str, lambda self: self._owner_key, lambda self, value: setattr(self, "_owner_key", value), notify=workspaceChanged)

    groupKey = Property(str, lambda self: self._group, notify=workspaceChanged)
    detachDistance = Property(float, lambda self: self.router.request(Request("settings", "get", "workspace.detach_distance")), notify=interactionChanged)
    dragging = Property(bool, lambda self: bool(self.router.request(Request("workspace", "dragging"))), notify=dragStateChanged)

    def get_entries(self) -> list[dict]:
        if not self._group:
            return []
        tabs, selected = self.router.request(Request("workspace", "snapshot", self._group))
        return [{"key": tab.key, "title": self.router.request(Request("localization", "text", TextQuery(tab.title_tag))), "titleTag": tab.title_tag, "selected": tab.key == selected} for tab in tabs]

    entries = Property("QVariantList", get_entries, notify=workspaceChanged)
    currentKey = Property(str, lambda self: self.router.request(Request("workspace", "snapshot", self._group))[1] if self._group else "", notify=workspaceChanged)

    @Slot(str, "QVariantList", bool, bool)
    def initialize(self, key: str, model: list[dict], detachable: bool, existing: bool) -> None:
        if self._group:
            raise RuntimeError("Tab group is immutable after initialization")
        if not existing:
            tabs = tuple(TabDefinition(row["key"], row["titleTag"], row["source"].toString() if isinstance(row["source"], QUrl) else str(row["source"])) for row in model)
            kind = "ordinary" if self._component_type == "Tabs" else "dock" if self._component_type == "DockWindow" else "detachable"
            owner = WindowOwnerContext(self._owner_key or key, self._scope_key)
            options = FloatingWindowSpec(self._close_policy, self._empty_policy, self._header_left, self._header_right, self._header_content, owner, self._body_content)
            self.router.request(Request("workspace", "register", TabGroup(key, tabs, detachable, kind, self._scope_key, options)))
        else:
            group = self.router.request(Request("workspace", "group", key))
            if group is not None:
                self._scope_key = group.scope_key
        self._group = key
        self._owns_group = not existing
        self._can_detach = self._component_type in ("DetachableTabs", "DockWindow")
        self._workspace_subscription = self.router.request(Request("events", "subscribe", Subscription(f"tabs.changed.{key}", self._on_workspace)))
        self._drag_subscription = self.router.request(Request("events", "subscribe", Subscription("workspace.drag.changed", self._on_drag)))
        self.workspaceChanged.emit()

    def _on_drag(self, event):
        self.dragStateChanged.emit()

    def _on_workspace(self, event: Event) -> None:
        self.workspaceChanged.emit()
        self.refreshDrag()

    @Slot()
    def refreshDrag(self):
        self.router.request(Request("workspace", "drag_refresh"))

    def _on_event(self, event: Event) -> None:
        super()._on_event(event)
        if event.topic == "locale.changed":
            self.workspaceChanged.emit()
        if event.topic == "settings.changed" and event.payload.key.startswith("workspace."):
            self.interactionChanged.emit()

    @Slot(bool)
    def setDetachable(self, value: bool) -> None:
        if self._group and self._can_detach:
            self.router.request(Request("workspace", "policy", TabGroup(self._group, (), value)))

    @Slot(str)
    def removeTab(self, key: str) -> None:
        self.router.request(Request("workspace", "remove", TabAction(self._group, key)))

    @Slot(str, str, str)
    def addTab(self, key: str, title_tag: str, source: str) -> None:
        self.router.request(Request("workspace", "add", TabInsert(self._group, TabDefinition(key, title_tag, source))))

    @Slot(str)
    def selectTab(self, key: str) -> None:
        self.router.request(Request("workspace", "select", TabAction(self._group, key)))

    @Slot(str, result=bool)
    def detachTab(self, key: str) -> bool:
        return self.router.request(Request("workspace", "detach", TabAction(self._group, key)))

    @Slot(str, result=bool)
    def reattachTab(self, key: str) -> bool:
        return self.router.request(Request("workspace", "reattach", TabAction(self._group, key)))

    @Slot(str, str, int, result=bool)
    def moveTab(self, key: str, target: str, index: int) -> bool:
        return self.router.request(Request("workspace", "move", TabAction(self._group, key, target, index)))

    @Slot(str, str, int, result=bool)
    def moveFrom(self, source: str, key: str, index: int) -> bool:
        return self.router.request(Request("workspace", "move", TabAction(source, key, self._group, index)))

    @Slot(str, QObject, float, float, float, float, result=bool)
    def beginDrag(self, key, item, x, y, offset_x, offset_y):
        edge_ratio = self.router.request(Request("settings", "get", "workspace.dock_edge_ratio"))
        return self.router.request(Request("workspace", "drag_begin", TabDragStart(self._group, key, item, item.mapToGlobal(QPointF(x, y)), QPointF(offset_x, offset_y), False, edge_ratio)))

    @Slot(QObject, float, float, float, float, result=bool)
    def beginGroupDrag(self, item, x, y, offset_x, offset_y):
        key = self.router.request(Request("workspace", "snapshot", self._group))[1]
        if not key:
            return False
        edge_ratio = self.router.request(Request("settings", "get", "workspace.dock_edge_ratio"))
        return self.router.request(Request("workspace", "drag_begin", TabDragStart(self._group, key, item, item.mapToGlobal(QPointF(x, y)), QPointF(offset_x, offset_y), True, edge_ratio)))

    @Slot()
    def closeFloatingGroup(self):
        self.router.request(Request("workspace", "close_float", self._group))

    @Slot(bool, str, result=bool)
    def respondClose(self, accepted, policy):
        return self.router.request(Request("workspace", "respond_close", WindowCloseDecision(self._group, accepted, policy)))

    @Slot(str)
    def hideDockPanel(self, key):
        self.router.request(Request("docking", "hide_any", (self._group, key)))

    @Slot()
    def releaseGroup(self) -> None:
        if self._drag_subscription:
            self.router.request(Request("events", "unsubscribe", self._drag_subscription))
            self._drag_subscription = ""
        if self._workspace_subscription:
            self.router.request(Request("events", "unsubscribe", self._workspace_subscription))
            self._workspace_subscription = ""
        if self._owns_group:
            self.router.request(Request("workspace", "unregister", self._group))
        self._group = ""
        self._owns_group = False


class TabContentHost(QQuickItem):
    router = None
    selectionChanged = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._group = ""
        self._tab = ""
        self._ready = False

    def set_group(self, value: str) -> None:
        if value == self._group:
            return
        self._group = value
        self.selectionChanged.emit()
        self._place()

    def set_tab(self, value: str) -> None:
        if value == self._tab:
            return
        self._tab = value
        self.selectionChanged.emit()
        self._place()

    groupKey = Property(str, lambda self: self._group, set_group, notify=selectionChanged)
    tabKey = Property(str, lambda self: self._tab, set_tab, notify=selectionChanged)

    def componentComplete(self) -> None:
        super().componentComplete()
        self._ready = True
        self._place()

    @Slot()
    def refreshPlacement(self):
        if self._ready and self._group:
            selected = self.router.request(Request("workspace", "snapshot", self._group))[1]
            if selected != self._tab:
                self._tab = selected
                self.selectionChanged.emit()
            self._place()

    def _place(self) -> None:
        if not self._ready:
            return
        if self._group and self._tab:
            self.router.request(Request("workspace", "place", TabPlacement(self._group, self._tab, self)))
        else:
            self.router.request(Request("workspace", "hide_host", self))
