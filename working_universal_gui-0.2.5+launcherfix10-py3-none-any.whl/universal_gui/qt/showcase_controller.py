from uuid import uuid4

from PySide6.QtCore import QObject, Property, QTimer, Signal, Slot

from universal_gui.app_manager import AppManager
from universal_gui.contracts import AppearanceQuery, Diagnostic, Event, OperationIntent, Request, SettingChange, TextQuery
from universal_gui.services.events import Subscription


class ShowcaseController(QObject):
    changed = Signal()
    styleChanged = Signal()
    diagnosticsChanged = Signal()
    recreateRequested = Signal()

    def __init__(self, router: AppManager) -> None:
        super().__init__()
        self._router = router
        self._style = router.request(Request("themes", "appearance", AppearanceQuery("ShowcaseShell", "showcase.shell")))[0]
        self._diagnostics = ""
        self._receipt = None
        self._subscriptions = []
        for topic in ("theme.changed", "locale.changed", "settings.changed", "operations.changed"):
            self._subscriptions.append(router.request(Request("events", "subscribe", Subscription(topic, self._on_event))))
        self._timer = QTimer(self)
        self._timer.setInterval(router.request(Request("settings", "get", "showcase.diagnostics_interval_ms")))
        self._timer.timeout.connect(self.refresh_diagnostics)
        self._timer.start()

    def _on_event(self, event: Event) -> None:
        if event.topic == "theme.changed":
            self._style = self._router.request(Request("themes", "appearance", AppearanceQuery("ShowcaseShell", "showcase.shell")))[0]
            self.styleChanged.emit()
        if event.topic == "settings.changed":
            change = event.payload
            if change.key == "showcase.diagnostics_interval_ms":
                self._timer.setInterval(change.value)
        self.changed.emit()

    style = Property("QVariantMap", lambda self: self._style.copy(), notify=styleChanged)
    theme = Property(str, lambda self: self._router.request(Request("themes", "current")), notify=changed)
    locale = Property(str, lambda self: self._router.request(Request("localization", "current")), notify=changed)
    reducedMotion = Property(bool, lambda self: self._router.request(Request("settings", "get", "motion.reduced")), notify=changed)
    geometry = Property(bool, lambda self: self._router.request(Request("settings", "get", "diagnostics.geometry")), notify=changed)
    listCount = Property(int, lambda self: self._router.request(Request("settings", "get", "showcase.list_count")), notify=changed)
    diagnostics = Property(str, lambda self: self._diagnostics, notify=diagnosticsChanged)

    def get_operations(self) -> list[dict]:
        states = self._router.request(Request("mock", "snapshot"))
        return [{"operationId": state.operation_id, "requestId": state.request_id, "status": self._router.request(Request("localization", "text", TextQuery(f"operation.{state.status}"))), "progress": state.progress, "text": state.text} for state in states]

    operations = Property("QVariantList", get_operations, notify=changed)

    def get_receipt_text(self) -> str:
        if self._receipt is not None and not self._receipt.accepted:
            return self._router.request(Request("localization", "text", TextQuery(f"operation.{self._receipt.reason}")))
        if not self.get_operations():
            return self._router.request(Request("localization", "text", TextQuery("showcase.operation.empty")))
        return ""

    receiptText = Property(str, get_receipt_text, notify=changed)

    @Slot()
    def cycleTheme(self) -> None:
        themes = self._router.request(Request("themes", "available"))
        current = themes.index(self._router.request(Request("themes", "current")))
        self._router.request(Request("themes", "select", themes[(current + 1) % len(themes)]))

    @Slot()
    def cycleLocale(self) -> None:
        locales = self._router.request(Request("localization", "available"))
        current = locales.index(self._router.request(Request("localization", "current")))
        self._router.request(Request("localization", "select", locales[(current + 1) % len(locales)]))

    @Slot()
    def toggleMotion(self) -> None:
        self._router.request(Request("settings", "set", SettingChange("motion.reduced", not self.reducedMotion)))

    @Slot()
    def toggleGeometry(self) -> None:
        self._router.request(Request("settings", "set", SettingChange("diagnostics.geometry", not self.geometry)))

    @Slot(str)
    def submit(self, text: str) -> None:
        self._receipt = self._router.request(Request("mock", "submit", OperationIntent(uuid4().hex, text)))
        self.changed.emit()

    @Slot()
    def recreate(self) -> None:
        self.recreateRequested.emit()

    @Slot()
    def openWindow(self) -> None:
        self._router.request(Request("windows", "open", "showcase.secondary"))

    @Slot()
    def openGallery(self) -> None:
        self._router.request(Request("windows", "open", "showcase.gallery"))

    @Slot()
    def openDocking(self) -> None:
        self._router.request(Request("windows", "open", "showcase.docking"))

    @Slot()
    def closeWindow(self) -> None:
        self._router.request(Request("windows", "close", "showcase.secondary"))

    @Slot()
    def checkMissing(self) -> None:
        key = "showcase.translation.intentionally_missing"
        text = self._router.request(Request("localization", "text", TextQuery(key)))
        self._router.request(Request("diagnostics", "record", Diagnostic("INFO", "showcase.missing_key", text)))
        self.refresh_diagnostics()

    @Slot()
    def refresh_diagnostics(self) -> None:
        registry = self._router.request(Request("registry", "snapshot"))
        resources = self._router.request(Request("resources", "stats"))
        subscriptions = self._router.request(Request("events", "count"))
        visuals = self._router.request(Request("visuals", "count"))
        entries = self._router.request(Request("diagnostics", "snapshot"))
        self._diagnostics = f"runtime=active | theme={self.theme} | locale={self.locale}\ncomponents={len(registry)} | subscriptions={subscriptions} | compiledVisuals={visuals}\n{resources}\n" + "\n".join(entries[-8:])
        self.diagnosticsChanged.emit()

    def close(self) -> None:
        self._timer.stop()
        for token in self._subscriptions:
            self._router.request(Request("events", "unsubscribe", token))
        self._subscriptions.clear()
