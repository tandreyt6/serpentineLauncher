from PySide6.QtCore import QObject, Property, Signal, Slot
from PySide6.QtQml import QQmlProperty, qmlEngine
from PySide6.QtQuick import QQuickItem


class DelegateHost(QQuickItem):
    sourceChanged = Signal()
    contextChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._source = None
        self._context = {}
        self._item = None
        self._ready = False
        self._state_store = None

    def set_source(self, source):
        if source is self._source:
            return
        self._source = source
        self.sourceChanged.emit()
        self._build()

    def set_context(self, context):
        changed_key = context.get("key") != self._context.get("key")
        if changed_key:
            self.remember()
        self._context = dict(context)
        if self._item is not None:
            self._item.setProperty("collectionContext", self._context)
            if changed_key:
                self._restore()
        self.contextChanged.emit()

    def componentComplete(self):
        super().componentComplete()
        self._ready = True
        self._build()

    def _build(self):
        if not self._ready or self._source is None:
            return
        if self._item is not None:
            self._item.setVisible(False)
            self._item.deleteLater()
        item = self._source.createWithInitialProperties({"collectionContext": self._context}, self._source.creationContext())
        if not isinstance(item, QQuickItem):
            raise ValueError("Collection delegate must create an Item with collectionContext")
        item.setParent(self)
        item.setParentItem(self)
        QQmlProperty(item, "anchors.fill").write(self)
        self._item = item
        self._restore()

    @Slot()
    def remember(self):
        if self._item is None or self._state_store is None:
            return
        engine = qmlEngine(self)
        if engine is None:
            return
        wrapper = engine.newQObject(self._item)
        method = wrapper.property("saveCollectionState")
        if method.isCallable():
            result = method.callWithInstance(wrapper).toVariant()
            self._state_store.save(str(self._context.get("key", "")), result)

    def _restore(self):
        if self._item is None or self._state_store is None:
            return
        engine = qmlEngine(self)
        if engine is None:
            return
        wrapper = engine.newQObject(self._item)
        method = wrapper.property("restoreCollectionState")
        if method.isCallable():
            values = self._state_store.load(str(self._context.get("key", "")))
            method.callWithInstance(wrapper, [engine.toScriptValue(values)])

    sourceComponent = Property(QObject, lambda self: self._source, set_source, notify=sourceChanged)
    collectionContext = Property("QVariantMap", lambda self: self._context, set_context, notify=contextChanged)
    stateStore = Property(QObject, lambda self: self._state_store, lambda self, value: setattr(self, "_state_store", value), notify=contextChanged)
