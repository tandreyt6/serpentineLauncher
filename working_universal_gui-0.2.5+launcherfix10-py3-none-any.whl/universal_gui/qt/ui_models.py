from dataclasses import fields

from PySide6.QtCore import Property, Signal, Slot

from universal_gui.contracts import Request
from universal_gui.qt.collection_model import CollectionModel
from universal_gui.ui_contracts import FileEntry, Issue, NotificationMessage, UiAction


def project_action(action: UiAction) -> dict:
    if not isinstance(action, UiAction):
        raise TypeError("Expected UiAction")
    result = {field.name: getattr(action, field.name) for field in fields(UiAction) if field.name != "children"}
    result["children"] = [project_action(child) for child in action.children]
    return result


class ActionModel(CollectionModel):
    entry_type = UiAction
    field_names = tuple(field.name for field in fields(UiAction))

    def project_value(self, entry, name):
        return [project_action(child) for child in entry.children] if name == "children" else getattr(entry, name)


class FileModel(CollectionModel):
    entry_type = FileEntry
    display_field = "name"
    field_names = tuple(field.name for field in fields(FileEntry))


class IssueModel(CollectionModel):
    entry_type = Issue
    display_field = "title"
    field_names = tuple(field.name for field in fields(Issue))

    def project_value(self, entry, name):
        return [project_action(action) for action in entry.actions] if name == "actions" else getattr(entry, name)


class NotificationQueue(CollectionModel):
    router = None
    currentChanged = Signal()
    optionsChanged = Signal()
    entry_type = NotificationMessage
    field_names = tuple(field.name for field in fields(NotificationMessage))

    def __init__(self, parent=None):
        super().__init__(parent)
        self._capacity = None
        self._policy = None

    def project_value(self, entry, name):
        return [project_action(action) for action in entry.actions] if name == "actions" else getattr(entry, name)

    def get_capacity(self):
        return self._capacity if self._capacity is not None else self.router.request(Request("settings", "get", "notifications.capacity"))

    def set_capacity(self, value):
        if value < 1:
            raise ValueError("Notification capacity must be positive")
        self._capacity = value
        while self.count > value:
            self.dismiss(self._entries[0].key)
        self.optionsChanged.emit()

    def get_policy(self):
        return self._policy if self._policy is not None else self.router.request(Request("settings", "get", "notifications.policy"))

    def set_policy(self, value):
        if value not in ("drop-oldest", "reject-new", "replace-current"):
            raise ValueError("Invalid notification policy")
        self._policy = value
        self.optionsChanged.emit()

    def enqueue(self, message: NotificationMessage) -> bool:
        self._check_thread()
        if not isinstance(message, NotificationMessage) or not message.key:
            raise TypeError("Expected keyed NotificationMessage")
        if message.lifetime is not None and message.lifetime < 0:
            raise ValueError("Notification lifetime must not be negative")
        if message.key in self._positions:
            self.update_entry(message)
            if self._positions[message.key] == 0:
                self.currentChanged.emit()
            return True
        policy = self.get_policy()
        previous_key = self._entries[0].key if self.count else ""
        if policy == "replace-current" and self.count:
            self.remove_entry(self._entries[0].key)
            self.insert_entry(0, message)
            self.currentChanged.emit()
            return True
        if self.count >= self.get_capacity():
            if policy == "reject-new":
                return False
            while self.count >= self.get_capacity():
                self.remove_entry(self._entries[0].key)
        self.insert_entry(self.count, message)
        if previous_key != self._entries[0].key:
            self.currentChanged.emit()
        return True

    @Slot(str, result=bool)
    def dismiss(self, key):
        index = self._positions.get(key)
        if index is None:
            return False
        self.remove_entry(key)
        if index == 0:
            self.currentChanged.emit()
        return True

    @Slot()
    def clear(self):
        self.set_entries(())
        self.currentChanged.emit()

    current = Property("QVariantMap", lambda self: self.get(0), notify=currentChanged)
    capacity = Property(int, get_capacity, set_capacity, notify=optionsChanged)
    policy = Property(str, get_policy, set_policy, notify=optionsChanged)
