from ctypes import wintypes
from dataclasses import dataclass
from weakref import ref
import ctypes
import sys

from PySide6.QtCore import QAbstractNativeEventFilter, QEvent, QObject, QRect, QTimer, Signal, Slot
from PySide6.QtGui import QGuiApplication, QPlatformSurfaceEvent, QWindow
from PySide6.QtQml import QJSValue
from shiboken6 import getCppPointer, isValid

from universal_gui.contracts import Request


WM_NCCALCSIZE = 0x0083
WM_NCPAINT = 0x0085
WM_NCACTIVATE = 0x0086
WM_NCHITTEST = 0x0084
WM_GETMINMAXINFO = 0x0024
WM_ERASEBKGND = 0x0014
WM_SYSCOMMAND = 0x0112
WM_SIZE = 0x0005
WM_SETTINGCHANGE = 0x001A
WM_DISPLAYCHANGE = 0x007E
WM_NCMOUSEMOVE = 0x00A0
WM_NCMOUSELEAVE = 0x02A2
WM_NCLBUTTONDOWN = 0x00A1
WM_NCLBUTTONUP = 0x00A2
SC_MAXIMIZE = 0xF030
SC_RESTORE = 0xF120
SC_MINIMIZE = 0xF020
HTCLIENT = 1
HTTRANSPARENT = -1
HTCAPTION = 2
HTMAXBUTTON = 9
HTLEFT = 10
HTRIGHT = 11
HTTOP = 12
HTTOPLEFT = 13
HTTOPRIGHT = 14
HTBOTTOM = 15
HTBOTTOMLEFT = 16
HTBOTTOMRIGHT = 17
GWL_STYLE = -16
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
ABM_GETAUTOHIDEBAREX = 0x0000000B
DWMWA_NCRENDERING_POLICY = 2
DWMWA_WINDOW_CORNER_PREFERENCE = 33
DWMWA_BORDER_COLOR = 34
DWMNCRP_USEWINDOWSTYLE = 0
DWMNCRP_DISABLED = 1
DWMNCP_DEFAULT = 0
DWMNCP_DONOTROUND = 1
DWMWA_COLOR_NONE = 0xFFFFFFFE
DWMWA_COLOR_DEFAULT = 0xFFFFFFFF
SWP_REFRESH_FRAME = 0x0037  # NOSIZE | NOMOVE | NOZORDER | NOACTIVATE | FRAMECHANGED


def same_window(left, right):
    return left is right or (left is not None and right is not None and
                            isValid(left) and isValid(right) and
                            getCppPointer(left)[0] == getCppPointer(right)[0])


class NativeMessage(ctypes.Structure):
    _fields_ = [("hwnd", ctypes.c_void_p), ("message", ctypes.c_uint), ("wParam", ctypes.c_size_t), ("lParam", ctypes.c_ssize_t), ("time", ctypes.c_uint), ("pt", wintypes.POINT)]


class MinMaxInfo(ctypes.Structure):
    _fields_ = [("reserved", wintypes.POINT), ("maxSize", wintypes.POINT), ("maxPosition", wintypes.POINT), ("minTrackSize", wintypes.POINT), ("maxTrackSize", wintypes.POINT)]


class MonitorInfo(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("monitor", wintypes.RECT), ("work", wintypes.RECT), ("flags", wintypes.DWORD)]


class Margins(ctypes.Structure):
    _fields_ = [("left", ctypes.c_int), ("right", ctypes.c_int), ("top", ctypes.c_int), ("bottom", ctypes.c_int)]


class AppBarData(ctypes.Structure):
    _fields_ = [("size", wintypes.DWORD), ("hwnd", ctypes.c_void_p), ("callback", wintypes.UINT), ("edge", wintypes.UINT), ("rect", wintypes.RECT), ("parameter", ctypes.c_ssize_t)]


@dataclass(frozen=True)
class ChromeRequest:
    window: QWindow
    operation: str = "configure"


class WindowsChrome(QAbstractNativeEventFilter):
    def __init__(self):
        super().__init__()
        self.windows = {}
        self.pending_sizes = set()
        self.work_areas = {}
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.dwm = ctypes.WinDLL("dwmapi", use_last_error=True)
        self.shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        self.shell32.SHAppBarMessage.argtypes = [wintypes.DWORD, ctypes.POINTER(AppBarData)]
        self.shell32.SHAppBarMessage.restype = ctypes.c_size_t
        self.user32.GetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
        self.user32.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
        self.user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
        self.user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        self.user32.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
        self.user32.GetWindowRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.RECT)]
        self.user32.GetTopWindow.argtypes = [ctypes.c_void_p]
        self.user32.GetTopWindow.restype = ctypes.c_void_p
        self.user32.GetWindow.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        self.user32.GetWindow.restype = ctypes.c_void_p
        self.user32.GetClientRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.RECT)]
        self.user32.ClientToScreen.argtypes = [ctypes.c_void_p, ctypes.POINTER(wintypes.POINT)]
        self.user32.IsZoomed.argtypes = [ctypes.c_void_p]
        self.is_arranged = getattr(self.user32, "IsWindowArranged", None)
        if self.is_arranged is not None:
            self.is_arranged.argtypes = [ctypes.c_void_p]
            self.is_arranged.restype = wintypes.BOOL
        self.user32.MonitorFromWindow.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        self.user32.MonitorFromWindow.restype = ctypes.c_void_p
        self.user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.POINTER(MonitorInfo)]
        self.dwm.DwmSetWindowAttribute.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
        self.dwm.DwmExtendFrameIntoClientArea.argtypes = [ctypes.c_void_p, ctypes.POINTER(Margins)]
        QGuiApplication.instance().installNativeEventFilter(self)

    def configure(self, window):
        hwnd = int(window.winId())
        for previous, state in tuple(self.windows.items()):
            target = state["window"]()
            if target is None or not isValid(target) or same_window(target, window) and previous != hwnd:
                self.windows.pop(previous)
        if window.property("nativeFrame"):
            if self.windows.pop(hwnd, None) is not None:
                self.set_frame_attributes(hwnd, False)
                self.user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_REFRESH_FRAME)
            return False
        style = window.property("appearance")
        if isinstance(style, QJSValue):
            style = {key: style.property(key).toNumber() for key in ("windowRadius", "resizeMargin", "titlebarHeight", "titlebarButtonWidth")}
        state = self.windows.get(hwnd)
        if state is None or not same_window(state["window"](), window):
            reference = ref(window)
            state = {"window": reference}
            self.windows[hwnd] = state
            window.destroyed.connect(lambda: self._forget_window(hwnd, reference))
        state.update(radius=float(style["windowRadius"]), resizeMargin=float(style["resizeMargin"]), titleHeight=float(style["titlebarHeight"]), buttonWidth=float(style["titlebarButtonWidth"]), resize=bool(window.property("resizeEnabled")), move=bool(window.property("moveEnabled")), minimize=bool(window.property("minimizeEnabled")), maximize=bool(window.property("maximizeEnabled")), close=bool(window.property("closeEnabled")), customCaption=bool(window.property("customCaption")))
        native_style = self.user32.GetWindowLongPtrW(hwnd, GWL_STYLE)
        # The QML caption owns this area. Leaving WS_CAPTION on the HWND lets
        # Windows paint a classic title bar on WM_SETTEXT/WM_SETICON, even when
        # NCCALCSIZE removed the inset and NCPAINT is handled. Keep resize and
        # minimize/maximize flags for native window commands and snap handling.
        updated = native_style & ~WS_CAPTION
        for flag, allowed in ((WS_THICKFRAME, state["resize"]), (WS_MINIMIZEBOX, state["minimize"]), (WS_MAXIMIZEBOX, state["maximize"])):
            updated = updated | flag if allowed else updated & ~flag
        if updated != native_style:
            self.user32.SetWindowLongPtrW(hwnd, GWL_STYLE, updated)
        if not state.get("configured") or updated != native_style:
            self.set_frame_attributes(hwnd, True)
            margins = Margins(0, 0, 0, 0)
            self.dwm.DwmExtendFrameIntoClientArea(hwnd, ctypes.byref(margins))
            state["configured"] = True
            # Reattaching may leave a caption-sized client inset even when the
            # Win32 style already matches. Recalculate after registration/DWM.
            self.user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_REFRESH_FRAME)
        else:
            self.repair_frame(hwnd)
        return True

    def repair_frame(self, hwnd):
        rect, client = wintypes.RECT(), wintypes.POINT(0, 0)
        if (self.user32.GetWindowRect(hwnd, ctypes.byref(rect)) and
                self.user32.ClientToScreen(hwnd, ctypes.byref(client)) and
                (client.x != rect.left or client.y != rect.top)):
            self.user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_REFRESH_FRAME)

    def forget_surface(self, window):
        for hwnd, state in tuple(self.windows.items()):
            if same_window(state["window"](), window):
                self._forget_window(hwnd, state["window"])

    def _forget_window(self, hwnd, reference):
        state = self.windows.get(hwnd)
        if state is not None and state["window"] is reference:
            self.windows.pop(hwnd, None)
            self.pending_sizes.discard(hwnd)

    def set_frame_attributes(self, hwnd, custom):
        policy = ctypes.c_int(DWMNCRP_DISABLED if custom else DWMNCRP_USEWINDOWSTYLE)
        corners = ctypes.c_int(DWMNCP_DONOTROUND if custom else DWMNCP_DEFAULT)
        border = wintypes.DWORD(DWMWA_COLOR_NONE if custom else DWMWA_COLOR_DEFAULT)
        for attribute, value in ((DWMWA_NCRENDERING_POLICY, policy), (DWMWA_WINDOW_CORNER_PREFERENCE, corners), (DWMWA_BORDER_COLOR, border)):
            self.dwm.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(value), ctypes.sizeof(value))

    def command(self, window, command):
        self.user32.PostMessageW(int(window.winId()), WM_SYSCOMMAND, command, 0)

    def window_order(self, handles):
        pending = set(handles)
        ordered = []
        visited = set()
        hwnd = self.user32.GetTopWindow(None)
        while hwnd and pending and hwnd not in visited:
            visited.add(hwnd)
            if hwnd in pending:
                ordered.append(hwnd)
                pending.remove(hwnd)
            hwnd = self.user32.GetWindow(hwnd, 2)
        return tuple(ordered)

    def work_area(self, hwnd):
        monitor = self.user32.MonitorFromWindow(hwnd, 2)
        info = MonitorInfo()
        info.size = ctypes.sizeof(info)
        if not self.user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            return None
        key = (monitor, info.monitor.left, info.monitor.top, info.monitor.right, info.monitor.bottom, info.work.left, info.work.top, info.work.right, info.work.bottom)
        cached = self.work_areas.get(key)
        if cached is not None:
            return cached
        for edge in range(4):
            bar = AppBarData()
            bar.size = ctypes.sizeof(bar)
            bar.edge = edge
            bar.rect = info.monitor
            if self.shell32.SHAppBarMessage(ABM_GETAUTOHIDEBAREX, ctypes.byref(bar)):
                if edge == 0 and info.work.left == info.monitor.left:
                    info.work.left += 2
                elif edge == 1 and info.work.top == info.monitor.top:
                    info.work.top += 2
                elif edge == 2 and info.work.right == info.monitor.right:
                    info.work.right -= 2
                elif edge == 3 and info.work.bottom == info.monitor.bottom:
                    info.work.bottom -= 2
        for previous in tuple(self.work_areas):
            if previous[0] == monitor:
                self.work_areas.pop(previous)
        self.work_areas[key] = info
        return info

    def hit_test(self, state, window, x, y, width, height):
        scale = window.devicePixelRatio()
        inset = float(window.property("frameInset")) * scale
        x, y = x - inset, y - inset
        width, height = width - inset * 2, height - inset * 2
        if x < 0 or y < 0 or x >= width or y >= height:
            return HTTRANSPARENT
        maximized = window.visibility() in (QWindow.Visibility.Maximized, QWindow.Visibility.FullScreen)
        radius = 0 if maximized else min(state["radius"] * scale, width / 2, height / 2)
        if radius > 0:
            cx = radius if x < radius else width - radius if x > width - radius else x
            cy = radius if y < radius else height - radius if y > height - radius else y
            if (x - cx) ** 2 + (y - cy) ** 2 > radius ** 2:
                return HTTRANSPARENT
        margin = state["resizeMargin"] * scale
        if state["resize"] and not maximized:
            left, right = x < margin, x >= width - margin
            top, bottom = y < margin, y >= height - margin
            if top and left:
                return HTTOPLEFT
            if top and right:
                return HTTOPRIGHT
            if bottom and left:
                return HTBOTTOMLEFT
            if bottom and right:
                return HTBOTTOMRIGHT
            if left:
                return HTLEFT
            if right:
                return HTRIGHT
            if top:
                return HTTOP
            if bottom:
                return HTBOTTOM
        if y < state["titleHeight"] * scale and window.visibility() != QWindow.Visibility.FullScreen:
            button = state["buttonWidth"] * scale
            maximum_right = width - (button if state["close"] else 0)
            if state["maximize"] and maximum_right - button <= x < maximum_right:
                return HTMAXBUTTON
            count = int(state["close"]) + int(state["maximize"]) + int(state["minimize"])
            if state["move"] and x < width - count * button:
                return HTCLIENT if state["customCaption"] else HTCAPTION
        return HTCLIENT

    def sync_maximized_size(self, hwnd):
        self.pending_sizes.discard(hwnd)
        state = self.windows.get(hwnd)
        window = state["window"]() if state is not None else None
        if window is None or not isValid(window) or not self.user32.IsZoomed(hwnd):
            return
        info = self.work_area(hwnd)
        if info is None:
            return
        screen = window.screen().geometry()
        scale = window.devicePixelRatio()
        geometry = QRect(screen.x() + round((info.work.left - info.monitor.left) / scale), screen.y() + round((info.work.top - info.monitor.top) / scale), round((info.work.right - info.work.left) / scale), round((info.work.bottom - info.work.top) / scale))
        if window.geometry() != geometry:
            window.setGeometry(geometry)

    def sync_geometry(self, window):
        hwnd = int(window.winId())
        self.sync_maximized_size(hwnd)
        snapped = window.visibility() == QWindow.Visibility.Windowed and self.is_arranged is not None and bool(self.is_arranged(hwnd))
        if window.property("nativeSnapped") != snapped:
            window.setProperty("nativeSnapped", snapped)

    def nativeEventFilter(self, event_type, message):
        if bytes(event_type) != b"windows_generic_MSG":
            return False, 0
        event = NativeMessage.from_address(int(message))
        if event.message in (WM_SETTINGCHANGE, WM_DISPLAYCHANGE):
            self.work_areas.clear()
        state = self.windows.get(event.hwnd)
        if state is None:
            return False, 0
        window = state["window"]()
        if window is None or not isValid(window):
            self.windows.pop(event.hwnd, None)
            return False, 0
        if event.message == WM_NCCALCSIZE:
            if event.wParam and self.user32.IsZoomed(event.hwnd):
                info = self.work_area(event.hwnd)
                if info is not None:
                    rect = wintypes.RECT.from_address(event.lParam)
                    rect.left, rect.top = info.work.left, info.work.top
                    rect.right, rect.bottom = info.work.right, info.work.bottom
            return True, 0
        if event.message == WM_ERASEBKGND:
            return True, 1
        if event.message == WM_NCPAINT:
            return True, 0
        if event.message == WM_NCACTIVATE and window.visibility() != QWindow.Visibility.Minimized:
            return True, 1
        if event.message == WM_SIZE and event.wParam == 2 and event.hwnd not in self.pending_sizes:
            self.pending_sizes.add(event.hwnd)
            QTimer.singleShot(0, lambda hwnd=event.hwnd: self.sync_maximized_size(hwnd))
        if event.message == WM_GETMINMAXINFO:
            info = self.work_area(event.hwnd)
            if info is not None:
                limits = MinMaxInfo.from_address(event.lParam)
                limits.maxPosition.x = info.work.left - info.monitor.left
                limits.maxPosition.y = info.work.top - info.monitor.top
                limits.maxSize.x = info.work.right - info.work.left
                limits.maxSize.y = info.work.bottom - info.work.top
                scale = window.devicePixelRatio()
                limits.minTrackSize.x = round(window.minimumWidth() * scale)
                limits.minTrackSize.y = round(window.minimumHeight() * scale)
                limits.maxTrackSize.x = min(round(window.maximumWidth() * scale), limits.maxSize.x)
                limits.maxTrackSize.y = min(round(window.maximumHeight() * scale), limits.maxSize.y)
                return True, 0
        if event.message == WM_NCHITTEST:
            rect = wintypes.RECT()
            origin = wintypes.POINT(0, 0)
            self.user32.GetClientRect(event.hwnd, ctypes.byref(rect))
            self.user32.ClientToScreen(event.hwnd, ctypes.byref(origin))
            x = ctypes.c_short(event.lParam & 0xffff).value - origin.x
            y = ctypes.c_short((event.lParam >> 16) & 0xffff).value - origin.y
            return True, self.hit_test(state, window, x, y, rect.right, rect.bottom)
        if event.message == WM_NCMOUSEMOVE:
            hovered = event.wParam == HTMAXBUTTON
            if window.property("nativeMaxHovered") != hovered:
                window.setProperty("nativeMaxHovered", hovered)
        if event.message == WM_NCMOUSELEAVE:
            window.setProperty("nativeMaxHovered", False)
            window.setProperty("nativeMaxPressed", False)
        if event.message == WM_NCLBUTTONDOWN and event.wParam == HTMAXBUTTON:
            window.setProperty("nativeMaxPressed", True)
            return True, 0
        if event.message == WM_NCLBUTTONUP and event.wParam == HTMAXBUTTON:
            pressed = window.property("nativeMaxPressed")
            window.setProperty("nativeMaxPressed", False)
            if pressed:
                self.command(window, SC_RESTORE if window.visibility() == QWindow.Visibility.Maximized else SC_MAXIMIZE)
            return True, 0
        if event.message == WM_SYSCOMMAND and event.wParam & 0xfff0 == SC_MAXIMIZE and not state["maximize"]:
            return True, 0
        return False, 0

    def close(self):
        QGuiApplication.instance().removeNativeEventFilter(self)
        self.windows.clear()
        self.pending_sizes.clear()
        self.work_areas.clear()


class WindowPlatformManager:
    def __init__(self):
        self.backend = WindowsChrome() if sys.platform == "win32" and QGuiApplication.platformName() == "windows" else None

    def handle(self, action, payload):
        if action == "window_order" and isinstance(payload, tuple) and all(isinstance(handle, int) for handle in payload):
            return self.backend.window_order(payload) if self.backend is not None else payload
        if action != "chrome" or not isinstance(payload, ChromeRequest):
            raise ValueError(f"Invalid platform window request: {action}")
        if payload.operation not in ("configure", "detach", "sync", "minimize", "maximize", "restore"):
            raise ValueError(f"Invalid window command: {payload.operation}")
        window = payload.window
        if payload.operation == "detach":
            if self.backend is not None:
                self.backend.forget_surface(window)
            return None
        enabled = False
        if self.backend is not None:
            enabled = self.backend.configure(window) if payload.operation == "configure" or int(window.winId()) not in self.backend.windows else True
        if payload.operation == "configure":
            return enabled
        if payload.operation == "sync":
            if enabled:
                self.backend.repair_frame(int(window.winId()))
                self.backend.sync_geometry(window)
            return None
        if enabled:
            command = SC_MINIMIZE if payload.operation == "minimize" else SC_MAXIMIZE if payload.operation == "maximize" else SC_RESTORE
            self.backend.command(window, command)
        elif payload.operation == "minimize":
            window.showMinimized()
        elif payload.operation == "maximize":
            window.showMaximized()
        elif payload.operation == "restore":
            window.showNormal()
        return None

    def close(self):
        if self.backend is not None:
            self.backend.close()


class WindowChromeBridge(QObject):
    router = None
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._window = None
        self._generation = 0
        self._surface_destroying = False
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.timeout.connect(self._sync_size)

    @Slot(QObject)
    def configure(self, window):
        if window is None or not isValid(window):
            raise ValueError("Window chrome requires a live window")
        if not same_window(self._window, window):
            self.detach()
            self._window = window
            self._surface_destroying = False
            self._generation += 1
            generation = self._generation
            window.destroyed.connect(lambda: self._window_destroyed(generation))
            window.installEventFilter(self)
            interval = self.router.request(Request("settings", "get", "render.swap_interval"))
            if interval == -1 and sys.platform == "win32":
                interval = 0
            if interval >= 0:
                surface = window.requestedFormat()
                surface.setSwapInterval(interval)
                window.setFormat(surface)
            window.xChanged.connect(self._queue_resize)
            window.yChanged.connect(self._queue_resize)
            window.widthChanged.connect(self._queue_resize)
            window.heightChanged.connect(self._queue_resize)
            window.visibilityChanged.connect(self._queue_resize)
        self._window = window
        self.router.request(Request("platform_windows", "chrome", ChromeRequest(window)))

    def eventFilter(self, watched, event):
        if event.type() == QEvent.Type.PlatformSurface and same_window(watched, self._window):
            if event.surfaceEventType() == QPlatformSurfaceEvent.SurfaceEventType.SurfaceAboutToBeDestroyed:
                self._surface_destroying = True
                self._resize_timer.stop()
                self.router.request(Request("platform_windows", "chrome", ChromeRequest(watched, "detach")))
            else:
                self._surface_destroying = False
                self._resize_timer.start(0)
        return False

    @Slot()
    def _queue_resize(self):
        if not self._surface_destroying and self._window is not None and isValid(self._window) and not self._window.property("nativeFrame"):
            self._resize_timer.start(0)

    def _window_destroyed(self, generation):
        if isValid(self) and generation == self._generation:
            self._window = None
            self._resize_timer.stop()

    @Slot()
    def _sync_size(self):
        if not self._surface_destroying and self._window is not None and isValid(self._window):
            self.router.request(Request("platform_windows", "chrome", ChromeRequest(self._window, "sync")))

    @Slot(str)
    def command(self, operation):
        if operation not in ("minimize", "maximize", "restore"):
            raise ValueError(f"Invalid window command: {operation}")
        window = self._window
        if window is not None and isValid(window):
            self.router.request(Request("platform_windows", "chrome", ChromeRequest(window, operation)))

    @Slot()
    def detach(self):
        self._generation += 1
        self._resize_timer.stop()
        window = self._window
        if window is not None and isValid(window):
            window.removeEventFilter(self)
            for signal in (window.xChanged, window.yChanged, window.widthChanged, window.heightChanged, window.visibilityChanged):
                signal.disconnect(self._queue_resize)
            self.router.request(Request("platform_windows", "chrome", ChromeRequest(window, "detach")))
        self._window = None
