from dataclasses import dataclass

from PySide6.QtCore import QEvent, QObject, QPointF, Property, Qt, Signal
from PySide6.QtGui import QGuiApplication, QWindow
from PySide6.QtQuick import QQuickItem

from universal_gui.contracts import Request


@dataclass(frozen=True)
class TabDragStart:
    group: str
    tab: str
    item: QQuickItem
    position: QPointF
    offset: QPointF
    whole_group: bool = False
    edge_ratio: float = 0


@dataclass(frozen=True)
class TabTarget:
    group: str
    item: QQuickItem
    header: bool
    priority: int = 0


@dataclass(frozen=True)
class TabHandle:
    group: str
    tab: str
    item: QQuickItem


class TabDragFilter(QObject):
    def __init__(self, router):
        super().__init__()
        self.router = router
        self.active = False
        QGuiApplication.instance().installEventFilter(self)

    def eventFilter(self, watched, event):
        if not self.active or not isinstance(watched, QWindow):
            return False
        if event.type() == QEvent.Type.MouseMove:
            if event.buttons() & Qt.MouseButton.LeftButton:
                self.router.request(Request("workspace", "drag_update", event.globalPosition()))
            else:
                self.router.request(Request("workspace", "drag_finish"))
            return False
        if event.type() == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
            self.router.request(Request("workspace", "drag_update", event.globalPosition()))
            self.router.request(Request("workspace", "drag_finish"))
            return False
        if event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.RightButton:
            self.router.request(Request("workspace", "drag_cancel"))
            return True
        if event.type() == QEvent.Type.KeyPress and event.key() == Qt.Key.Key_Escape:
            self.router.request(Request("workspace", "drag_cancel"))
            return True
        return False

    def close(self):
        self.active = False
        QGuiApplication.instance().removeEventFilter(self)


class TabDropTarget(QQuickItem):
    router = None
    targetChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._group = ""
        self._header = False
        self._priority = 0
        self._ready = False

    def set_group(self, value):
        if value != self._group:
            self._group = value
            self.targetChanged.emit()
            self.register()

    def set_header(self, value):
        self._header = value
        self.targetChanged.emit()
        self.register()

    def set_priority(self, value):
        self._priority = value
        self.targetChanged.emit()
        self.register()

    groupKey = Property(str, lambda self: self._group, set_group, notify=targetChanged)
    header = Property(bool, lambda self: self._header, set_header, notify=targetChanged)
    priority = Property(int, lambda self: self._priority, set_priority, notify=targetChanged)

    def componentComplete(self):
        super().componentComplete()
        self._ready = True
        self.register()

    def register(self):
        if self._ready and self._group:
            self.router.request(Request("workspace", "target", TabTarget(self._group, self, self._header, self._priority)))


class TabDragHandle(QQuickItem):
    router = None
    identityChanged = Signal()
    activeChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._group = ""
        self._tab = ""
        self._active = False
        self._ready = False

    def set_group(self, value):
        self._group = value
        self.identityChanged.emit()
        self.register()

    def set_tab(self, value):
        self._tab = value
        self.identityChanged.emit()
        self.register()

    def set_active(self, value):
        if value != self._active:
            self._active = value
            self.activeChanged.emit()

    groupKey = Property(str, lambda self: self._group, set_group, notify=identityChanged)
    tabKey = Property(str, lambda self: self._tab, set_tab, notify=identityChanged)
    activeDrag = Property(bool, lambda self: self._active, set_active, notify=activeChanged)

    def componentComplete(self):
        super().componentComplete()
        self._ready = True
        self.register()

    def register(self):
        if self._ready and self._group and self._tab:
            self.router.request(Request("workspace", "drag_handle", TabHandle(self._group, self._tab, self)))
