from dataclasses import fields

from PySide6.QtCore import QAbstractItemModel, QAbstractListModel, QModelIndex, QObject, Property, QSortFilterProxyModel, Qt, Signal, Slot, QThread, QTimer
from PySide6.QtQml import QJSValue

from universal_gui.ui_contracts import CollectionEntry
from universal_gui.contracts import Request, TextQuery


class CollectionModel(QAbstractListModel):
    countChanged = Signal()
    dataRevisionChanged = Signal()
    entry_type = CollectionEntry
    display_field = "text"
    field_names = tuple(field.name for field in fields(CollectionEntry))

    def __init__(self, parent=None, entries: tuple[CollectionEntry, ...] = ()) -> None:
        super().__init__(parent)
        self._entries: list[CollectionEntry] = []
        self._positions: dict[str, int] = {}
        self._revision = 0
        for signal in (self.dataChanged, self.rowsInserted, self.rowsRemoved, self.rowsMoved):
            signal.connect(self._advance_revision)
        self.set_entries(entries)

    def _advance_revision(self, *args):
        self._revision += 1
        self.dataRevisionChanged.emit()

    def roleNames(self):
        return {int(Qt.ItemDataRole.UserRole) + index: name.encode() for index, name in enumerate(self.field_names)}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._entries)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._entries):
            return None
        entry = self._entries[index.row()]
        if role == Qt.ItemDataRole.DisplayRole:
            return getattr(entry, self.display_field)
        field = int(role) - int(Qt.ItemDataRole.UserRole)
        return self.project_value(entry, self.field_names[field]) if 0 <= field < len(self.field_names) else None

    def project_value(self, entry, name):
        return getattr(entry, name)

    def _check_thread(self):
        if QThread.currentThread() is not self.thread():
            raise RuntimeError("CollectionModel mutations belong to its GUI thread")

    def _index_entries(self):
        self._positions = {entry.key: index for index, entry in enumerate(self._entries)}

    def set_entries(self, entries: tuple[CollectionEntry, ...]) -> None:
        self._check_thread()
        if not all(isinstance(entry, self.entry_type) and entry.key for entry in entries):
            raise TypeError("Entries must match the model DTO with a nonempty key")
        if len({entry.key for entry in entries}) != len(entries):
            raise ValueError("Duplicate collection key")
        if not self._entries and entries:
            self.beginInsertRows(QModelIndex(), 0, len(entries) - 1)
            self._entries = list(entries)
            self._index_entries()
            self.endInsertRows()
            self.countChanged.emit()
            return
        target = {entry.key for entry in entries}
        for entry in tuple(self._entries):
            if entry.key not in target:
                self.remove_entry(entry.key)
        for index, entry in enumerate(entries):
            if entry.key not in self._positions:
                self.insert_entry(index, entry)
            else:
                self.move_entry(entry.key, index)
                self.update_entry(entry)

    def insert_entry(self, index: int, entry: CollectionEntry) -> None:
        self._check_thread()
        if not isinstance(entry, self.entry_type) or not entry.key:
            raise TypeError("Expected the model DTO")
        if entry.key in self._positions:
            raise ValueError(f"Duplicate collection key: {entry.key}")
        index = max(0, min(index, len(self._entries)))
        self.beginInsertRows(QModelIndex(), index, index)
        self._entries.insert(index, entry)
        self._index_entries()
        self.endInsertRows()
        self.countChanged.emit()

    def update_entry(self, entry: CollectionEntry) -> None:
        self._check_thread()
        if not isinstance(entry, self.entry_type):
            raise TypeError("Expected the model DTO")
        index = self._positions[entry.key]
        previous = self._entries[index]
        if previous == entry:
            return
        self._entries[index] = entry
        roles = [int(Qt.ItemDataRole.UserRole) + field for field, name in enumerate(self.field_names) if getattr(previous, name) != getattr(entry, name)]
        self.dataChanged.emit(self.index(index), self.index(index), roles)

    def remove_entry(self, key: str) -> None:
        self._check_thread()
        index = self._positions[key]
        self.beginRemoveRows(QModelIndex(), index, index)
        self._entries.pop(index)
        self._index_entries()
        self.endRemoveRows()
        self.countChanged.emit()

    def move_entry(self, key: str, index: int) -> None:
        self._check_thread()
        previous = self._positions[key]
        index = max(0, min(index, len(self._entries) - 1))
        if previous == index:
            return
        self.beginMoveRows(QModelIndex(), previous, previous, QModelIndex(), index + 1 if index > previous else index)
        self._entries.insert(index, self._entries.pop(previous))
        self._index_entries()
        self.endMoveRows()

    @Slot(int, result="QVariantMap")
    def get(self, index):
        if not 0 <= index < len(self._entries):
            return {}
        entry = self._entries[index]
        return {name: self.project_value(entry, name) for name in self.field_names}

    @Slot(str, result=int)
    def indexOf(self, key):
        return self._positions.get(key, -1)

    count = Property(int, lambda self: len(self._entries), notify=countChanged)
    dataRevision = Property(int, lambda self: self._revision, notify=dataRevisionChanged)


class SearchProxy(QSortFilterProxyModel):
    router = None
    sourceChanged = Signal()
    queryChanged = Signal()
    rolesChanged = Signal()
    sourceRowsChanged = Signal()
    sourceRowsAboutToChange = Signal()
    dataRevisionChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._query = ""
        self._text_role = "text"
        self._key_role = "key"
        self._array_model = None
        self._roles = {}
        self._ranks = {}
        self._labels = {}
        self._locale_dirty = False
        self._locale_timer = QTimer(self)
        self._locale_timer.setSingleShot(True)
        self._locale_timer.timeout.connect(self._apply_locale_revision)
        self._revision = 0
        self._locale_revision = 0
        self._sort_policy = "match"
        self.setDynamicSortFilter(True)

    def set_model(self, value):
        if isinstance(value, QJSValue):
            value = value.toVariant()
        previous = self.sourceModel()
        if value is previous:
            return
        self.sourceRowsAboutToChange.emit()
        if previous is not None:
            for signal in (previous.rowsInserted, previous.rowsRemoved, previous.rowsMoved, previous.modelReset):
                signal.disconnect(self._on_source_changed)
            previous.dataChanged.disconnect(self._on_data_changed)
            for signal in (previous.rowsAboutToBeInserted, previous.rowsAboutToBeRemoved, previous.rowsAboutToBeMoved, previous.modelAboutToBeReset):
                signal.disconnect(self._on_source_about)
        if isinstance(value, (list, tuple)):
            entries = tuple(CollectionEntry(str(row.get(self._key_role, row.get("key", index))), str(row.get(self._text_role, row.get("text", row.get("tag", "")))), str(row.get("text_key", row.get("tag", ""))), str(row.get("secondary", row.get("note", ""))), str(row.get("icon", "")), str(row.get("state_key", "")), row.get("enabled", True), row.get("pinned", False), value=row.get("value", ""), warning=str(row.get("warning", ""))) for index, row in enumerate(value))
            if self._array_model is not None:
                self._array_model.deleteLater()
            self._array_model = CollectionModel(self, entries)
            value = self._array_model
        elif value is not None and not isinstance(value, QAbstractItemModel):
            raise TypeError("Search source must be a Qt model or known row array")
        self._roles = {bytes(name).decode(): role for role, name in value.roleNames().items()} if value is not None else {}
        self._clear_search_cache()
        self.setSourceModel(value)
        if value is not None:
            for signal in (value.rowsInserted, value.rowsRemoved, value.rowsMoved, value.modelReset):
                signal.connect(self._on_source_changed)
            value.dataChanged.connect(self._on_data_changed)
            for signal in (value.rowsAboutToBeInserted, value.rowsAboutToBeRemoved, value.rowsAboutToBeMoved, value.modelAboutToBeReset):
                signal.connect(self._on_source_about)
        self.sort(0)
        self._revision += 1
        self.dataRevisionChanged.emit()
        self.rolesChanged.emit()
        self.sourceChanged.emit()
        self.sourceRowsChanged.emit()

    @Slot(QObject, str)
    def selectKey(self, control, key):
        control.setProperty("selectedKey", key)

    @Slot(QObject, str)
    def selectQuery(self, control, query):
        control.setProperty("searchText", query)

    @Slot(QObject, int)
    def selectIndex(self, control, index):
        control.setProperty("currentIndex", index)

    @Slot(str, result=bool)
    def hasRole(self, name):
        return name in self._roles

    def _on_source_changed(self, *args):
        self._roles = {bytes(name).decode(): role for role, name in self.sourceModel().roleNames().items()}
        self._ranks.clear()
        self.invalidate()
        self._revision += 1
        self.dataRevisionChanged.emit()
        self.sourceRowsChanged.emit()

    def _on_source_about(self, *args):
        self.sourceRowsAboutToChange.emit()

    def _on_data_changed(self, first, last, roles):
        ordering_roles = {self._role(self._text_role), self._role("text_key"), self._role("pinned")}
        if not roles or ordering_roles.intersection(roles):
            for row in range(first.row(), last.row() + 1):
                self._ranks.pop(row, None)
            self.invalidate()
        self._revision += 1
        self.dataRevisionChanged.emit()
        if not roles or self._role(self._key_role) in roles:
            self.sourceRowsChanged.emit()

    def set_query(self, value):
        if value != self._query:
            self.beginFilterChange()
            self._query = value
            self._clear_search_cache()
            self.endFilterChange(QSortFilterProxyModel.Direction.Rows)
            self.setDynamicSortFilter(True)
            self.queryChanged.emit()

    def set_text_role(self, value):
        if value != self._text_role:
            self.beginFilterChange()
            self._text_role = value
            self._clear_search_cache()
            self.endFilterChange(QSortFilterProxyModel.Direction.Rows)
            self.setDynamicSortFilter(True)
            self.rolesChanged.emit()

    def set_key_role(self, value):
        if value != self._key_role:
            self._key_role = value
            self.rolesChanged.emit()

    def _role(self, name):
        model = self.sourceModel()
        if model is self._array_model and name == self._text_role:
            name = "text"
        elif model is self._array_model and name == self._key_role:
            name = "key"
        return self._roles.get(name, -1) if model is not None else -1

    def set_locale_revision(self, value):
        if value != self._locale_revision:
            self._locale_revision = value
            self._locale_dirty = True
            if self._query:
                self._locale_timer.start(0)

    @Slot()
    def _apply_locale_revision(self):
        if not self._locale_dirty or not self._query:
            return
        self.beginFilterChange()
        self._clear_search_cache()
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)
        if self._sort_policy == "match":
            self.setDynamicSortFilter(True)

    def _clear_search_cache(self):
        self._ranks.clear()
        self._labels.clear()
        self._locale_dirty = False
        self._locale_timer.stop()

    def set_sort_policy(self, value):
        if value not in ("source", "match"):
            raise ValueError("Invalid search order")
        if value != self._sort_policy:
            self._sort_policy = value
            self._ranks.clear()
            self.setDynamicSortFilter(True)
            self.rolesChanged.emit()

    def _label(self, index):
        key = self._value(index, "text_key")
        if not key and self._text_role == "tag":
            key = self._value(index, self._text_role)
        if key:
            if self.router is None:
                raise RuntimeError("Localized search needs the application router")
            key = str(key)
            if key not in self._labels:
                self._labels[key] = self.router.request(Request("localization", "text", TextQuery(key)))
            return self._labels[key]
        value = self._value(index, self._text_role)
        return "" if value is None else str(value)

    def _value(self, index, role):
        number = self._role(role)
        return self.sourceModel().data(index, number) if number >= 0 else None

    def filterAcceptsRow(self, row, parent):
        index = self.sourceModel().index(row, 0, parent)
        text = self._label(index) if self._query else ""
        return not self._query or self._query.casefold() in text.casefold() or bool(self._value(index, "pinned"))

    def lessThan(self, left, right):
        for index in (left, right):
            if index.row() not in self._ranks:
                text = self._label(index).casefold() if self._query and self._sort_policy == "match" else ""
                self._ranks[index.row()] = (not bool(self._value(index, "pinned")), self._sort_policy == "match" and text != self._query.casefold(), index.row())
        return self._ranks[left.row()] < self._ranks[right.row()]

    @Slot(str, result=int)
    def indexOf(self, key):
        role = self._role(self._key_role)
        for row in range(self.rowCount()):
            if self.data(self.index(row, 0), role) == key:
                return row
        return -1

    @Slot(int, result="QVariantMap")
    def get(self, row):
        if not 0 <= row < self.rowCount() or self.sourceModel() is None:
            return {}
        index = self.index(row, 0)
        values = {bytes(name).decode(): self.data(index, role) for role, name in self.roleNames().items()}
        if self.sourceModel() is self._array_model:
            values[self._text_role] = values["text"]
            values[self._key_role] = values["key"]
        return values

    @Slot(int, result="QVariantMap")
    def sourceRow(self, row):
        model = self.sourceModel()
        if model is None or not 0 <= row < model.rowCount():
            return {}
        values = {bytes(name).decode(): model.data(model.index(row, 0), role) for role, name in model.roleNames().items()}
        if model is self._array_model:
            values[self._text_role] = values["text"]
            values[self._key_role] = values["key"]
        return values

    @Slot(str, result=int)
    def sourceIndexOf(self, key):
        model = self.sourceModel()
        if model is None:
            return -1
        if isinstance(model, CollectionModel):
            return model.indexOf(key)
        role = self._role(self._key_role)
        return next((row for row in range(model.rowCount()) if model.data(model.index(row, 0), role) == key), -1)

    source = Property("QVariant", lambda self: self.sourceModel(), set_model, notify=sourceChanged)
    dataRevision = Property(int, lambda self: self._revision, notify=dataRevisionChanged)
    query = Property(str, lambda self: self._query, set_query, notify=queryChanged)
    textRole = Property(str, lambda self: self._text_role, set_text_role, notify=rolesChanged)
    keyRole = Property(str, lambda self: self._key_role, set_key_role, notify=rolesChanged)
    localeRevision = Property(int, lambda self: self._locale_revision, set_locale_revision)
    sortPolicy = Property(str, lambda self: self._sort_policy, set_sort_policy, notify=rolesChanged)
