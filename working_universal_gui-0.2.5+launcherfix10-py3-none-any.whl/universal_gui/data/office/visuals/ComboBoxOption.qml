import QtQuick

Item {
    id: visual
    required property QtObject viewState
    Rectangle {
        anchors.fill: parent
        radius: visual.viewState.style.optionRadius
        color: !visual.viewState.enabled ? visual.viewState.style.optionBackground : visual.viewState.pressed ? visual.viewState.style.optionPressedBackground : visual.viewState.checked ? visual.viewState.style.optionSelectedBackground : visual.viewState.hovered || visual.viewState.highlighted ? visual.viewState.style.optionHoverBackground : visual.viewState.style.optionBackground
        Behavior on color {
            ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration }
        }
    }
    Text {
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        width: visual.viewState.style.optionCheckWidth
        horizontalAlignment: Text.AlignHCenter
        text: visual.viewState.style.optionCheckGlyph
        visible: visual.viewState.checked
        color: visual.viewState.enabled ? visual.viewState.style.optionMarkerColor : visual.viewState.style.disabledText
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.fontSize
    }
    Image {
        id: picture
        x: visual.viewState.leftPadding
        anchors.verticalCenter: parent.verticalCenter
        width: visual.viewState.style.iconSize
        height: width
        source: visual.viewState.iconSource
        visible: source.toString().length > 0
        sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
        sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
    }
    Text {
        x: visual.viewState.leftPadding + (picture.visible ? picture.width + visual.viewState.style.iconGap : 0)
        anchors.verticalCenter: parent.verticalCenter
        width: Math.max(0, parent.width - x - visual.viewState.rightPadding - visual.viewState.style.optionCheckWidth)
        text: visual.viewState.text
        color: !visual.viewState.enabled ? visual.viewState.style.disabledText : visual.viewState.checked ? visual.viewState.style.optionSelectedTextColor : visual.viewState.hovered || visual.viewState.highlighted ? visual.viewState.style.optionHoveredTextColor : visual.viewState.style.optionTextColor
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.fontSize
        elide: Text.ElideRight
    }
}
