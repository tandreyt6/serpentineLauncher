import QtQuick

Rectangle {
    id: visual
    required property QtObject viewState
    color: viewState.style.scrollbarTrack
    Rectangle {
        width: visual.viewState.vertical ? visual.width : visual.width * visual.viewState.size
        height: visual.viewState.vertical ? visual.height * visual.viewState.size : visual.height
        x: visual.viewState.vertical ? 0 : visual.width * visual.viewState.position
        y: visual.viewState.vertical ? visual.height * visual.viewState.position : 0
        radius: visual.viewState.style.scrollbarWidth / 2
        color: visual.viewState.pressed ? visual.viewState.style.accentPressed : visual.viewState.style.accent
        opacity: visual.viewState.active ? 1 : visual.viewState.style.scrollbarIdleOpacity
        Behavior on opacity { NumberAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
    }
}
