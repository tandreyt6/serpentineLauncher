import QtQuick

Rectangle {
    id: visual
    required property QtObject viewState
    radius: viewState.style.tabActionRadius
    color: viewState.pressed ? viewState.style.tabActionPressed : viewState.hovered ? viewState.style.tabActionHover : viewState.style.tabActionBackground
    border.color: viewState.style.focus
    border.width: viewState.focused ? viewState.style.focusWidth : 0
    Behavior on color { ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
    Text {
        anchors.centerIn: parent
        text: visual.viewState.text
        color: visual.viewState.enabled ? visual.viewState.style.accentText : visual.viewState.style.disabledText
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.tabActionFontSize
    }
}
