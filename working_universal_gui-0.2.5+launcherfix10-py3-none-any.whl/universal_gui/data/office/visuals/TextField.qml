import QtQuick

Rectangle {
    required property QtObject viewState
    color: viewState.enabled ? viewState.style.surface : viewState.style.disabled
    radius: viewState.style.radius
    border.width: viewState.focused ? viewState.style.focusWidth : viewState.style.borderWidth
    border.color: viewState.focused ? viewState.style.focus : viewState.style.border
    Behavior on border.color {
        ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration }
    }
}
