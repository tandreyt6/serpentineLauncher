import QtQuick
import Qt5Compat.GraphicalEffects
import Working.Gui

Rectangle {
    id: visual
    required property QtObject viewState
    color: viewState.style.surface
    radius: viewState.style.radius
    border.color: viewState.focused ? viewState.style.focus : viewState.style.border
    border.width: viewState.style.borderWidth
    Loader {
        anchors.fill: parent
        active: visual.viewState.imageSource !== undefined && String(visual.viewState.imageSource).length > 0
        sourceComponent: Component {
            Item {
                Image {
                    id: picture
                    anchors.fill: parent
                    source: decodeReady ? visual.viewState.imageUrl(visual.viewState.imageSource) : ""
                    fillMode: visual.viewState.imageFit
                    property bool decodeReady: false
                    readonly property size requestedPixels: Qt.size(Math.max(1, Math.ceil(width * Screen.devicePixelRatio)), Math.max(1, Math.ceil(height * Screen.devicePixelRatio)))
                    property size decodedPixels: Qt.size(1, 1)
                    sourceSize: decodedPixels
                    retainWhileLoading: true
                    function initializeDecode() {
                        if (!decodeReady && width > 0 && height > 0) {
                            decodedPixels = requestedPixels
                            decodeReady = true
                        }
                    }
                    onRequestedPixelsChanged: {
                        if (decodeReady) decodeResize.restart()
                        else initializeDecode()
                    }
                    Component.onCompleted: initializeDecode()
                    Timer {
                        id: decodeResize
                        interval: 120
                        onTriggered: picture.decodedPixels = picture.requestedPixels
                    }
                    asynchronous: !source.toString().startsWith("image://pack/")
                    visible: false
                }
                Rectangle { id: mask; anchors.fill: parent; radius: visual.viewState.style.radius; visible: false }
                Loader {
                    anchors.fill: parent
                    active: !Gui.hardwareAcceleration
                    sourceComponent: Component {
                        SoftwareImageItem { source: picture.source; fillMode: visual.viewState.imageFit; radius: visual.viewState.style.radius; opacity: visual.viewState.imageOpacity }
                    }
                }
                OpacityMask { anchors.fill: parent; source: picture; maskSource: mask; opacity: visual.viewState.imageOpacity; cached: false; visible: Gui.hardwareAcceleration }
            }
        }
    }
    Behavior on color { ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration } }
}
