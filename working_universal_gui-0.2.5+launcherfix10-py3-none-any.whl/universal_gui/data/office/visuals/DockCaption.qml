import QtQuick

Rectangle {
    required property QtObject viewState
    color: viewState.windowCaption ? "transparent" : viewState.style.dockTitleBackground
    border.color: viewState.style.border
    border.width: viewState.windowCaption ? 0 : viewState.style.borderWidth
    Text {
        anchors.fill: parent
        anchors.leftMargin: viewState.style.controlPadding
        anchors.rightMargin: viewState.style.controlPadding + viewState.actionSpace
        text: viewState.title
        elide: Text.ElideRight
        verticalAlignment: Text.AlignVCenter
        color: viewState.style.foreground
        font.family: viewState.style.fontFamily
        font.pixelSize: viewState.style.fontSize
    }
    Behavior on color { ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration } }
}
