import QtQuick
import QtQuick.Effects

Item {
    required property QtObject viewState
    RectangularShadow {
        anchors.fill: frame
        visible: viewState.frameInset > 0
        radius: frame.radius
        blur: viewState.style.windowShadowBlur
        spread: viewState.style.windowShadowSpread
        offset: Qt.vector2d(viewState.style.windowShadowOffsetX, viewState.style.windowShadowOffsetY)
        color: viewState.style.windowShadowColor
        cached: false
    }
    Rectangle {
        id: frame
        anchors.fill: parent
        anchors.margins: viewState.frameInset
        radius: viewState.maximized ? 0 : viewState.style.windowRadius
        color: viewState.style.background
        border.color: viewState.alert ? viewState.style.alertColor : viewState.focused ? viewState.style.accent : viewState.style.border
        border.width: viewState.style.windowBorderWidth
        Behavior on border.color { ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration } }
    }
}
