import QtQuick

Rectangle {
    required property QtObject viewState
    color: viewState.pressed ? viewState.style.accent : viewState.hovered ? viewState.style.focus : viewState.style.border
    radius: viewState.style.splitHandleSize / 2
    Behavior on color { ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration } }
}
