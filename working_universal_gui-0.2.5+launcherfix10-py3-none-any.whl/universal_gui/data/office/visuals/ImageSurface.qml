import QtQuick
import Qt5Compat.GraphicalEffects
import Working.Gui

Item {
    required property QtObject viewState
    Rectangle { anchors.fill: parent; radius: viewState.style.radius; color: viewState.style.surface; border.color: viewState.selected ? viewState.style.accent : viewState.style.border; border.width: viewState.style.borderWidth }
    Image {
        id: picture
        anchors.fill: parent
        source: decodeReady ? viewState.imageUrl(viewState.imageSource) : ""
        fillMode: viewState.imageFit
        property bool decodeReady: false
        readonly property size requestedPixels: Qt.size(Math.max(1, Math.ceil(width * Screen.devicePixelRatio)), Math.max(1, Math.ceil(height * Screen.devicePixelRatio)))
        property size decodedPixels: Qt.size(1, 1)
        sourceSize: decodedPixels
        retainWhileLoading: true
        function initializeDecode() {
            if (!decodeReady && width > 0 && height > 0) {
                decodedPixels = requestedPixels
                decodeReady = true
            }
        }
        onRequestedPixelsChanged: {
            if (decodeReady) decodeResize.restart()
            else initializeDecode()
        }
        Component.onCompleted: initializeDecode()
        Timer {
            id: decodeResize
            interval: 120
            onTriggered: picture.decodedPixels = picture.requestedPixels
        }
        asynchronous: !source.toString().startsWith("image://pack/")
        visible: false
    }
    Rectangle { id: mask; anchors.fill: parent; radius: viewState.style.radius; visible: false }
    Loader {
        anchors.fill: parent
        active: !Gui.hardwareAcceleration
        sourceComponent: Component {
            SoftwareImageItem { source: picture.source; fillMode: viewState.imageFit; radius: viewState.style.radius; opacity: viewState.imageOpacity }
        }
    }
    OpacityMask { anchors.fill: parent; source: picture; maskSource: mask; opacity: viewState.imageOpacity; cached: false; visible: Gui.hardwareAcceleration }
}
