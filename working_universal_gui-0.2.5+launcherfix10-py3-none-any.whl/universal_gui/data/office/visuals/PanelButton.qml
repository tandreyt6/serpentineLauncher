import QtQuick

Item {
    id: visual
    required property QtObject viewState
    scale: viewState.pressed ? viewState.style.pressedScale : 1
    Behavior on scale { NumberAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration; easing.type: visual.viewState.style.motionEasing } }

    Rectangle {
        anchors.fill: parent
        radius: visual.viewState.style.radius
        topLeftRadius: visual.viewState.leftRadius
        bottomLeftRadius: visual.viewState.leftRadius
        topRightRadius: visual.viewState.rightRadius
        bottomRightRadius: visual.viewState.rightRadius
        color: !visual.viewState.enabled ? visual.viewState.style.disabled : visual.viewState.pressed || visual.viewState.checked ? visual.viewState.style.accentPressed : visual.viewState.hovered ? visual.viewState.style.accentHover : visual.viewState.style.accent
        border.width: visual.viewState.focused ? visual.viewState.style.focusWidth : 0
        border.color: visual.viewState.style.focus
        Behavior on color {
            ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration }
        }
    }
    Text {
        x: visual.viewState.leftPadding + (picture.visible ? picture.width + visual.viewState.style.iconGap : 0)
        anchors.verticalCenter: parent.verticalCenter
        width: Math.max(0, parent.width - x - visual.viewState.rightPadding)
        horizontalAlignment: visual.viewState.textAlignment
        elide: Text.ElideRight
        text: visual.viewState.text
        color: visual.viewState.enabled ? visual.viewState.style.accentText : visual.viewState.style.disabledText
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.fontSize
    }
    Image {
        id: picture
        x: visual.viewState.leftPadding
        anchors.verticalCenter: parent.verticalCenter
        width: visual.viewState.style.iconSize
        height: width
        source: visual.viewState.iconSource
        visible: source.toString().length > 0
        sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
        sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
    }
}
