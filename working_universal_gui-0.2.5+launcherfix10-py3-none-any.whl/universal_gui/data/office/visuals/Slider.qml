import QtQuick

Item {
    id: visual
    required property QtObject viewState
    Rectangle {
        anchors.centerIn: parent
        width: visual.viewState.vertical ? visual.viewState.style.progressHeight : parent.width - visual.viewState.style.sliderThumbSize
        height: visual.viewState.vertical ? parent.height - visual.viewState.style.sliderThumbSize : visual.viewState.style.progressHeight
        radius: visual.viewState.style.progressHeight / 2
        color: visual.viewState.style.border
    }
    Rectangle {
        width: visual.viewState.style.sliderThumbSize
        height: width
        radius: width / 2
        x: visual.viewState.vertical ? (parent.width - width) / 2 : visual.viewState.position * (parent.width - width)
        y: visual.viewState.vertical ? visual.viewState.position * (parent.height - height) : (parent.height - height) / 2
        color: !visual.viewState.enabled ? visual.viewState.style.disabled : visual.viewState.pressed ? visual.viewState.style.accentPressed : visual.viewState.style.accent
        border.color: visual.viewState.style.focus
        border.width: visual.viewState.focused ? visual.viewState.style.focusWidth : 0
        Behavior on color { ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
    }
}
