import QtQuick

Item {
    required property QtObject viewState
}
