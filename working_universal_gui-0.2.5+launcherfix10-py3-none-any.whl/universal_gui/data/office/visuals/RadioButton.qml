import QtQuick

Item {
    id: visual
    required property QtObject viewState
    Rectangle {
        id: indicator
        x: visual.viewState.leftPadding
        anchors.verticalCenter: parent.verticalCenter
        width: visual.viewState.indicatorWidth
        height: visual.viewState.indicatorHeight
        radius: visual.viewState.style.switchHeight / 2
        color: !visual.viewState.enabled ? visual.viewState.style.disabled : visual.viewState.checked ? visual.viewState.style.accent : visual.viewState.style.border
        border.color: visual.viewState.focused ? visual.viewState.style.focus : visual.viewState.style.border
        border.width: visual.viewState.focused ? visual.viewState.style.focusWidth : visual.viewState.style.borderWidth
        Behavior on color { ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
        Rectangle {
            anchors.centerIn: parent
            width: visual.viewState.style.switchThumbSize
            height: width
            radius: visual.viewState.style.switchThumbSize / 2
            color: visual.viewState.style.accentText
            opacity: visual.viewState.checked ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
        }
    }
    Text {
        anchors.left: indicator.right
        anchors.leftMargin: visual.viewState.style.spacing
        anchors.right: parent.right
        anchors.rightMargin: visual.viewState.rightPadding
        anchors.verticalCenter: parent.verticalCenter
        horizontalAlignment: visual.viewState.textAlignment
        text: visual.viewState.text
        color: visual.viewState.enabled ? visual.viewState.style.foreground : visual.viewState.style.disabledText
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.fontSize
        elide: Text.ElideRight
    }
    Image {
        anchors.right: parent.right
        anchors.rightMargin: visual.viewState.rightPadding
        anchors.verticalCenter: parent.verticalCenter
        width: visual.viewState.style.iconSize
        height: width
        source: visual.viewState.imageSource
        visible: source.toString().length > 0
        sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
        sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
    }
}
