import QtQuick

Rectangle {
    id: visual
    required property QtObject viewState
    color: viewState.style.surface
    radius: viewState.style.radius
    border.width: viewState.checked || viewState.focused ? viewState.style.focusWidth : viewState.style.borderWidth
    border.color: viewState.checked ? viewState.style.accent : viewState.focused ? viewState.style.focus : viewState.style.border
    Behavior on border.color { ColorAnimation { duration: viewState.reducedMotion || viewState.suspended ? 0 : viewState.style.duration } }
    Image {
        id: picture
        anchors.top: parent.top
        anchors.topMargin: visual.viewState.style.controlPadding
        anchors.horizontalCenter: parent.horizontalCenter
        width: visual.viewState.style.imageChoiceWidth
        height: visual.viewState.style.imageChoiceHeight
        source: visual.viewState.imageSource
        fillMode: Image.PreserveAspectFit
        sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
        sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
        Rectangle { anchors.fill: parent; color: visual.viewState.style.background; visible: picture.source.toString().length === 0 }
    }
    Text {
        anchors.top: picture.bottom
        anchors.topMargin: visual.viewState.style.headingGap
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: visual.viewState.style.headingGap
        horizontalAlignment: Text.AlignHCenter
        text: visual.viewState.text
        color: visual.viewState.style.foreground
        font.family: visual.viewState.style.fontFamily
        font.pixelSize: visual.viewState.style.fontSize
        wrapMode: Text.WordWrap
    }
    Rectangle {
        anchors.bottom: parent.bottom
        anchors.bottomMargin: visual.viewState.style.headingGap
        anchors.horizontalCenter: parent.horizontalCenter
        width: visual.viewState.style.switchThumbSize
        height: width
        radius: width / 2
        color: visual.viewState.checked ? visual.viewState.style.accent : visual.viewState.style.border
        Behavior on color { ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration } }
    }
}
