import QtQuick

Item {
    id: visual
    required property QtObject viewState
    scale: viewState.pressed ? viewState.style.pressedScale : 1
    Behavior on scale { NumberAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration; easing.type: visual.viewState.style.motionEasing } }

    Rectangle {
        anchors.fill: parent
        radius: visual.viewState.style.radius
        color: !visual.viewState.enabled ? visual.viewState.style.disabled : visual.viewState.pressed || visual.viewState.checked ? visual.viewState.style.accentPressed : visual.viewState.hovered ? visual.viewState.style.accentHover : visual.viewState.style.accent
        border.color: visual.viewState.style.focus
        border.width: visual.viewState.focused ? visual.viewState.style.focusWidth : 0
        Behavior on color {
            ColorAnimation { duration: visual.viewState.reducedMotion || visual.viewState.suspended ? 0 : visual.viewState.style.duration }
        }
    }
    Row {
        visible: visual.viewState.text.length > 0 || visual.viewState.iconSource.toString().length > 0
        anchors.centerIn: parent
        spacing: visual.viewState.style.iconGap
        Image {
            width: visual.viewState.style.iconSize
            height: visual.viewState.style.iconSize
            source: visual.viewState.iconSource.toString().length ? visual.viewState.iconSource : visual.viewState.assetUrl("assets/mark.svg")
            sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
            sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
        }
        Text {
            text: visual.viewState.text
            color: visual.viewState.enabled ? visual.viewState.style.accentText : visual.viewState.style.disabledText
            font.family: visual.viewState.style.fontFamily
            font.pixelSize: visual.viewState.style.fontSize
        }
    }
}
