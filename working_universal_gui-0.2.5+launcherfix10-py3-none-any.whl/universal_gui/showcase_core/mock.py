from queue import Full, Queue
from threading import Event, Lock, Thread
from typing import Callable
from uuid import uuid4

from universal_gui.contracts import CommandReceipt, OperationIntent, OperationState


class MockCore:
    def __init__(self, publish: Callable[[OperationState], None], capacity: int, steps: int, interval_ms: int) -> None:
        if capacity < 1 or steps < 1 or interval_ms < 1:
            raise ValueError("Mock capacity, steps and interval must be positive")
        self._publish = publish
        self._queue: Queue[tuple[str, OperationIntent] | None] = Queue(maxsize=capacity)
        self._steps = steps
        self._interval = interval_ms / 1000
        self._stop = Event()
        self._lock = Lock()
        self._receipts: dict[str, CommandReceipt] = {}
        self._thread = Thread(target=self._run, name="showcase-mock-core", daemon=False)
        self._thread.start()

    def submit(self, intent: OperationIntent) -> CommandReceipt:
        with self._lock:
            if self._stop.is_set():
                return CommandReceipt(False, "", "closed")
            if intent.request_id in self._receipts:
                return self._receipts[intent.request_id]
            operation_id = uuid4().hex
            try:
                self._queue.put_nowait((operation_id, intent))
            except Full:
                return CommandReceipt(False, "", "queue-full")
            receipt = CommandReceipt(True, operation_id, "")
            self._receipts[intent.request_id] = receipt
            self._publish(OperationState(operation_id, intent.request_id, "queued", 0, intent.text))
            return receipt

    def _run(self) -> None:
        while not self._stop.is_set():
            item = self._queue.get()
            if item is None:
                break
            operation_id, intent = item
            with self._lock:
                if self._stop.is_set():
                    break
            for step in range(self._steps + 1):
                if self._stop.wait(self._interval):
                    return
                status = "completed" if step == self._steps else "running"
                self._publish(OperationState(operation_id, intent.request_id, status, step * 100 // self._steps, intent.text))

    def close(self) -> None:
        self._stop.set()
        try:
            self._queue.put_nowait(None)
        except Full:
            pass
        self._thread.join()
