from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path, PurePosixPath
from threading import RLock
import gzip
import json
import struct
import zlib


HEADER = struct.Struct("<8sQ")
SIGNATURE = b"UGTHM001"
COMPRESSIBLE = {".json", ".qml", ".svg", ".txt"}


@dataclass(frozen=True)
class PackLimits:
    index_bytes: int
    entry_bytes: int
    entries: int


def validate_key(key: str) -> None:
    path = PurePosixPath(key)
    if not key or path.is_absolute() or ".." in path.parts or "\\" in key or ":" in key or str(path) != key:
        raise ValueError(f"Invalid resource key: {key}")


def build_pack(source: Path, destination: Path) -> None:
    if not source.is_dir():
        raise ValueError("Source must be a directory")
    if destination.resolve().is_relative_to(source.resolve()):
        raise ValueError("Pack destination must be outside source directory")
    records = {}
    blocks = []
    offset = 0
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        if path.is_symlink():
            raise ValueError(f"Symlink is not a pack resource: {path.name}")
        key = path.relative_to(source).as_posix()
        validate_key(key)
        content = path.read_bytes()
        compressed = gzip.compress(content, mtime=0) if path.suffix in COMPRESSIBLE else content
        codec = "gzip" if len(compressed) < len(content) else "none"
        block = compressed if codec == "gzip" else content
        records[key] = {"offset": offset, "stored": len(block), "size": len(content), "codec": codec, "sha256": sha256(content).hexdigest()}
        blocks.append(block)
        offset += len(block)
    if "manifest.json" not in records:
        raise ValueError("Pack needs manifest.json")
    index = json.dumps(records, separators=(",", ":"), sort_keys=True).encode("utf-8")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    try:
        with temporary.open("wb") as stream:
            stream.write(HEADER.pack(SIGNATURE, len(index)))
            stream.write(index)
            for block in blocks:
                stream.write(block)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


class ThemePack:
    def __init__(self, path: Path, limits: PackLimits) -> None:
        self.path = path
        self._limits = limits
        self._lock = RLock()
        self.bytes_read = 0
        self._stream = path.open("rb")
        try:
            header = self._stream.read(HEADER.size)
            if len(header) != HEADER.size:
                raise ValueError("Truncated pack header")
            signature, index_size = HEADER.unpack(header)
            if signature != SIGNATURE or index_size > limits.index_bytes:
                raise ValueError("Invalid signature or excessive index")
            index = self._stream.read(index_size)
            if len(index) != index_size:
                raise ValueError("Truncated pack index")
            self.bytes_read = HEADER.size + index_size
            self._records = json.loads(index)
            self._data_start = HEADER.size + index_size
            self._validate(path.stat().st_size)
        except Exception:
            self._stream.close()
            raise

    def _validate(self, file_size: int) -> None:
        if not isinstance(self._records, dict) or len(self._records) > self._limits.entries:
            raise ValueError("Invalid resource index")
        ranges = []
        for key, record in self._records.items():
            validate_key(key)
            if not isinstance(record, dict):
                raise ValueError("Invalid resource record")
            for field in ("offset", "stored", "size"):
                if type(record.get(field)) is not int or record[field] < 0:
                    raise ValueError(f"Invalid {field}: {key}")
            if record["size"] > self._limits.entry_bytes or record["stored"] > self._limits.entry_bytes:
                raise ValueError(f"Excessive resource: {key}")
            if record.get("codec") not in ("none", "gzip"):
                raise ValueError(f"Unsupported codec: {key}")
            digest = record.get("sha256")
            if not isinstance(digest, str) or len(digest) != 64:
                raise ValueError(f"Invalid digest: {key}")
            end = record["offset"] + record["stored"]
            if self._data_start + end > file_size:
                raise ValueError(f"Resource outside file: {key}")
            ranges.append((record["offset"], end))
        previous_end = 0
        for start, end in sorted(ranges):
            if start < previous_end:
                raise ValueError("Overlapping resource blocks")
            previous_end = end

    def read(self, key: str) -> bytes:
        record = self._records[key]
        with self._lock:
            self._stream.seek(self._data_start + record["offset"])
            block = self._stream.read(record["stored"])
            self.bytes_read += len(block)
        if record["codec"] == "gzip":
            decoder = zlib.decompressobj(zlib.MAX_WBITS | 16)
            content = decoder.decompress(block, record["size"] + 1)
            if not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
                raise ValueError(f"Invalid compressed block: {key}")
        else:
            content = block
        if len(content) != record["size"] or sha256(content).hexdigest() != record["sha256"]:
            raise ValueError(f"Resource integrity failure: {key}")
        return content

    def keys(self) -> tuple[str, ...]:
        return tuple(self._records)

    def contains(self, key: str) -> bool:
        return key in self._records

    def close(self) -> None:
        with self._lock:
            self._stream.close()
