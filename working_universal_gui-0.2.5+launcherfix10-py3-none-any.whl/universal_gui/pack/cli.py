from argparse import ArgumentParser
from pathlib import Path

from universal_gui.pack.format import build_pack


def main() -> None:
    parser = ArgumentParser(description="Build one indexed theme file without Base64")
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    arguments = parser.parse_args()
    build_pack(arguments.source, arguments.destination)
    print(arguments.destination)


if __name__ == "__main__":
    main()
