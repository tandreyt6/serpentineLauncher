from pathlib import Path

from PySide6.QtCore import QCoreApplication, QEvent, QUrl
from PySide6.QtGui import QGuiApplication
from PySide6.QtQml import QQmlApplicationEngine, qmlRegisterType
from shiboken6 import delete

from universal_gui.app_manager import AppManager
from universal_gui.contracts import Diagnostic, Event, ImageCacheStatistics, Request, SettingChange, WindowDefinition
from universal_gui.qt.incubation import IncubationScheduler
from universal_gui.pack.format import PackLimits
from universal_gui.qt.bridge import ComponentBridge
from universal_gui.qt.paint import GpuPaintItem, SoftwarePaintItem
from universal_gui.qt.software_image import SoftwareImageItem
from universal_gui.qt.object_factory import ObjectFactory
from universal_gui.qt.calendar_model import CalendarModel
from universal_gui.qt.collection_model import CollectionModel, SearchProxy
from universal_gui.qt.document_adapter import DocumentAdapter
from universal_gui.qt.document_buffer import DocumentBuffer
from universal_gui.qt.document_lines import DocumentLines
from universal_gui.qt.document_viewport import DocumentViewport
from universal_gui.qt.delegate_host import DelegateHost
from universal_gui.qt.data_ports import DataBridge
from universal_gui.qt.docking import DockBridge, DockManager, DockSurface
from universal_gui.qt.mock_adapter import MockAdapter
from universal_gui.qt.local_state import LocalStateStore
from universal_gui.qt.ui_models import ActionModel, FileModel, IssueModel, NotificationQueue
from universal_gui.qt.native_windows import WindowChromeBridge, WindowPlatformManager
from universal_gui.qt.preview_controller import PreviewController
from universal_gui.qt.showcase_controller import ShowcaseController
from universal_gui.qt.stack_host import StackHost
from universal_gui.qt.split_layout import SplitLayout
from universal_gui.qt.tab_drag import TabDragHandle, TabDropTarget
from universal_gui.qt.visuals import VisualHost, VisualManager
from universal_gui.qt.windows import WindowManager
from universal_gui.qt.workspace import TabContentHost, WorkspaceBridge, WorkspaceManager
from universal_gui.services.diagnostics import DiagnosticsManager
from universal_gui.services.events import EventManager
from universal_gui.services.localization import LocalizationManager
from universal_gui.services.pages import PageManager
from universal_gui.services.registry import RegistryManager
from universal_gui.services.resources import ResourceManager
from universal_gui.services.settings import SettingsManager
from universal_gui.services.themes import ThemeManager


PACKAGE_ROOT = Path(__file__).resolve().parent


class GuiRuntime:
    _active = False
    _types_registered = False

    def __init__(self, application: QGuiApplication, theme_directories: tuple[Path, ...] = (), settings: tuple[SettingChange, ...] = ()) -> None:
        if GuiRuntime._active:
            raise RuntimeError("Only one framework runtime may own the QML engine")
        if QGuiApplication.instance() is not application:
            raise ValueError("Host must provide the active QGuiApplication")
        self._application = application
        self._closed = False
        self.router = AppManager()
        self.engine = None
        self._incubation = None
        self.showcase = None
        self.preview = None
        try:
            self._bootstrap(theme_directories, settings)
            GuiRuntime._active = True
        except Exception:
            self.close()
            raise

    def _bootstrap(self, theme_directories: tuple[Path, ...], initial: tuple[SettingChange, ...]) -> None:
        defaults_path = PACKAGE_ROOT / "data" / "runtime.json"
        settings = SettingsManager(self.router, defaults_path, initial)
        self.router.register("settings", settings)
        defaults = self.router.request(Request("settings", "snapshot"))
        self.router.register("diagnostics", DiagnosticsManager(defaults["diagnostics.capacity"]))
        self.router.register("events", EventManager(self.router))
        limits = PackLimits(defaults["resources.max_index_bytes"], defaults["resources.max_entry_bytes"], defaults["resources.max_entries"])
        self.router.register("resources", ResourceManager(limits, defaults["resources.cache_bytes"], self.router))
        self.router.register("themes", ThemeManager(self.router, PACKAGE_ROOT / "data" / "packs", theme_directories))
        self.router.register("localization", LocalizationManager(self.router, PACKAGE_ROOT / "data" / "locales"))
        self.router.register("registry", RegistryManager(self.router))
        self.router.register("pages", PageManager(self.router))
        self.router.register("platform_windows", WindowPlatformManager())
        ComponentBridge.router = self.router
        SearchProxy.router = self.router
        DocumentBuffer.router = self.router
        NotificationQueue.router = self.router
        VisualHost.router = self.router
        TabContentHost.router = self.router
        TabDropTarget.router = self.router
        TabDragHandle.router = self.router
        WindowChromeBridge.router = self.router
        if not GuiRuntime._types_registered:
            qmlRegisterType(GpuPaintItem, "Working.Gui", 1, 0, "GpuPaintItem")
            qmlRegisterType(SoftwareImageItem, "Working.Gui", 1, 0, "SoftwareImageItem")
            qmlRegisterType(SoftwarePaintItem, "Working.Gui", 1, 0, "SoftwarePaintItem")
            qmlRegisterType(CollectionModel, "Working.Gui", 1, 0, "CollectionModel")
            qmlRegisterType(DocumentLines, "Working.Gui", 1, 0, "DocumentLines")
            qmlRegisterType(DocumentViewport, "Working.Gui", 1, 0, "DocumentViewport")
            qmlRegisterType(FileModel, "Working.Gui", 1, 0, "FileModel")
            qmlRegisterType(SearchProxy, "Working.Gui", 1, 0, "SearchProxy")
            qmlRegisterType(StackHost, "Working.Gui", 1, 0, "StackHost")
            qmlRegisterType(SplitLayout, "Working.Gui", 1, 0, "SplitLayout")
            qmlRegisterType(CalendarModel, "Working.Gui", 1, 0, "CalendarModel")
            qmlRegisterType(DocumentBuffer, "Working.Gui", 1, 0, "DocumentBuffer")
            qmlRegisterType(DocumentAdapter, "Working.Gui", 1, 0, "DocumentAdapter")
            qmlRegisterType(DelegateHost, "Working.Gui", 1, 0, "DelegateHost")
            qmlRegisterType(LocalStateStore, "Working.Gui", 1, 0, "LocalStateStore")
            qmlRegisterType(ActionModel, "Working.Gui", 1, 0, "ActionModel")
            qmlRegisterType(IssueModel, "Working.Gui", 1, 0, "IssueModel")
            qmlRegisterType(NotificationQueue, "Working.Gui", 1, 0, "NotificationQueue")
            qmlRegisterType(DataBridge, "Working.Gui", 1, 0, "DataBridge")
            qmlRegisterType(VisualHost, "Working.Gui", 1, 0, "VisualHost")
            qmlRegisterType(WorkspaceBridge, "Working.Gui", 1, 0, "WorkspaceBridge")
            qmlRegisterType(DockBridge, "Working.Gui", 1, 0, "DockBridge")
            qmlRegisterType(DockSurface, "Working.Gui", 1, 0, "DockSurface")
            qmlRegisterType(TabContentHost, "Working.Gui", 1, 0, "TabContentHost")
            qmlRegisterType(TabDropTarget, "Working.Gui", 1, 0, "TabDropTarget")
            qmlRegisterType(TabDragHandle, "Working.Gui", 1, 0, "TabDragHandle")
            GuiRuntime._types_registered = True
        self.engine = QQmlApplicationEngine()
        self._incubation = IncubationScheduler(self.engine)
        self._object_factory = ObjectFactory(self.engine)
        self.engine.rootContext().setContextProperty("_ugfObjectFactory", self._object_factory)
        self.engine.addImportPath(str(PACKAGE_ROOT / "qml"))
        self.engine.warnings.connect(self._qml_warnings)
        self.router.register("visuals", VisualManager(self.router, self.engine))
        self.router.register("windows", WindowManager(self.engine, self.router))
        self.router.register("workspace", WorkspaceManager(self.router, self.engine))
        self.router.register("docking", DockManager(self.router))
        self.router.request(Request("diagnostics", "record", Diagnostic("INFO", "runtime.ready", "One QML engine; host owns event loop")))

    def _qml_warnings(self, errors) -> None:
        for error in errors:
            self.router.request(Request("diagnostics", "record", Diagnostic("WARNING", "qml.warning", error.toString())))

    @property
    def image_cache_statistics(self):
        if self._closed:
            raise RuntimeError("Runtime is closed")
        return ImageCacheStatistics(0, 0, 0)

    def load(self, scene: Path) -> None:
        self.engine.load(QUrl.fromLocalFile(str(scene.resolve())))
        if not self.engine.rootObjects():
            raise RuntimeError(f"QML root did not load: {scene.name}")

    def load_showcase(self) -> None:
        if self.showcase is not None or self.preview is not None:
            raise RuntimeError("A demonstration mode is already loaded")
        self.router.register("mock", MockAdapter(self.router))
        self.showcase = ShowcaseController(self.router)
        self.router.request(Request("windows", "register", WindowDefinition("showcase.secondary", str(PACKAGE_ROOT / "qml" / "showcase" / "SecondaryWindow.qml"))))
        self.router.request(Request("windows", "register", WindowDefinition("showcase.gallery", str(PACKAGE_ROOT / "qml" / "showcase" / "WidgetGallery.qml"))))
        self.router.request(Request("windows", "register", WindowDefinition("showcase.docking", str(PACKAGE_ROOT / "qml" / "showcase" / "DockShowcase.qml"))))
        self.engine.rootContext().setContextProperty("Showcase", self.showcase)
        self.load(PACKAGE_ROOT / "qml" / "showcase" / "Main.qml")

    def load_preview(self, scene: Path | None = None) -> None:
        self.enable_preview()
        self.load(scene or PACKAGE_ROOT / "qml" / "preview" / "Main.qml")

    def enable_preview(self) -> None:
        if self.showcase is not None or self.preview is not None:
            raise RuntimeError("A demonstration mode is already loaded")
        self.preview = PreviewController(self.router)
        self.engine.rootContext().setContextProperty("Preview", self.preview)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self.showcase is not None:
            self.showcase.close()
        if self.preview is not None:
            self.preview.close()
        if self.engine is not None:
            self.router.request(Request("events", "publish", Event("runtime.closing", None)))
            self._incubation.close()
            self.router.request(Request("docking", "dispose"))
            self.router.request(Request("workspace", "dispose"))
            self.router.request(Request("windows", "cancel_loading"))
            for root in self.engine.rootObjects():
                root.setProperty("visible", False)
                delete(root)
            self.router.request(Request("visuals", "clear"))
            delete(self.engine)
            self.engine = None
            self._incubation = None
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        try:
            self.router.close()
        finally:
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
            GuiRuntime._active = False
