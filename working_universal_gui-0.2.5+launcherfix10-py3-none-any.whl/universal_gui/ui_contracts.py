from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class CollectionEntry:
    key: str
    text: str = ""
    text_key: str = ""
    secondary: str = ""
    icon: str = ""
    state_key: str = ""
    enabled: bool = True
    pinned: bool = False
    path: str = ""
    kind: str = ""
    progress: float = 0
    detail: str = ""
    value: str | int | float | bool | None = ""
    warning: str = ""

    def __post_init__(self):
        if type(self.value) not in (str, int, float, bool, type(None)) or isinstance(self.value, float) and not isfinite(self.value):
            raise TypeError("Collection values must be finite immutable scalars")


@dataclass(frozen=True)
class FileEntry:
    key: str
    name: str
    path: str = ""
    kind: str = "file"
    icon: str = ""
    enabled: bool = True
    size: str = ""
    url: str = ""
    children_loaded: bool = True
    has_children: bool = False
    state_key: str = ""


@dataclass(frozen=True)
class UiAction:
    key: str
    text: str = ""
    text_key: str = ""
    icon: str = ""
    state_key: str = ""
    enabled: bool = True
    checkable: bool = False
    checked: bool = False
    separator: bool = False
    explanation: str = ""
    children: tuple["UiAction", ...] = ()
    group: str = ""


@dataclass(frozen=True)
class ActionIntent:
    component: str
    action: str
    context: str = ""


@dataclass(frozen=True)
class SaveIntent:
    document: str
    revision: int
    text: str


@dataclass(frozen=True)
class DocumentSnapshot:
    key: str
    text: str
    revision: int = 0


@dataclass(frozen=True)
class Issue:
    key: str
    title: str
    reason: str = ""
    context: str = ""
    state_key: str = ""
    actions: tuple[UiAction, ...] = ()


@dataclass(frozen=True)
class NotificationMessage:
    key: str
    text: str = ""
    text_key: str = ""
    icon: str = ""
    state_key: str = ""
    lifetime: int | None = None
    actions: tuple[UiAction, ...] = ()


@dataclass(frozen=True)
class PreparedDocument:
    generation: int
    format: str
    text: str
    error: str = ""
