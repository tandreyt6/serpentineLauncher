from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class Request:
    department: str
    action: str
    payload: object = None


@dataclass(frozen=True)
class Event:
    topic: str
    payload: object = None


@dataclass(frozen=True)
class VisualFailure:
    source: str
    detail: str


@dataclass(frozen=True)
class ComponentIdentity:
    component_type: str
    tag: str
    token: str


@dataclass(frozen=True)
class AppearanceQuery:
    component_type: str
    tag: str
    state_key: str = ""
    density: str = "normal"
    typography_role: str = "body"


@dataclass(frozen=True)
class ResolvedAppearance:
    encoded: str
    visual: "AssetQuery | None"


@dataclass(frozen=True)
class NamedToken:
    name: str
    value: str | int | float | bool


@dataclass(frozen=True)
class TokenPalette:
    tokens: tuple[NamedToken, ...]

    def value(self, name: str) -> str | int | float | bool:
        for token in self.tokens:
            if token.name == name:
                return token.value
        raise KeyError(name)

    def number(self, name: str) -> float:
        value = self.value(name)
        if type(value) not in (int, float):
            raise TypeError(f"Token is not numeric: {name}")
        return float(value)

    def text(self, name: str) -> str:
        value = self.value(name)
        if not isinstance(value, str):
            raise TypeError(f"Token is not text: {name}")
        return value


@dataclass(frozen=True)
class ImageCacheStatistics:
    entries: int
    bytes: int
    capacity: int


@dataclass(frozen=True)
class TextQuery:
    tag: str
    arguments: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class SettingChange:
    key: str
    value: object


@dataclass(frozen=True)
class Diagnostic:
    level: str
    code: str
    detail: str


@dataclass(frozen=True)
class AssetQuery:
    pack_id: str
    key: str
    generation: int = 0


@dataclass(frozen=True)
class AssetData:
    content: bytes
    url: str


@dataclass(frozen=True)
class AppearanceOverride:
    component_type: str
    tag: str
    values: tuple[tuple[str, object], ...]


@dataclass(frozen=True)
class WindowDefinition:
    key: str
    scene: str


@dataclass(frozen=True)
class PageDefinition:
    key: str
    scene: str


@dataclass(frozen=True)
class Navigation:
    window_key: str
    page_key: str


@dataclass(frozen=True)
class LocaleCatalog:
    locale: str
    entries: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class OperationIntent:
    request_id: str
    text: str


@dataclass(frozen=True)
class OperationState:
    operation_id: str
    request_id: str
    status: str
    progress: int
    text: str


@dataclass(frozen=True)
class CommandReceipt:
    accepted: bool
    operation_id: str
    reason: str


class Department(Protocol):
    def handle(self, action: str, payload: object) -> object: ...

    def close(self) -> None: ...
