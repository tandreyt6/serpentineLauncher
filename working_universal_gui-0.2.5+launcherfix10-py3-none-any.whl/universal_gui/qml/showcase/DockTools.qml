import QtQuick
import QtQuick.Layouts
import Working.Gui

Frame {
    id: page
    tag: "gallery.dock.tools"
    ColumnLayout {
        anchors.fill: parent
        spacing: page.appearance.spacing
        UiText { tag: "gallery.dock.filter.hint"; Layout.fillWidth: true; wrapMode: Text.Wrap }
        TextField { objectName: "gallery.tab.input"; tag: "gallery.dock.filter"; Layout.fillWidth: true }
        CheckBox { tag: "gallery.dock.details" }
        Slider { tag: "gallery.dock.scale"; Layout.fillWidth: true; value: 0.45 }
        UiText { tag: "gallery.dock.state.hint"; Layout.fillWidth: true; wrapMode: Text.Wrap }
        Item { Layout.fillHeight: true }
    }
}
