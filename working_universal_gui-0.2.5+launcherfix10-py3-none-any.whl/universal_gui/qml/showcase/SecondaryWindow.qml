import QtQuick
import QtQuick.Layouts
import Working.Gui

AppWindow {
    id: window
    width: Showcase.style.windowWidth / 2
    height: Showcase.style.windowHeight / 3
    tag: "showcase.secondary"
    ColumnLayout {
        anchors.centerIn: parent
        spacing: Showcase.style.spacing
        UiText { tag: "showcase.secondary" }
        PanelButton { tag: "settings.languages.select"; onActivated: Showcase.cycleLocale() }
        PanelButton { tag: "showcase.action.close"; onActivated: Showcase.closeWindow() }
    }
}
