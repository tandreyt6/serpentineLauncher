import QtQuick
import QtQuick.Layouts
import Working.Gui

Frame {
    tag: "gallery.tab.page"
    ColumnLayout {
        anchors.fill: parent
        spacing: parent.parent.appearance.spacing
        UiText { tag: "gallery.tab.hint"; Layout.fillWidth: true }
        TextField { objectName: "gallery.tab.input"; tag: "gallery.tab.input"; Layout.fillWidth: true }
        Switch { tag: "gallery.switch" }
        ProgressBar { tag: "gallery.progress"; value: 0.65; Layout.fillWidth: true }
    }
}
