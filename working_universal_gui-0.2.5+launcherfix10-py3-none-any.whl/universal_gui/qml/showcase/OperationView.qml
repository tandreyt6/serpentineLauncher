import QtQuick
import QtQuick.Layouts
import Working.Gui

ColumnLayout {
    id: view
    spacing: Showcase.style.spacing
    function refreshOperations() {
        const entries = Showcase.operations
        while (operationRows.count > entries.length) operationRows.remove(operationRows.count - 1)
        for (let index = 0; index < entries.length; ++index) {
            if (index < operationRows.count) operationRows.set(index, entries[index])
            else operationRows.append(entries[index])
        }
    }
    ListModel { id: operationRows }
    Connections { target: Showcase; function onChanged() { view.refreshOperations() } }
    RowLayout {
        spacing: Showcase.style.spacing
        TextField {
            id: input
            objectName: "operation.input"
            tag: "showcase.input"
            Layout.fillWidth: true
            onCommitted: function(value, instanceToken) { Showcase.submit(value) }
        }
        PanelButton { objectName: "operation.submit"; tag: "showcase.action.start"; onActivated: Showcase.submit(input.text) }
        PanelButton { objectName: "operation.recreate"; tag: "showcase.action.recreate"; onActivated: Showcase.recreate() }
    }
    Text {
        visible: text.length > 0
        text: Showcase.receiptText
        color: Showcase.style.muted
        font.family: Showcase.style.fontFamily
        font.pixelSize: Showcase.style.fontSize
    }
    Repeater {
        model: operationRows
        delegate: ColumnLayout {
            id: operationRow
            required property string operationId
            required property string text
            required property string status
            required property int progress
            Layout.fillWidth: true
            spacing: Showcase.style.headingGap
            Text {
                Layout.fillWidth: true
                text: operationRow.text + " · " + operationRow.status + " · " + operationRow.progress + "%"
                color: Showcase.style.foreground
                font.family: Showcase.style.fontFamily
                font.pixelSize: Showcase.style.fontSize
                elide: Text.ElideRight
            }
            ProgressBar {
                objectName: "operation.progress." + operationRow.operationId
                tag: "showcase.operation.progress"
                Layout.fillWidth: true
                from: 0
                to: 100
                value: operationRow.progress
            }
        }
    }
    Component.onCompleted: refreshOperations()
}
