import QtQuick
import QtQuick.Layouts
import Working.Gui

AppWindow {
    id: window
    tag: "gallery.window"
    objectName: "gallery.window"
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: window.appearance.padding
        spacing: window.appearance.spacing
        Flow {
            Layout.fillWidth: true
            Layout.preferredHeight: childrenRect.height
            spacing: window.appearance.spacing
            Button { tag: "settings.themes.select"; onActivated: Showcase.cycleTheme() }
            Button { tag: "settings.languages.select"; onActivated: Showcase.cycleLocale() }
            Button { tag: "settings.motion.toggle"; onActivated: Showcase.toggleMotion() }
            UiText { tag: "gallery.hint"; width: parent.width; wrapMode: Text.Wrap }
        }
        ScrollArea {
            id: scroll
            objectName: "gallery.scroll"
            tag: "gallery.scroll"
            Layout.fillWidth: true
            Layout.fillHeight: true
            ColumnLayout {
                width: scroll.width - window.appearance.scrollbarWidth
                spacing: window.appearance.spacing
                Frame {
                    tag: "gallery.defaults"
                    Layout.fillWidth: true
                    contentItem: ColumnLayout {
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            Button { tag: "gallery.button" }
                            ToolButton { tag: "gallery.tool" }
                            PanelPopupButton {
                                id: popupButton
                                objectName: "gallery.popup.button"
                                tag: "gallery.popup"
                                panelComponent: Component {
                                    ColumnLayout {
                                        UiText { tag: "gallery.popup.hint"; Layout.fillWidth: true }
                                        ProgressBar { tag: "gallery.progress"; value: 0.4; Layout.fillWidth: true }
                                        TextField { tag: "gallery.input"; Layout.fillWidth: true }
                                    }
                                }
                            }
                            PromptButton { tag: "gallery.prompt" }
                        }
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            Switch { tag: "gallery.switch" }
                            SwitchBox { tag: "gallery.switchbox" }
                            CheckBox { tag: "gallery.check" }
                            RadioButton { tag: "gallery.radio" }
                        }
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            TextField { tag: "gallery.input" }
                            ComboBox { tag: "gallery.combo"; model: [{key:"one", tag:"gallery.one"}, {key:"two", tag:"gallery.two"}] }
                            Slider { tag: "gallery.slider"; value: 0.4 }
                        }
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            ImageRadioButton { tag: "gallery.image.radio" }
                            ImageRadioGroup {
                                tag: "gallery.image.group"
                                width: Math.min(parent.width, window.appearance.controlWidth * 2 + window.appearance.cardPadding * 2)
                                height: window.appearance.controlHeight + window.appearance.cardPadding * 2
                                buttons: [radioOne, radioTwo]
                                contentItem: Row {
                                    RadioButton { id: radioOne; tag: "gallery.one" }
                                    RadioButton { id: radioTwo; tag: "gallery.two" }
                                }
                            }
                        }
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            Line { tag: "gallery.line" }
                            LineEdit { tag: "gallery.lineedit" }
                        }
                        Label { tag: "gallery.label" }
                        Flow {
                            Layout.fillWidth: true
                            Layout.preferredHeight: childrenRect.height
                            spacing: window.appearance.spacing
                            ProgressBar { tag: "gallery.progress"; value: 0.65 }
                            ProgressBar { tag: "gallery.busy"; indeterminate: true }
                            Button { tag: "gallery.expand"; onActivated: expandable.expanded = !expandable.expanded }
                            Button { tag: "gallery.transition"; onActivated: stack.sourceComponent = stack.sourceComponent === first ? second : first }
                        }
                        ExpandablePanel {
                            id: expandable
                            tag: "gallery.expandable"
                            Layout.fillWidth: true
                            contentItem: UiText { tag: "gallery.expand.hint" }
                        }
                        AnimatedStack {
                            id: stack
                            tag: "gallery.stack"
                            Layout.fillWidth: true
                            Layout.preferredHeight: window.appearance.controlHeight
                            sourceComponent: first
                        }
                        Component { id: first; UiText { tag: "gallery.one" } }
                        Component { id: second; UiText { tag: "gallery.two" } }
                    }
                }
                Tabs {
                    objectName: "gallery.tabs.ordinary"
                    tag: "gallery.tabs.ordinary"
                    Layout.fillWidth: true
                    Layout.preferredHeight: window.appearance.galleryHeight
                    model: [{key:"ordinary.one",titleTag:"gallery.one",source:Qt.resolvedUrl("TabSample.qml").toString()}, {key:"ordinary.two",titleTag:"gallery.two",source:Qt.resolvedUrl("TabSample.qml").toString()}]
                }
                RowLayout {
                    Switch { id: locked; tag: "gallery.locked"; checked: false }
                    UiText { tag: "gallery.tabs.hint"; Layout.fillWidth: true }
                }
                DetachableTabs {
                    objectName: "gallery.tabs.detachable"
                    tag: "gallery.tabs.detachable"
                    Layout.fillWidth: true
                    Layout.preferredHeight: window.appearance.galleryHeight
                    detachMode: locked.checked ? DetachableTabs.Locked : DetachableTabs.Allowed
                    model: [{key:"detach.one",titleTag:"gallery.one",source:Qt.resolvedUrl("TabSample.qml").toString()}, {key:"detach.two",titleTag:"gallery.two",source:Qt.resolvedUrl("TabSample.qml").toString()}]
                }
                RowLayout {
                    UiText { tag: "gallery.dock.hint"; Layout.fillWidth: true; wrapMode: Text.Wrap }
                    Switch { id: dockLocked; tag: "gallery.dock.locked" }
                    Button { tag: "gallery.dock.restore"; onActivated: { docking.showPanel("dock.one"); docking.showPanel("dock.two"); docking.showPanel("dock.center") } }
                    Button { tag: "gallery.dock.open"; onActivated: Showcase.openDocking() }
                }
                DockHost {
                    id: docking
                    objectName: "gallery.dock"
                    tag: "gallery.dock"
                    Layout.fillWidth: true
                    Layout.preferredHeight: window.appearance.galleryHeight * 2
                    dockingEnabled: !dockLocked.checked
                    model: [{key:"dock.one",titleTag:"gallery.dock.project",source:Qt.resolvedUrl("DockTools.qml").toString(),area:"left"}, {key:"dock.two",titleTag:"gallery.dock.properties",source:Qt.resolvedUrl("DockTools.qml").toString(),area:"left"}, {key:"dock.center",titleTag:"gallery.dock.editor",source:Qt.resolvedUrl("TabSample.qml").toString(),area:"center"}]
                }
                FileSystem {
                    objectName: "gallery.files"
                    tag: "gallery.files"
                    path: "/demo"
                    Layout.fillWidth: true
                    Layout.preferredHeight: window.appearance.galleryHeight
                    model: [{key:"documents",name:"Documents",isDirectory:true}, {key:"sample",name:"example.txt",isDirectory:false,size:2048}]
                    onActionRequested: (action,keys,path,value) => feedback.text = action + ": " + keys.join(", ") + " " + value
                }
                Frame {
                    id: dragFrame
                    tag: "gallery.drag.frame"
                    Layout.fillWidth: true
                    Layout.preferredHeight: window.appearance.galleryHeight
                    contentItem: Item {
                        DragItem {
                            tag: "gallery.drag"
                            width: window.appearance.controlWidth
                            height: window.appearance.controlHeight
                            keys: ["sample-item"]
                            text: "sample-item"
                            Rectangle { anchors.fill: parent; radius: window.appearance.radius; color: window.appearance.accent; UiText { anchors.centerIn: parent; tag: "gallery.drag.caption" } }
                        }
                        DragItem {
                            tag: "gallery.drag.native"
                            y: window.appearance.controlHeight + window.appearance.spacing
                            width: window.appearance.controlWidth
                            height: window.appearance.controlHeight
                            keys: ["native-sample"]
                            text: "Universal GUI drag sample"
                            nativeDrag: true
                            Rectangle { anchors.fill: parent; radius: window.appearance.radius; color: window.appearance.accent; UiText { anchors.centerIn: parent; tag: "gallery.drag.native.caption"; width: parent.width; horizontalAlignment: Text.AlignHCenter } }
                        }
                        DropZone {
                            tag: "gallery.drop"
                            anchors.right: parent.right
                            width: window.appearance.popupWidth
                            height: parent.height
                            UiText { anchors.centerIn: parent; tag: "gallery.drop.hint"; width: parent.width }
                            onDropped: payload => feedback.text = payload.action + ": " + payload.keys.join(", ") + payload.urls.join(", ") + payload.text
                        }
                    }
                }
                Button { tag: "gallery.native"; onActivated: native.open() }
                Text { id: feedback; objectName: "gallery.feedback"; color: window.appearance.foreground; Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; font.pixelSize: window.appearance.fontSize }
            }
        }
    }
    AppWindow {
        id: native
        tag: "gallery.native"
        nativeFrame: true
        width: window.appearance.popupWidth
        height: window.appearance.popupHeight
        function open() { show() }
        UiText { anchors.centerIn: parent; tag: "gallery.native" }
    }
}
