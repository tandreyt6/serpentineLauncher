import QtQuick
import QtQuick.Layouts
import Working.Gui

AppWindow {
    id: window
    objectName: "showcase.window"
    minimumWidth: Showcase.style.minimumWidth
    minimumHeight: Showcase.style.minimumHeight
    visible: true
    tag: "showcase.shell"

    ScrollArea {
        objectName: "showcase.scroll"
        tag: "showcase.scroll"
        anchors.fill: parent
        anchors.margins: Showcase.style.padding
        contentHeight: layout.implicitHeight
        clip: true
        ColumnLayout {
            id: layout
            width: parent.width
            spacing: Showcase.style.spacing
            UiText { tag: "showcase.title"; Layout.fillWidth: true }
            UiText { tag: "showcase.subtitle"; Layout.fillWidth: true }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: controls.implicitHeight + Showcase.style.cardPadding * 2
                color: Showcase.style.surface
                radius: Showcase.style.radius
                ColumnLayout {
                    id: controls
                    anchors.fill: parent
                    anchors.margins: Showcase.style.cardPadding
                    spacing: Showcase.style.spacing
                    UiText { tag: "showcase.controls" }
                    Flow {
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: Showcase.style.spacing
                        PanelButton { objectName: "theme.button"; tag: "settings.themes.select"; onActivated: Showcase.cycleTheme() }
                        PanelButton { objectName: "locale.button"; tag: "settings.languages.select"; onActivated: Showcase.cycleLocale() }
                        PanelButton { tag: "showcase.gallery.open"; onActivated: Showcase.openGallery() }
                        PanelButton { tag: "settings.motion.toggle"; checkable: true; checked: Showcase.reducedMotion; onActivated: Showcase.toggleMotion() }
                        PanelButton { tag: "settings.geometry.toggle"; checkable: true; checked: Showcase.geometry; onActivated: Showcase.toggleGeometry() }
                    }
                    RowLayout {
                        spacing: Showcase.style.spacing
                        UiText { tag: "settings.themes.select"; suffix: ": " + Showcase.theme }
                        UiText { tag: "settings.languages.select"; suffix: ": " + Showcase.locale }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: operationArea.implicitHeight + Showcase.style.cardPadding * 2
                color: Showcase.style.surface
                radius: Showcase.style.radius
                ColumnLayout {
                    id: operationArea
                    anchors.fill: parent
                    anchors.margins: Showcase.style.cardPadding
                    spacing: Showcase.style.spacing
                    UiText { tag: "showcase.operations"; Layout.fillWidth: true }
                    UiText { tag: "showcase.operations.hint"; Layout.fillWidth: true }
                    Loader {
                        id: view
                        objectName: "operation.loader"
                        Layout.fillWidth: true
                        source: "OperationView.qml"
                        Connections {
                            target: Showcase
                            function onRecreateRequested() {
                                view.active = false
                                view.active = true
                            }
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: virtualArea.implicitHeight + Showcase.style.cardPadding * 2
                color: Showcase.style.surface
                radius: Showcase.style.radius
                ColumnLayout {
                    id: virtualArea
                    anchors.fill: parent
                    anchors.margins: Showcase.style.cardPadding
                    spacing: Showcase.style.spacing
                    UiText { tag: "showcase.virtualization" }
                    ListWidget {
                        id: syntheticList
                        objectName: "synthetic.list"
                        tag: "showcase.virtualization.list"
                        Layout.fillWidth: true
                        Layout.preferredHeight: Showcase.style.listHeight
                        model: Showcase.listCount
                        clip: true
                        reuseItems: true
                        delegate: Rectangle {
                            required property int index
                            width: ListView.view.width
                            height: Showcase.style.rowHeight
                            color: index % 2 ? Showcase.style.background : Showcase.style.surface
                            UiText {
                                anchors.verticalCenter: parent.verticalCenter
                                anchors.left: parent.left
                                anchors.leftMargin: Showcase.style.controlPadding
                                tag: "showcase.list.row"
                                suffix: " " + (parent.index + 1)
                            }
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                implicitHeight: diagnosticsArea.implicitHeight + Showcase.style.cardPadding * 2
                color: Showcase.style.surface
                radius: Showcase.style.radius
                ColumnLayout {
                    id: diagnosticsArea
                    anchors.fill: parent
                    anchors.margins: Showcase.style.cardPadding
                    spacing: Showcase.style.spacing
                    UiText { tag: "showcase.diagnostics" }
                    UiText { tag: "showcase.diagnostics.hint"; Layout.fillWidth: true }
                    RowLayout {
                        spacing: Showcase.style.spacing
                        PanelButton { tag: "showcase.action.window"; onActivated: Showcase.openWindow() }
                        PanelButton { tag: "showcase.action.missing"; onActivated: Showcase.checkMissing() }
                    }
                    Text {
                        objectName: "diagnostics.text"
                        Layout.fillWidth: true
                        Layout.preferredHeight: Showcase.style.diagnosticsHeight
                        text: Showcase.diagnostics
                        color: Showcase.style.muted
                        font.family: Showcase.style.fontFamily
                        font.pixelSize: Showcase.style.diagnosticsFontSize
                        wrapMode: Text.WrapAnywhere
                        clip: true
                    }
                }
            }
        }
    }
}
