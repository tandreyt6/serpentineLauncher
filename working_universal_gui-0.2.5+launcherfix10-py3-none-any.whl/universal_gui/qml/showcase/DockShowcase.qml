import QtQuick
import QtQuick.Layouts
import Working.Gui

AppWindow {
    id: window
    tag: "gallery.dock.window"
    objectName: "gallery.dock.window"
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: window.appearance.padding
        spacing: window.appearance.spacing
        UiText { tag: "gallery.dock.hint"; Layout.fillWidth: true; wrapMode: Text.Wrap }
        Flow {
            Layout.fillWidth: true
            Layout.preferredHeight: childrenRect.height
            spacing: window.appearance.spacing
            Button { tag: "settings.themes.select"; onActivated: Showcase.cycleTheme() }
            Button { tag: "settings.languages.select"; onActivated: Showcase.cycleLocale() }
            Switch { id: locked; tag: "gallery.dock.locked" }
            Button { tag: "gallery.dock.restore"; onActivated: { docking.showPanel("workspace.project"); docking.showPanel("workspace.properties"); docking.showPanel("workspace.editor") } }
        }
        DockHost {
            id: docking
            tag: "gallery.dock.workspace"
            objectName: "gallery.dock.workspace"
            Layout.fillWidth: true
            Layout.fillHeight: true
            dockingEnabled: !locked.checked
            model: [{key:"workspace.project",titleTag:"gallery.dock.project",source:Qt.resolvedUrl("DockTools.qml").toString(),area:"left"}, {key:"workspace.properties",titleTag:"gallery.dock.properties",source:Qt.resolvedUrl("DockTools.qml").toString(),area:"left"}, {key:"workspace.editor",titleTag:"gallery.dock.editor",source:Qt.resolvedUrl("TabSample.qml").toString(),area:"center"}]
        }
    }
}
