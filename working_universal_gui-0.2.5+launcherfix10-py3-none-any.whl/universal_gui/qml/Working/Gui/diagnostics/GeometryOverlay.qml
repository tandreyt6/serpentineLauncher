import QtQuick

Item {
    required property var style
    property bool focused: false
    z: 1
    Rectangle {
        anchors.fill: parent
        color: "transparent"
        border.color: parent.style.overlayHit
        border.width: parent.style.overlayWidth
    }
    Rectangle {
        anchors.fill: parent
        radius: parent.style.radius
        color: "transparent"
        border.color: parent.style.overlayVisual
        border.width: parent.style.overlayWidth
    }
    Rectangle {
        anchors.fill: parent
        visible: parent.focused
        color: "transparent"
        border.color: parent.style.overlayFocus
        border.width: parent.style.focusWidth
    }
}
