import QtQuick
import QtQuick.Layouts
import Working.Gui

Item {
    id: control
    required property string tag
    property var model: []
    property string path: ""
    property var selectedKeys: []
    property var contextKeys: []
    property var breadcrumbs: []
    property bool navigationVisible: true
    property bool pathVisible: true
    property url backIconSource
    property string backIconKey: appearance.backIconKey
    property Component backIconContent
    property url refreshIconSource
    property string refreshIconKey: appearance.refreshIconKey
    property Component refreshIconContent
    property url folderIconSource
    property string folderIconKey: appearance.folderIconKey
    property Component folderIconContent
    property url fileIconSource
    property string fileIconKey: appearance.fileIconKey
    property Component fileIconContent
    property var toolbarActions: []
    property Component rowDelegate
    property Component entryDelegate
    property var columns: []
    readonly property alias viewport: files
    property var actions: [ {key: "open", tag: "files.open"}, {key: "rename", tag: "files.rename"}, {key: "delete", tag: "files.delete"}, {key: "download", tag: "files.download"} ]
    readonly property alias instanceToken: port.token
    property alias stateKey: port.stateKey
    property alias density: port.density
    property alias typographyRole: port.typographyRole
    property alias textKey: port.textKey
    property alias displayText: port.displayText
    property alias useDisplayText: port.useDisplayText
    readonly property alias appearance: port.style
    signal actionRequested(string action, var keys, string path, string value)
    DataBridge { id: port; componentType: "FileSystem"; tag: control.tag; textFromTag: false }
    LocalStateStore { id: entryState; capacity: port.setting("collection.state_entries") }
    LocalStateStore { id: childRequests; capacity: port.setting("collection.state_entries") }
    function request(action, value) {
        port.fileAction(action, path, selectedKeys, [], value)
        actionRequested(action, selectedKeys, path, value)
    }
    function select(key, additive) {
        const selected = additive ? selectedKeys.slice() : []
        const index = selected.indexOf(key)
        if (index >= 0) selected.splice(index, 1)
        else selected.push(key)
        selectedKeys = selected
    }
    function navigateEntry(entry) {
        const directory = entry.isDirectory === true || entry.kind === "directory"
        const targetPath = entry.path === undefined ? path : entry.path
        if (directory && entry.children_loaded === false && !childRequests.load(entry.key).pending) {
            childRequests.save(entry.key, {pending: true})
            port.fileAction("children", targetPath, [entry.key], [], "")
            actionRequested("children", [entry.key], targetPath, "")
        }
        port.fileAction(directory ? "navigate" : "open", targetPath, [entry.key], [], "")
        actionRequested(directory ? "navigate" : "open", [entry.key], targetPath, "")
    }
    function refresh() { childRequests.clear(); request("refresh", "") }
    function activateCurrent() {
        if (files.currentIndex < 0) return
        const entry = model && model.get ? model.get(files.currentIndex) : model[files.currentIndex]
        if (entry && entry.enabled !== false) navigateEntry(entry)
    }
    onPathChanged: childRequests.clear()
    function pruneSelection() {
        if (Array.isArray(model)) selectedKeys = selectedKeys.filter(key => model.some(row => row.key === key))
        else if (model && model.indexOf) selectedKeys = selectedKeys.filter(key => model.indexOf(key) >= 0)
    }
    onModelChanged: pruneSelection()
    Connections {
        target: control.model && !Array.isArray(control.model) ? control.model : null
        ignoreUnknownSignals: true
        function onRowsRemoved() { control.pruneSelection() }
        function onModelReset() { control.pruneSelection() }
    }
    ColumnLayout {
        anchors.fill: parent
        spacing: control.appearance.spacing
        RowLayout {
            visible: control.navigationVisible
            ToolButton { tag: control.tag + ".back"; displayText: ""; hideText: true; tooltipKey: "framework.files.back"; contentItem: ActionIcon { tag: control.tag + ".back.icon"; source: control.backIconSource; resourceKey: control.backIconKey; imageComponent: control.backIconContent; glyph: control.appearance.previousGlyph; tint: control.appearance.accentText } implicitWidth: control.appearance.controlHeight; onActivated: control.request("back", "") }
            Repeater { model: control.breadcrumbs; delegate: ToolButton { required property var modelData; tag: control.tag + ".breadcrumb." + modelData.key; displayText: modelData.text; onActivated: { port.fileAction("navigate", modelData.path, [], [], ""); control.actionRequested("navigate", [], modelData.path, "") } } }
            ToolButton { tag: control.tag + ".refresh"; displayText: ""; hideText: true; tooltipKey: "framework.files.refresh"; contentItem: ActionIcon { tag: control.tag + ".refresh.icon"; source: control.refreshIconSource; resourceKey: control.refreshIconKey; imageComponent: control.refreshIconContent; glyph: control.appearance.refreshGlyph; tint: control.appearance.accentText } implicitWidth: control.appearance.controlHeight; onActivated: control.refresh() }
        }
        RowLayout {
            visible: control.toolbarActions.length > 0
            Repeater { model: control.toolbarActions; delegate: ToolButton { required property var modelData; tag: control.tag + ".toolbar." + modelData.key; textKey: modelData.text_key === undefined ? "" : modelData.text_key; displayText: modelData.text === undefined ? "" : modelData.text; useDisplayText: !textKey.length; iconSource: modelData.icon === undefined ? "" : modelData.icon; enabled: modelData.enabled !== false; onActivated: control.request(modelData.key, "") } }
        }
        RowLayout {
            visible: control.columns.length > 0
            Layout.fillWidth: true
            spacing: control.appearance.spacing
            Layout.leftMargin: control.appearance.headingGap
            Layout.rightMargin: control.appearance.headingGap
            Item { Layout.preferredWidth: control.appearance.iconSize }
            Repeater {
                model: control.columns
                delegate: UiText {
                    required property var modelData
                    tag: control.tag + ".column"
                    textKey: modelData.textKey === undefined ? "" : modelData.textKey
                    displayText: modelData.text === undefined ? "" : modelData.text
                    useDisplayText: !textKey.length
                    Layout.preferredWidth: modelData.width === undefined ? implicitWidth : modelData.width
                    Layout.fillWidth: modelData.fill === true
                    elide: Text.ElideRight
                }
            }
        }
        TextField {
            visible: control.pathVisible
            tag: control.tag + ".path"
            textFromTag: false
            Layout.fillWidth: true
            text: control.path
            onCommitted: value => {
                port.fileAction("navigate", value, [], [], "")
                control.actionRequested("navigate", [], value, "")
            }
        }
        ListWidget {
            id: files
            tag: control.tag + ".items"
            Layout.fillWidth: true
            Layout.fillHeight: true
            model: control.model
            delegate: control.rowDelegate ? control.rowDelegate : fileDelegate
            Keys.onDeletePressed: control.request("delete", "")
            Keys.onReturnPressed: control.activateCurrent()
            Keys.onBackPressed: control.request("back", "")
            Keys.onPressed: event => { if (event.key === Qt.Key_F5) { control.refresh(); event.accepted = true } }
        }
    }
    Component {
        id: fileDelegate
        DragItem {
                id: row
                required property var model
                required property int index
                property var modelData: model.modelData === undefined ? model : model.modelData
                property var collectionSnapshot: ({})
                function updateCollectionContext() {
                    if (!control || !modelData) return
                    collectionSnapshot = {key: modelData.key, text: text, path: modelData.path, kind: modelData.kind, icon: modelData.icon, enabled: enabled, stateKey: stateKey, selected: control.selectedKeys.indexOf(modelData.key) >= 0, width: width, height: height}
                }
                onModelDataChanged: updateCollectionContext()
                onTextChanged: updateCollectionContext()
                onEnabledChanged: updateCollectionContext()
                onStateKeyChanged: updateCollectionContext()
                onWidthChanged: updateCollectionContext()
                onHeightChanged: updateCollectionContext()
                Connections {
                    target: control
                    function onSelectedKeysChanged() { row.updateCollectionContext() }
                }
                tag: control.tag + ".row"
                text: modelData.name === undefined ? modelData.text : modelData.name
                keys: [modelData.key]
                urls: modelData.url ? [modelData.url] : []
                nativeDrag: true
                moveVisual: false
                enabled: modelData.enabled !== false
                stateKey: modelData.state_key === undefined ? control.stateKey : modelData.state_key
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                width: ListView.view.width
                height: control.appearance.rowHeight
                Rectangle { anchors.fill: parent; color: control.selectedKeys.indexOf(row.modelData.key) >= 0 ? control.appearance.dropHighlight : control.appearance.surface }
                RowLayout {
                    visible: !control.entryDelegate
                    anchors.fill: parent
                    anchors.margins: control.appearance.headingGap
                    spacing: control.appearance.spacing
                    ActionIcon {
                        tag: control.tag + ".icon"
                        readonly property bool directory: row.modelData.isDirectory || row.modelData.kind === "directory"
                        source: row.modelData.icon ? row.modelData.icon : directory ? control.folderIconSource : control.fileIconSource
                        resourceKey: row.modelData.icon ? "" : directory ? control.folderIconKey : control.fileIconKey
                        imageComponent: row.modelData.icon ? null : directory ? control.folderIconContent : control.fileIconContent
                        glyph: directory ? control.appearance.folderGlyph : control.appearance.fileGlyph
                        tint: control.appearance.accent
                        stateKey: row.stateKey
                    }
                    Text { visible: control.columns.length === 0; Layout.fillWidth: true; text: row.modelData.name === undefined ? row.modelData.text : row.modelData.name; elide: Text.ElideRight; color: control.appearance.foreground; font.family: control.appearance.fontFamily; font.pixelSize: control.appearance.fontSize }
                    Text { visible: control.columns.length === 0; text: row.modelData.size === undefined ? "" : row.modelData.size; color: control.appearance.muted; font.pixelSize: control.appearance.smallSize }
                    Repeater {
                        model: control.columns
                        delegate: Text {
                            required property var modelData
                            Layout.preferredWidth: modelData.width === undefined ? implicitWidth : modelData.width
                            Layout.fillWidth: modelData.fill === true
                            horizontalAlignment: modelData.alignment === undefined ? Text.AlignLeft : modelData.alignment
                            text: row.modelData[modelData.role] === undefined ? "" : row.modelData[modelData.role]
                            elide: Text.ElideRight
                            color: control.appearance.foreground
                            font.family: control.appearance.fontFamily
                            font.pixelSize: control.appearance.fontSize
                        }
                    }
                }
                DelegateHost {
                    id: customEntry
                    anchors.fill: parent
                    visible: control.entryDelegate !== null
                    sourceComponent: control.entryDelegate
                    stateStore: entryState
                    collectionContext: row.collectionSnapshot
                }
                ListView.onPooled: customEntry.remember()
                Component.onCompleted: updateCollectionContext()
                Component.onDestruction: customEntry.remember()
                onClicked: (button, modifiers) => {
                    if (button === Qt.RightButton) {
                        control.contextKeys = [modelData.key]
                        const point = row.mapToItem(control, row.pointerPosition.x, row.pointerPosition.y)
                        menu.popupAt(control, point.x, point.y, modelData.key)
                        port.fileAction("context", control.path, control.contextKeys, [], "")
                        control.actionRequested("context", control.contextKeys, control.path, "")
                    } else { files.forceActiveFocus(); files.currentIndex = index; control.select(modelData.key, Boolean(modifiers & Qt.ControlModifier)) }
                }
                onDoubleClicked: {
                    control.selectedKeys = [modelData.key]
                    control.navigateEntry(modelData)
                }
            }
    }
    Menu {
        id: menu
        tag: control.tag + ".menu"
        model: control.actions
        onTriggered: key => { port.fileAction(key, control.path, control.contextKeys, [], ""); control.actionRequested(key, control.contextKeys, control.path, "") }
    }
    DropZone {
        parent: files
        anchors.fill: parent
        tag: control.tag + ".drop"
        onDropped: payload => {
            const action = payload.urls.length ? "upload" : payload.action
            port.fileAction(action, control.path, payload.keys, payload.urls, "")
            control.actionRequested(action, payload.keys, control.path, "")
        }
    }
    Component.onCompleted: port.attach(control)
}
