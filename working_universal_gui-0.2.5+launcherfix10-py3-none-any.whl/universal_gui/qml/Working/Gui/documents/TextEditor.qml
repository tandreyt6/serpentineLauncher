import QtQuick
import QtQuick.Controls as C
import Working.Gui

Widget {
    id: control
    componentType: "TextEditor"
    property var document: localDocument
    property bool readOnly: false
    property bool lineNumbers: false
    property real lineNumberWidth: lineNumbers ? Math.max(appearance.lineNumberMinimumWidth, lineNumberMetrics.advanceWidth + appearance.lineNumberGap) : 0
    padding: appearance.editorPadding
    property bool wrap: true
    property string searchText: ""
    property alias selectionStart: editor.selectionStart
    property alias selectionEnd: editor.selectionEnd
    property alias cursorPosition: editor.cursorPosition
    property alias contentY: viewport.contentY
    readonly property alias editor: editor
    readonly property bool dirty: document.dirty
    signal saveRequested()
    signal closeRequested()
    implicitWidth: appearance.editorWidth
    implicitHeight: appearance.editorHeight
    DocumentBuffer { id: localDocument }
    DocumentLines { id: lineNumbersSource }
    DocumentViewport { id: textViewport }
    TextMetrics { id: lineNumberMetrics; font: editor.font; text: { control.document.revision; return String(Math.max(1, control.document.lineCount)) } }
    function findNext() {
        const index = editor.text.indexOf(searchText, editor.selectionEnd)
        if (index >= 0 && searchText.length) editor.select(index, index + searchText.length)
        return index
    }
    function replaceAll(replacement) { return document.replaceAll(searchText, replacement) }
    function undo() { document.undo() }
    function redo() { document.redo() }
    function requestClose() { document.requestClose(); closeRequested() }
    function attachDocument() { if (document) document.attachEditor(editor.textDocument) }
    onDocumentChanged: Qt.callLater(attachDocument)
    contentItem: Flickable {
        id: viewport
        clip: true
        contentWidth: control.wrap ? width : Math.max(width, editor.width + gutter.width)
        contentHeight: Math.max(height, editor.contentHeight)
        boundsBehavior: Flickable.StopAtBounds
        Item {
            id: gutter
            width: control.lineNumberWidth
            height: editor.contentHeight
            readonly property var visibleLines: {
                control.document.revision
                control.appearance.fontSize
                editor.width
                editor.contentHeight
                return control.lineNumbers ? lineNumbersSource.visibleLines(control.document.document, editor.positionAt(0, viewport.contentY), editor.positionAt(editor.width, viewport.contentY + viewport.height), control.setting("documents.visible_line_numbers")) : []
            }
            Repeater {
                model: gutter.visibleLines
                delegate: Text {
                    required property var modelData
                    y: { editor.contentHeight; editor.width; editor.font; return editor.positionToRectangle(modelData.position).y }
                    width: Math.max(0, gutter.width - control.appearance.lineNumberGap)
                    text: String(modelData.number)
                    color: control.appearance.muted
                    font.family: control.appearance.monospaceFont
                    font.pixelSize: control.appearance.fontSize
                    horizontalAlignment: Text.AlignRight
                }
            }
        }
        TextEdit {
            id: editor
            x: gutter.width
            width: control.wrap ? Math.max(0, viewport.width - gutter.width) : Math.max(1, implicitWidth)
            height: Math.max(viewport.height, contentHeight)
            textFormat: TextEdit.PlainText
            readOnly: control.readOnly
            wrapMode: control.wrap ? TextEdit.Wrap : TextEdit.NoWrap
            selectByMouse: true
            persistentSelection: true
            color: control.appearance.foreground
            selectionColor: control.appearance.accent
            selectedTextColor: control.appearance.accentText
            font.family: control.appearance.monospaceFont
            font.pixelSize: control.appearance.fontSize
            Keys.onPressed: event => {
                if (event.modifiers & Qt.ControlModifier && event.key === Qt.Key_S && !control.readOnly) { control.document.requestSave(); control.saveRequested(); event.accepted = true }
            }
            onCursorPositionChanged: {
                if (cursorRectangle.y < viewport.contentY) viewport.contentY = cursorRectangle.y
                else if (cursorRectangle.y + cursorRectangle.height > viewport.contentY + viewport.height) viewport.contentY = cursorRectangle.y + cursorRectangle.height - viewport.height
            }
        }
        C.ScrollBar.vertical: ScrollBar { tag: control.tag + ".scrollbar" }
        C.ScrollBar.horizontal: ScrollBar { tag: control.tag + ".horizontal-scrollbar" }
        TapHandler {
            onTapped: {
                if (point.position.x + viewport.contentX < editor.x + editor.width) return
                editor.forceActiveFocus()
                editor.cursorPosition = editor.positionAt(editor.width, point.position.y + viewport.contentY)
            }
        }
    }
    Component.onCompleted: { textViewport.observe(editor); attachDocument() }
}
