import QtQuick
import QtQuick.Controls as C
import Working.Gui

Widget {
    id: control
    componentType: "DocumentView"
    property string source: ""
    property string format: "plain"
    signal linkRequested(string url)
    signal preparationFailed(string message)
    readonly property bool busy: adapter.busy
    DocumentAdapter { id: adapter; source: control.source; format: control.format; asynchronousThreshold: control.setting("documents.prepare_async_characters"); maximumCharacters: control.setting("documents.pending_characters"); onFailed: message => control.preparationFailed(message) }
    DocumentViewport { id: textViewport }
    Component.onCompleted: textViewport.observe(document)
    implicitWidth: appearance.editorWidth
    implicitHeight: appearance.editorHeight
    contentItem: Flickable {
        clip: true
        contentWidth: width
        contentHeight: document.contentHeight
        TextEdit {
            id: document
            width: parent.width
            height: contentHeight
            text: adapter.prepared
            textFormat: TextEdit.RichText
            readOnly: true
            selectByMouse: true
            wrapMode: TextEdit.Wrap
            color: control.appearance.foreground
            font.family: control.appearance.fontFamily
            font.pixelSize: control.appearance.fontSize
            onLinkActivated: link => control.linkRequested(link)
        }
        C.ScrollBar.vertical: ScrollBar { tag: control.tag + ".scrollbar" }
    }
}
