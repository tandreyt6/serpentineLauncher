import QtQuick
import Working.Gui

TextEditor {
    id: control
    componentType: "TextViewer"
    readOnly: true
    property bool followTail: false
    property string sourceKey: ""
    property int maximumBlocks: 0
    property bool ready: false
    signal sourceRequested(string key)
    function append(text) { document.appendIncremental(text) }
    onMaximumBlocksChanged: if (document) document.limitBlocks(maximumBlocks)
    onSourceKeyChanged: if (ready && sourceKey.length) sourceRequested(sourceKey)
    function moveToTail() { if (followTail) editor.cursorPosition = editor.length }
    Connections {
        target: control.document
        function onChanged() { if (!control.document.appending) control.moveToTail() }
        function onAppendFinished() { control.moveToTail() }
    }
    onDocumentChanged: if (document && maximumBlocks > 0) document.limitBlocks(maximumBlocks)
    Component.onCompleted: { ready = true; if (maximumBlocks > 0) document.limitBlocks(maximumBlocks); if (sourceKey.length) sourceRequested(sourceKey) }
}
