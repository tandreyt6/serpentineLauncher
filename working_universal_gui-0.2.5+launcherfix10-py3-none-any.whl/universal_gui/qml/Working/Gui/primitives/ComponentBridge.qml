import QtQml
import Working.Gui

QtObject {
    id: port
    readonly property QtObject backend: ObjectFactory.componentBridge(port)
    property string componentType: ""
    property string tag: ""
    property string stateKey: ""
    property string density: "normal"
    property string typographyRole: "body"
    property string textKey: ""
    property var displayText
    property bool useDisplayText: backend.useDisplayText
    property bool textFromTag: true
    readonly property string token: backend.token
    readonly property string text: backend.text
    readonly property int localeRevision: backend.localeRevision
    readonly property string localeName: backend.localeName
    readonly property var style: backend.paintStyle
    readonly property var paintStyle: backend.paintStyle
    readonly property string visual: backend.visual
    readonly property bool reducedMotion: backend.reducedMotion
    readonly property bool geometryVisible: backend.geometryVisible
    readonly property bool suspended: backend.suspended
    readonly property int settingsRevision: backend.settingsRevision
    onBackendChanged: initializeBackend()
    function initializeBackend() {
        if (backend && backend.token.length === 0) {
            backend.componentType = componentType
            backend.tag = tag
            backend.stateKey = stateKey
            backend.density = density
            backend.typographyRole = typographyRole
            backend.textKey = textKey
            backend.textFromTag = textFromTag
            if (displayText !== undefined) backend.displayText = displayText
            backend.useDisplayText = useDisplayText
        }
    }
    signal changed()
    signal identityChanged()
    signal presentationChanged()
    signal localeChanged()
    signal optionsChanged()
    signal displayModeChanged()
    onComponentTypeChanged: if (backend) backend.componentType = componentType
    onTagChanged: if (backend) backend.tag = tag
    onStateKeyChanged: if (backend) backend.stateKey = stateKey
    onDensityChanged: if (backend) backend.density = density
    onTypographyRoleChanged: if (backend) backend.typographyRole = typographyRole
    onTextKeyChanged: if (backend) backend.textKey = textKey
    onDisplayTextChanged: {
        if (backend && displayText !== undefined) {
            if (typeof displayText !== "string") throw new Error("displayText must be a string")
            backend.displayText = displayText
        }
    }
    onUseDisplayTextChanged: if (backend) backend.useDisplayText = useDisplayText
    onTextFromTagChanged: if (backend) backend.textFromTag = textFromTag
    property Connections forwarding: Connections {
        target: port.backend
        function onChanged() { port.changed() }
        function onIdentityChanged() { port.identityChanged() }
        function onPresentationChanged() { port.presentationChanged() }
        function onLocaleChanged() { port.localeChanged() }
        function onOptionsChanged() { port.optionsChanged() }
        function onDisplayModeChanged() { port.displayModeChanged() }
    }
    function attach(owner) { initializeBackend(); backend.attach(owner) }
    function detach() { backend.detach() }
    function refresh(topic) { backend.refresh(topic === undefined ? "" : topic) }
    function numberToken(name) { return backend.numberToken(name) }
    function colorToken(name) { return backend.colorToken(name) }
    function setting(key) { return backend.setting(key) }
    function textFor(key) { return backend.textFor(key) }
    function assetUrl(key) { backend.paintStyle; backend.visual; return backend.assetUrl(key) }
    function imageUrl(source) { backend.paintStyle; backend.visual; return backend.imageUrl(source.toString()) }
    function suspend(value) { backend.suspend(value) }
}
