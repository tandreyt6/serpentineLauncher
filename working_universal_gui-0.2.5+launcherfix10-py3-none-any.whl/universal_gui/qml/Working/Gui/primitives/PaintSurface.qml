import QtQuick
import Working.Gui

Widget {
    id: surface
    tag: "paint.surface"
    componentType: "PaintSurface"
    padding: 0
    hoverEnabled: false
    property var commands: []
    property real offsetX: 0
    property real offsetY: 0
    property real scaleX: 1
    property real scaleY: 1
    property real paintRotation: 0
    property color clearColor: "transparent"
    property bool paintAntialiasing: true
    readonly property bool hardwareAccelerated: Gui.hardwareAcceleration
    readonly property int commandCount: painter.item ? painter.item.commandCount : 0
    readonly property int batchCount: painter.item ? painter.item.batchCount : 0
    signal paintError(string message)
    background: null
    contentItem: Loader {
        id: painter
        sourceComponent: surface.hardwareAccelerated ? gpu : software
        Binding { target: painter.item; property: "commands"; value: surface.commands; when: painter.item !== null }
        Binding { target: painter.item; property: "offsetX"; value: surface.offsetX; when: painter.item !== null }
        Binding { target: painter.item; property: "offsetY"; value: surface.offsetY; when: painter.item !== null }
        Binding { target: painter.item; property: "scaleX"; value: surface.scaleX; when: painter.item !== null }
        Binding { target: painter.item; property: "scaleY"; value: surface.scaleY; when: painter.item !== null }
        Binding { target: painter.item; property: "paintRotation"; value: surface.paintRotation; when: painter.item !== null }
        Binding { target: painter.item; property: "clearColor"; value: surface.clearColor; when: painter.item !== null }
        Binding { target: painter.item; property: "antialiasing"; value: surface.paintAntialiasing; when: painter.item !== null }
        Connections { target: painter.item; function onPaintError(message) { surface.paintError(message) } }
    }
    Component { id: gpu; GpuPaintItem {} }
    Component { id: software; SoftwarePaintItem {} }
}
