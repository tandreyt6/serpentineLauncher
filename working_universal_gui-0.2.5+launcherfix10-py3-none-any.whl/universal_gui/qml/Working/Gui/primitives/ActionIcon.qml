import QtQuick
import Working.Gui

Item {
    id: control
    required property string tag
    readonly property string componentType: "ActionIcon"
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    readonly property alias contentItem: presentation
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    Component.onCompleted: bridge.attach(control)
    property url source
    property string resourceKey: ""
    property Component imageComponent
    property string glyph: ""
    property color tint: appearance.foreground
    property real iconSize: appearance.iconSize
    implicitWidth: iconSize
    implicitHeight: iconSize
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: false
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !control.visible
        readonly property string glyph: control.glyph
        readonly property url source: control.source
        readonly property color tint: control.tint
        readonly property real iconSize: control.iconSize
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: bridge.visual; viewState: visualState }
    Item {
        id: presentation
        anchors.fill: parent
        Item {
            anchors.centerIn: parent
            width: Math.min(parent.width, parent.height, control.iconSize)
            height: width
            Loader {
                anchors.fill: parent
                active: control.imageComponent !== null
                sourceComponent: control.imageComponent
            }
            Loader {
                anchors.fill: parent
                active: !control.imageComponent && (String(control.source).length > 0 || control.resourceKey.length > 0)
                sourceComponent: Component {
                    Icon {
                        tag: control.tag + ".image"
                        source: control.source
                        resourceKey: control.resourceKey
                        tint: control.tint
                        stateKey: control.stateKey
                        density: control.density
                    }
                }
            }
            Text {
                anchors.fill: parent
                visible: !control.imageComponent && !String(control.source).length && !control.resourceKey.length
                text: control.glyph
                color: control.tint
                font.family: control.appearance.fontFamily
                font.pixelSize: control.appearance.fontSize
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }
    }
}
