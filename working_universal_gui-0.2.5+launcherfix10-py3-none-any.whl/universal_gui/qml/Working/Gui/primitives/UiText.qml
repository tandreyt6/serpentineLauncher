import QtQuick
import QtQuick.Controls as C
import Working.Gui

Text {
    id: control
    required property string tag
    property string componentType: "UiText"
    readonly property alias appearance: bridge.style
    property string suffix: ""
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property url iconSource
    property string iconKey: ""
    readonly property url resolvedIconSource: iconKey.length ? bridge.assetUrl(iconKey) : iconSource
    property alias textAlignment: control.horizontalAlignment
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias textFromTag: bridge.textFromTag
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    text: bridge.text + suffix
    readonly property var renderStyle: bridge.paintStyle
    color: String(bridge.visual).length > 0 ? "transparent" : enabled ? renderStyle.textColor : renderStyle.disabledText
    font.family: renderStyle.fontFamily
    font.pixelSize: renderStyle.textSize
    wrapMode: Text.WordWrap
    leftPadding: String(resolvedIconSource).length ? appearance.iconSize + appearance.iconGap : 0
    HoverHandler { id: hover }
    C.ToolTip.visible: hover.hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Loader { active: String(control.resolvedIconSource).length > 0; width: control.appearance.iconSize; height: width; anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter; sourceComponent: Component { Icon { tag: control.tag + ".icon"; source: control.resolvedIconSource } } }
    Accessible.role: Accessible.StaticText
    Accessible.name: text
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property string text: control.text
        readonly property int textAlignment: control.horizontalAlignment
        readonly property int verticalAlignment: control.verticalAlignment
        readonly property int wrapMode: control.wrapMode
        readonly property int elide: control.elide
        readonly property int maximumLineCount: control.maximumLineCount
        readonly property real leftPadding: control.leftPadding
        readonly property real rightPadding: control.rightPadding
        readonly property url iconSource: control.resolvedIconSource
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !control.visible
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: bridge.visual; viewState: visualState }
    Component.onCompleted: bridge.attach(control)
}
