import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.Control {
    id: control
    required property string tag
    property string componentType: "Widget"
    property var collectionContext: ({})
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textFromTag: bridge.textFromTag
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    property string tooltip: ""
    property string disabledExplanation: ""
    hoverEnabled: true
    property bool interactionPressed: false
    readonly property alias caption: bridge.text
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    readonly property alias reducedMotion: bridge.reducedMotion
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    implicitWidth: contentItem ? contentItem.implicitWidth + leftPadding + rightPadding : appearance.controlWidth
    implicitHeight: contentItem ? contentItem.implicitHeight + topPadding + bottomPadding : appearance.controlHeight
    padding: appearance.controlPadding
    locale: Qt.locale(bridge.localeName)
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property string text: bridge.text
        readonly property bool enabled: control.enabled
        readonly property bool hovered: control.hovered
        readonly property bool pressed: control.interactionPressed
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    function assetUrl(key) { return bridge.assetUrl(key) }
    function setting(key) { bridge.settingsRevision; return bridge.setting(key) }
    HoverHandler { id: hover }
    C.ToolTip.visible: hover.hovered && (enabled ? tooltip.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: enabled ? tooltip : disabledExplanation
    C.ToolTip.delay: setting("ui.tooltip_delay_ms")
    Component.onCompleted: bridge.attach(control)
    function saveCollectionState() { return ({}) }
    function restoreCollectionState(values) {}
}
