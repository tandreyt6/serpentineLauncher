import Working.Gui

UiText { componentType: "Label" }
