import QtQuick
import Qt5Compat.GraphicalEffects
import Working.Gui

Item {
    id: control
    required property string tag
    readonly property string componentType: "Icon"
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    readonly property alias contentItem: presentation
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    property alias textFromTag: bridge.textFromTag
    readonly property alias caption: bridge.text
    property string tooltip: ""
    property string disabledExplanation: ""
    property real padding: 0
    property real leftPadding: padding
    property real rightPadding: padding
    property real topPadding: padding
    property real bottomPadding: padding
    readonly property real availableWidth: Math.max(0, width - leftPadding - rightPadding)
    readonly property real availableHeight: Math.max(0, height - topPadding - bottomPadding)
    readonly property bool reducedMotion: bridge.reducedMotion
    readonly property bool suspended: !visible
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    function assetUrl(key) { return bridge.assetUrl(key) }
    function setting(key) { bridge.settingsRevision; return bridge.setting(key) }
    Component.onCompleted: bridge.attach(control)
    property url source
    property string resourceKey: ""
    property url fallbackSource
    signal loadFailed(url source)
    property color tint: appearance.foreground
    property bool tinted: true
    property int fillMode: Image.PreserveAspectFit
    readonly property int status: picture.status
    implicitWidth: appearance.iconSize
    implicitHeight: appearance.iconSize
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: false
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: bridge.visual; viewState: visualState }
    Item {
        id: presentation
        anchors.fill: parent
        anchors.leftMargin: control.leftPadding
        anchors.rightMargin: control.rightPadding
        anchors.topMargin: control.topPadding
        anchors.bottomMargin: control.bottomPadding
        Image {
            id: picture
            anchors.fill: parent
            source: control.resourceKey.length ? control.assetUrl(control.resourceKey) : bridge.imageUrl(control.source)
            fillMode: control.fillMode
            sourceSize.width: Math.ceil(width * Screen.devicePixelRatio)
            sourceSize.height: Math.ceil(height * Screen.devicePixelRatio)
            asynchronous: !source.toString().startsWith("image://pack/")
            visible: !control.tinted && status !== Image.Error
            onStatusChanged: if (status === Image.Error) control.loadFailed(source)
            opacity: control.enabled ? 1 : control.appearance.disabledOpacity
        }
        Image { id: fallback; anchors.fill: parent; source: picture.status === Image.Error ? bridge.imageUrl(control.fallbackSource) : ""; fillMode: control.fillMode; sourceSize: picture.sourceSize; asynchronous: !source.toString().startsWith("image://pack/"); visible: picture.status === Image.Error && !control.tinted; opacity: control.enabled ? 1 : control.appearance.disabledOpacity }
        Loader {
            anchors.fill: parent
            active: !Gui.hardwareAcceleration && control.tinted
            sourceComponent: Component {
                SoftwareImageItem {
                    source: picture.status === Image.Error ? fallback.source : picture.source
                    tint: control.tint
                    tinted: true
                    fillMode: control.fillMode
                    opacity: control.enabled ? 1 : control.appearance.disabledOpacity
                }
            }
        }
        ColorOverlay {
            anchors.fill: picture
            source: picture.status === Image.Error ? fallback : picture
            color: control.tint
            cached: false
            visible: control.tinted && Gui.hardwareAcceleration
            opacity: control.enabled ? 1 : control.appearance.disabledOpacity
        }
    }
}
