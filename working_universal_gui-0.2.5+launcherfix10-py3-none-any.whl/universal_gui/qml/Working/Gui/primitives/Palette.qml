import QtQuick
import Working.Gui

QtObject {
    id: control
    required property string tag
    property string componentType: "Palette"
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    readonly property alias tokens: bridge.style
    readonly property alias instanceToken: bridge.token
    property ComponentBridge componentBridge: ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    function number(name) { bridge.style; return bridge.numberToken(name) }
    function color(name) { bridge.style; return bridge.colorToken(name) }
    Component.onCompleted: bridge.attach(control)
}
