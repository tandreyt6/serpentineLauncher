pragma Singleton
import QtQml

QtObject {
    function componentBridge(owner) { return _ugfObjectFactory.componentBridge(owner) }
    function windowChromeBridge(owner) { return _ugfObjectFactory.windowChromeBridge(owner) }
}
