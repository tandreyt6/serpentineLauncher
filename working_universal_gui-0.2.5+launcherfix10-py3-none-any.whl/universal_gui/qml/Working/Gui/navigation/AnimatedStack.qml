import QtQuick
import Working.Gui

Item {
    id: control
    clip: true
    required property string tag
    property Component sourceComponent
    property bool ready: false
    property var pages: []
    property string currentKey: ""
    property string retentionPolicy: "bounded"
    property int maximumRetained: 8
    property string transitionMode: appearance.stackTransition
    property int orientation: Qt.Horizontal
    property int slideDirection: 1
    property int duration: appearance.surfaceDuration
    property int easing: appearance.motionEasing
    property alias capacity: control.maximumRetained
    signal navigationRequested(string key)
    signal pagePrepared(string key, var page)
    signal pageShown(string key, var page)
    signal pageHidden(string key, var page)
    readonly property alias item: host.currentItem
    readonly property alias retainedCount: host.retainedCount
    readonly property alias appearance: port.style
    readonly property alias instanceToken: port.token
    property alias stateKey: port.stateKey
    property alias density: port.density
    property alias typographyRole: port.typographyRole
    property alias textKey: port.textKey
    property alias displayText: port.displayText
    property alias useDisplayText: port.useDisplayText
    ComponentBridge { id: port; componentType: "AnimatedStack"; tag: control.tag; textFromTag: false }
    StackHost {
        id: host
        anchors.fill: parent
        retentionPolicy: control.retentionPolicy
        capacity: control.maximumRetained
        duration: port.reducedMotion || !control.visible || (control.Window.window && (!control.Window.window.visible || control.Window.window.visibility === Window.Minimized)) ? 0 : control.duration
        Binding { target: host; property: "transitionMode"; value: control.transitionMode; when: control.ready }
        orientation: control.orientation
        direction: control.slideDirection
        easing: control.easing
        onPagePrepared: (key, page) => control.pagePrepared(key, page)
        onPageShown: (key, page) => control.pageShown(key, page)
        onPageHidden: (key, page) => control.pageHidden(key, page)
    }
    function present(key, factory) {
        if (!host.beginCreation(key, true)) return
        try {
            const retained = host.retainedItem(key)
            const page = retained || factory.createObject(host)
            if (!page) throw new Error("Stack page factory must create an Item")
            host.showCreated(key, page)
        } finally {
            host.endCreation(key)
        }
    }
    function preparePage(key) {
        const retained = host.retainedItem(key)
        if (retained) return retained
        const entry = pages.find(page => page.key === key)
        if (!entry) throw new Error("Unknown stack page: " + key)
        if (retentionPolicy === "discard" || (retentionPolicy === "bounded" && maximumRetained === 1 && item)) throw new Error("Preparation requires retention capacity")
        if (!host.beginCreation(key, false)) return null
        try {
            const page = entry.component.createObject(host)
            if (!page) throw new Error("Stack page factory must create an Item")
            return host.prepareItem(key, page)
        } finally {
            host.endCreation(key)
        }
    }
    function showPage(key) {
        const page = pages.find(entry => entry.key === key)
        if (!page) throw new Error("Unknown stack page: " + key)
        navigationRequested(key)
        host.selectKey(control, key)
        present(key, page.component)
    }
    onCurrentKeyChanged: if (ready && currentKey.length && pages.some(entry => entry.key === currentKey)) present(currentKey, pages.find(entry => entry.key === currentKey).component)
    onSourceComponentChanged: if (ready && sourceComponent) present("component/" + sourceComponent.toString(), sourceComponent)
    Component.onCompleted: { port.attach(control); ready = true; if (sourceComponent) present("component/" + sourceComponent.toString(), sourceComponent); else if (currentKey.length) present(currentKey, pages.find(entry => entry.key === currentKey).component) }
}
