import QtQuick
import Working.Gui

Item {
    id: control
    clip: true
    required property string tag
    property string groupKey: tag
    property var model: []
    property bool closable: true
    property bool contentSized: false
    property url closeIconSource
    property string closeIconKey: appearance.tabCloseIconKey
    property Component closeIconContent
    property url detachIconSource
    property string detachIconKey: appearance.tabDetachIconKey
    property Component detachIconContent
    readonly property alias appearance: tabPort.style
    readonly property alias instanceToken: tabPort.token
    property alias scopeKey: tabPort.scopeKey
    property alias floatingClosePolicy: tabPort.floatingClosePolicy
    property alias floatingEmptyPolicy: tabPort.floatingEmptyPolicy
    property alias floatingHeaderLeft: tabPort.floatingHeaderLeft
    property alias floatingHeaderRight: tabPort.floatingHeaderRight
    property alias floatingHeaderContent: tabPort.floatingHeaderContent
    property alias stateKey: tabPort.stateKey
    property alias density: tabPort.density
    property alias typographyRole: tabPort.typographyRole
    property alias textKey: tabPort.textKey
    property alias displayText: tabPort.displayText
    property alias useDisplayText: tabPort.useDisplayText
    readonly property alias currentKey: tabPort.currentKey
    function selectTab(key) { tabPort.selectTab(key) }
    function addTab(key, titleTag, source) { tabPort.addTab(key, titleTag, source.toString()) }
    function removeTab(key) { tabPort.removeTab(key) }
    function moveTab(key, index) { return tabPort.moveTab(key, groupKey, index) }
    WorkspaceBridge { id: tabPort; componentType: "Tabs"; tag: control.tag; textFromTag: false }
    TabStrip { contentSized: control.contentSized; anchors.top: parent.top; width: parent.width; port: tabPort; closeIconSource: control.closeIconSource; closeIconKey: control.closeIconKey; closeIconContent: control.closeIconContent; detachIconSource: control.detachIconSource; detachIconKey: control.detachIconKey; detachIconContent: control.detachIconContent; appearance: control.appearance; closable: control.closable; onCloseRequested: key => tabPort.removeTab(key) }
    TabContentHost {
        id: content
        anchors.fill: parent
        anchors.topMargin: control.appearance.tabHeight
        groupKey: tabPort.groupKey
        tabKey: tabPort.currentKey
    }
    SurfaceMotion { id: reveal; targetItem: content; appearance: control.appearance; reducedMotion: tabPort.reducedMotion; suspended: !control.visible }
    Connections { target: content; function onSelectionChanged() { reveal.restart() } }
    Component.onCompleted: { tabPort.attach(control); tabPort.initialize(groupKey, model, false, false) }
    Component.onDestruction: { tabPort.releaseGroup(); tabPort.detach() }
}
