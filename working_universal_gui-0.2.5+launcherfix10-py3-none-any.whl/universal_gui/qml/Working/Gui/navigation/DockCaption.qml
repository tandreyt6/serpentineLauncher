import QtQuick
import Working.Gui

TabDropTarget {
    id: header
    required property var port
    required property var appearance
    required property string tag
    property string componentType: "DockCaption"
    property bool windowCaption: false
    property bool wholeGroup: false
    property bool closable: false
    property url closeIconSource
    property string closeIconKey: appearance.tabCloseIconKey
    property Component closeIconContent
    signal closeRequested(string key)
    signal captionDoubleClicked()
    groupKey: port.groupKey
    readonly property bool groupCaption: wholeGroup
    header: true
    readonly property real detachDistance: port.detachDistance
    readonly property real tabStride: width
    readonly property real tabWidth: width
    readonly property real scrollOffset: 0
    readonly property real actionSpace: closable && !windowCaption ? appearance.tabActionSize + appearance.tabActionInset : 0
    ComponentBridge { id: bridge; componentType: header.componentType; tag: header.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string title: {
            if (header.wholeGroup) return header.port.entries.map(tab => tab.title).join(bridge.style.dockTitleSeparator)
            const selected = header.port.entries.find(tab => tab.selected)
            return selected ? selected.title : ""
        }
        readonly property bool enabled: header.enabled
        readonly property bool focused: header.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !header.visible
        readonly property bool windowCaption: header.windowCaption
        readonly property real actionSpace: header.actionSpace
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: bridge.visual; viewState: visualState }
    TabDragHandle {
        id: handle
        anchors.fill: parent
        groupKey: header.port.groupKey
        tabKey: header.port.currentKey
        property bool wholeGroup: header.wholeGroup
        property real dragOffset: 0
        readonly property real slotX: 0
        readonly property real floatingWidth: header.windowCaption && Window.window ? Window.window.width : header.parent.width + (Window.window ? Window.window.frameInset * 2 : 0)
        readonly property real floatingHeight: header.windowCaption && Window.window ? Window.window.height : header.parent.height + (Window.window ? Window.window.frameInset * 2 + Window.window.appearance.titlebarHeight : 0)
        objectName: header.wholeGroup ? "dock.group.handle" : "dock.caption.handle"
        Connections { target: handle; function onActiveChanged() { if (!handle.activeDrag) drag.initiated = false } }
        MouseArea {
            id: drag
            anchors.fill: parent
            anchors.rightMargin: header.actionSpace
            acceptedButtons: Qt.LeftButton
            preventStealing: true
            property real pressedX
            property real pressedY
            property bool initiated: false
            onPressed: mouse => { pressedX = mouse.x; pressedY = mouse.y; initiated = false }
            onPositionChanged: mouse => {
                if (pressed && !initiated && Math.hypot(mouse.x - pressedX, mouse.y - pressedY) >= Qt.styleHints.startDragDistance)
                    initiated = header.wholeGroup ? header.port.beginGroupDrag(handle, mouse.x, mouse.y, pressedX, pressedY) : header.port.beginDrag(header.port.currentKey, handle, mouse.x, mouse.y, pressedX, pressedY)
            }
            onReleased: initiated = false
            onCanceled: initiated = false
            onDoubleClicked: { if (header.windowCaption) header.captionDoubleClicked() }
        }
    }
    ToolButton {
        anchors.right: parent.right
        anchors.rightMargin: header.appearance.tabActionInset
        anchors.verticalCenter: parent.verticalCenter
        width: header.appearance.tabActionSize
        height: width
        tag: "tabs.close"
        displayText: ""
        hideText: true
        tooltipKey: "tabs.close"
        contentItem: ActionIcon { tag: header.tag + ".close.icon"; source: header.closeIconSource; resourceKey: header.closeIconKey; imageComponent: header.closeIconContent; glyph: header.appearance.closeGlyph; tint: header.appearance.accentText }
        visible: header.closable && !header.windowCaption
        onActivated: header.closeRequested(header.port.currentKey)
    }
    Component.onCompleted: bridge.attach(header)
}
