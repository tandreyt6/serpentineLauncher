import QtQuick
import QtQuick.Templates as T
import Working.Gui

ListView {
    id: control
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    clip: true
    reuseItems: true
    boundsBehavior: Flickable.StopAtBounds
    keyNavigationEnabled: true
    highlightMoveDuration: bridge.reducedMotion ? 0 : appearance.duration
    ComponentBridge { id: bridge; componentType: "ListWidget"; tag: control.tag; textFromTag: false }
    WheelScroll { flickable: control; step: control.appearance.scrollStep; duration: control.appearance.scrollDuration; easing: control.appearance.scrollEasing; reducedMotion: bridge.reducedMotion }
    T.ScrollBar.vertical: ScrollBar { tag: control.tag + ".scrollbar" }
    add: Transition {
        NumberAnimation { properties: "opacity"; from: 0; to: 1; duration: bridge.reducedMotion ? 0 : control.appearance.duration }
    }
    move: Transition {
        NumberAnimation { properties: "x,y"; duration: bridge.reducedMotion ? 0 : control.appearance.duration; easing.type: control.appearance.motionEasing }
    }
    Component.onCompleted: bridge.attach(control)
}
