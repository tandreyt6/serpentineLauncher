import QtQuick
import QtQuick.Controls as C
import Working.Gui

Widget {
    id: control
    componentType: "CollectionArea"
    property var model
    property Component delegate: defaultDelegate
    property string mode: "grid"
    property string sizePreset: "normal"
    property string selectedKey: ""
    property string keyRole: "key"
    property string textRole: "text"
    property string secondaryRole: "secondary"
    property string iconRole: "icon"
    property string stateRole: "state_key"
    property string enabledRole: "enabled"
    property real elementWidth: sizePreset === "small" ? appearance.cardSmallWidth : appearance.cardWidth
    property real elementHeight: sizePreset === "small" ? appearance.cardSmallHeight : appearance.cardHeight
    property real rowHeight: appearance.collectionRowHeight
    readonly property real contentY: viewport.contentY
    readonly property int count: viewport.count
    readonly property alias viewport: viewport
    property var scrollAnchor: ({key: "", index: 0, offset: 0})
    property bool restoringScroll: false
    signal selectionRequested(string key)
    signal activated(string key)
    signal contextRequested(string key, real x, real y)
    padding: 0
    rightPadding: appearance.scrollbarWidth + appearance.spacing
    LocalStateStore { id: localStateStore; capacity: control.setting("collection.state_entries") }
    contentItem: GridView {
        id: viewport
        clip: true
        model: control.model
        onContentYChanged: {
            if (control.restoringScroll || count === 0) return
            const index = indexAt(1, contentY + 1)
            const item = itemAtIndex(index)
            if (item) control.scrollAnchor = ({key: item.record[control.keyRole], index: index, offset: contentY - item.y})
        }
        delegate: Item {
            required property var model
            required property int index
            readonly property var record: model.modelData === undefined ? model : model.modelData
            width: control.mode === "list" ? viewport.width : Math.min(viewport.width, control.elementWidth)
            height: control.mode === "list" ? control.rowHeight : control.elementHeight
            DelegateHost {
                id: delegateHost
                anchors.fill: parent
                stateStore: localStateStore
                sourceComponent: control.delegate
                collectionContext: ({ key: parent.record[control.keyRole], text: parent.record[control.textRole], secondary: parent.record[control.secondaryRole], icon: parent.record[control.iconRole], stateKey: parent.record[control.stateRole], enabled: parent.record[control.enabledRole], selected: control.selectedKey === parent.record[control.keyRole], progress: parent.record.progress, detail: parent.record.detail, path: parent.record.path, kind: parent.record.kind, pinned: parent.record.pinned, width: parent.width, height: parent.height })
            }
            GridView.onPooled: delegateHost.remember()
            Component.onDestruction: delegateHost.remember()
        }
        reuseItems: true
        cellWidth: control.mode === "list" ? width : Math.min(width, control.elementWidth + control.appearance.spacing)
        cellHeight: (control.mode === "list" ? control.rowHeight : control.elementHeight) + control.appearance.spacing
        cacheBuffer: cellHeight * control.appearance.collectionCacheRows
        boundsBehavior: Flickable.StopAtBounds
        add: Transition { NumberAnimation { properties: "opacity"; from: 0; to: 1; duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration } }
        remove: Transition { NumberAnimation { properties: "opacity"; to: 0; duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration } }
        displaced: Transition { NumberAnimation { properties: "x,y"; duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing } }
        move: Transition { NumberAnimation { properties: "x,y"; duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing } }
        C.ScrollBar.vertical: ScrollBar { tag: control.tag + ".scrollbar"; parent: control; x: control.width - width; y: 0; height: control.height }
    }
    Component {
        id: defaultDelegate
        Frame {
            id: cell
            tag: control.tag + ".entry"
            stateKey: collectionContext.stateKey === undefined ? "" : collectionContext.stateKey
            enabled: collectionContext.enabled !== false
            UiText { anchors.fill: parent; tag: control.tag + ".text"; displayText: cell.collectionContext.text === undefined ? "" : cell.collectionContext.text; elide: Text.ElideRight }
            TapHandler { onTapped: { control.selectedKey = cell.collectionContext.key; control.selectionRequested(cell.collectionContext.key) } onDoubleTapped: control.activated(cell.collectionContext.key) }
            TapHandler { acceptedButtons: Qt.RightButton; onTapped: control.contextRequested(cell.collectionContext.key, point.position.x, point.position.y) }
        }
    }
    function positionAt(index) { viewport.positionViewAtIndex(index, GridView.Contain) }
    function restoreScrollAnchor() {
        if (!viewport || !viewport.count || restoringScroll) return
        restoringScroll = true
        Qt.callLater(function() {
            let index = model && model.indexOf ? model.indexOf(scrollAnchor.key) : Array.isArray(model) ? model.findIndex(entry => entry[keyRole] === scrollAnchor.key) : scrollAnchor.index
            index = Math.max(0, Math.min(viewport.count - 1, index < 0 ? scrollAnchor.index : index))
            viewport.positionViewAtIndex(index, GridView.Beginning)
            viewport.contentY = Math.max(0, Math.min(Math.max(0, viewport.contentHeight - viewport.height), viewport.contentY + scrollAnchor.offset))
            restoringScroll = false
        })
    }
    onModeChanged: restoreScrollAnchor()
    onElementWidthChanged: restoreScrollAnchor()
    onElementHeightChanged: restoreScrollAnchor()
    onRowHeightChanged: restoreScrollAnchor()
    onWidthChanged: restoreScrollAnchor()
}
