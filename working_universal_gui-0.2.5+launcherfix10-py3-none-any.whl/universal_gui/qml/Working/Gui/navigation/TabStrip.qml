import QtQuick
import Working.Gui

TabDropTarget {
    id: strip
    header: true
    groupKey: port.groupKey
    required property var port
    required property var appearance
    property url closeIconSource
    property string closeIconKey: appearance.tabCloseIconKey
    property Component closeIconContent
    property url detachIconSource
    property string detachIconKey: appearance.tabDetachIconKey
    property Component detachIconContent
    property bool allowDetach: false
    property bool closable: true
    property bool showDetachButton: false
    property bool dockPresentation: false
    property bool windowCaption: false
    property bool contentSized: false
    readonly property real actionSpace: appearance.tabActionInset + (appearance.tabActionSize + appearance.tabActionGap) * ((allowDetach && showDetachButton ? 1 : 0) + (closable ? 1 : 0))
    FontMetrics {
        id: titleMetrics
        font.family: strip.appearance.fontFamily
        font.pixelSize: strip.appearance.fontSize
    }
    readonly property var tabGeometry: {
        if (!contentSized || !port) return []
        const entries = port.entries
        const minimum = appearance.tabMinimumWidth
        const gap = appearance.tabGap
        const desired = entries.map(entry => Math.max(minimum, Math.ceil(titleMetrics.advanceWidth(entry.title)) + appearance.controlPadding + actionSpace + appearance.tabActionGap))
        const total = desired.reduce((sum, width) => sum + width, 0)
        const available = Math.max(0, scroll.width - gap * Math.max(0, desired.length - 1))
        const extra = total - minimum * desired.length
        const ratio = extra > 0 ? Math.max(0, Math.min(1, (available - minimum * desired.length) / extra)) : 1
        let position = 0
        return desired.map((width, index) => {
            const actual = dockPresentation && entries.length === 1 ? scroll.width : minimum + (width - minimum) * ratio
            const result = {key: entries[index].key, x: position, width: actual}
            position += actual + gap
            return result
        })
    }
    signal closeRequested(string key)
    signal captionDoubleClicked()
    readonly property real tabWidth: dockPresentation && headers.count === 1 ? scroll.width : Math.max(appearance.tabMinimumWidth, Math.min(appearance.tabWidth, (scroll.width - appearance.tabGap * Math.max(0, headers.count - 1)) / Math.max(1, headers.count)))
    readonly property real tabStride: tabWidth + appearance.tabGap
    readonly property real scrollOffset: scroll.contentX
    readonly property real detachDistance: port.detachDistance
    implicitHeight: appearance.tabHeight
    ListModel { id: headers }
    function syncHeaders() {
        const entries = port.entries
        for (let i = headers.count - 1; i >= 0; --i) {
            if (!entries.some(tab => tab.key === headers.get(i).key)) headers.remove(i)
        }
        for (let i = 0; i < entries.length; ++i) {
            const entry = entries[i]
            let found = -1
            for (let j = i; j < headers.count; ++j) {
                if (headers.get(j).key === entry.key) { found = j; break }
            }
            if (found < 0) headers.insert(i, entry)
            else {
                if (found !== i) headers.move(found, i, 1)
                headers.setProperty(i, "title", entry.title)
                headers.setProperty(i, "selected", entry.selected)
            }
        }
    }
    function revealSelection() {
        let index = -1
        for (let i = 0; i < headers.count; ++i) {
            if (headers.get(i).selected) { index = i; break }
        }
        if (index < 0 || scroll.width <= 0) return
        const bounds = contentSized ? tabGeometry[index] : null
        const left = bounds ? bounds.x : index * tabStride
        const right = left + (bounds ? bounds.width : tabWidth)
        if (left < scroll.contentX) scroll.contentX = left
        else if (right > scroll.contentX + scroll.width) scroll.contentX = right - scroll.width
    }
    Connections { target: strip.port; function onWorkspaceChanged() { strip.syncHeaders(); Qt.callLater(strip.revealSelection) } }
    Component.onCompleted: syncHeaders()
    Flickable {
        id: scroll
        anchors.fill: parent
        contentWidth: strip.contentSized ? strip.tabGeometry.length ? strip.tabGeometry[strip.tabGeometry.length - 1].x + strip.tabGeometry[strip.tabGeometry.length - 1].width : 0 : headers.count * strip.tabStride - (headers.count ? strip.appearance.tabGap : 0)
        clip: true
        flickableDirection: Flickable.HorizontalFlick
        onWidthChanged: Qt.callLater(strip.revealSelection)
        onContentWidthChanged: Qt.callLater(strip.revealSelection)
        WheelScroll { flickable: scroll; step: strip.appearance.scrollStep; horizontalWheel: true; duration: strip.appearance.scrollDuration; easing: strip.appearance.scrollEasing; reducedMotion: strip.port.reducedMotion }
        Repeater {
            model: headers
            delegate: TabDragHandle {
                id: tab
                required property string key
                required property string titleTag
                required property string title
                required property bool selected
                required property int index
                groupKey: strip.port.groupKey
                tabKey: key
                objectName: "tab." + key
                width: strip.contentSized && strip.tabGeometry[index] ? strip.tabGeometry[index].width : strip.tabWidth
                height: strip.height
                property real dragOffset: 0
                readonly property real slotX: strip.contentSized && strip.tabGeometry[index] ? strip.tabGeometry[index].x : index * strip.tabStride
                readonly property real floatingWidth: strip && strip.windowCaption && Window.window ? Window.window.width : (strip && strip.parent ? strip.parent.width : 0) + (Window.window ? Window.window.frameInset * 2 : 0)
                readonly property real floatingHeight: strip && strip.windowCaption && Window.window ? Window.window.height : (strip && strip.parent ? strip.parent.height : 0) + (Window.window ? Window.window.frameInset * 2 + Window.window.appearance.titlebarHeight : 0)
                Connections { target: tab; function onActiveChanged() { if (!tab.activeDrag) drag.initiated = false } }
                onSlotXChanged: { if (activeDrag) strip.port.refreshDrag() }
                onWidthChanged: { if (activeDrag) strip.port.refreshDrag() }
                x: slotX + dragOffset
                z: activeDrag ? 1 : 0
                Behavior on x { enabled: !tab.activeDrag; NumberAnimation { duration: select.appearance.duration; easing.type: select.appearance.motionEasing } }
                readonly property real actionSpace: strip.appearance.tabActionInset + (strip.appearance.tabActionSize + strip.appearance.tabActionGap) * ((strip.allowDetach && strip.showDetachButton ? 1 : 0) + (strip.closable ? 1 : 0))
                Button {
                    id: select
                    anchors.fill: parent
                    tag: tab.titleTag
                    text: tab.title
                    hideText: true
                    checked: tab.selected
                    onActivated: strip.port.selectTab(tab.key)
                }
                Text {
                    anchors.fill: parent
                    anchors.leftMargin: select.appearance.controlPadding
                    anchors.rightMargin: tab.actionSpace
                    text: tab.title
                    elide: Text.ElideRight
                    verticalAlignment: Text.AlignVCenter
                    color: select.appearance.accentText
                    font.family: select.appearance.fontFamily
                    font.pixelSize: select.appearance.fontSize
                }
                ToolButton {
                    anchors.right: parent.right
                    anchors.rightMargin: strip.appearance.tabActionInset + (strip.closable ? strip.appearance.tabActionSize + strip.appearance.tabActionGap : 0)
                    anchors.verticalCenter: parent.verticalCenter
                    width: strip.appearance.tabActionSize
                    height: width
                    tag: "tabs.detach"
                    displayText: ""; hideText: true; tooltipKey: "tabs.detach"
                    contentItem: ActionIcon { tag: strip.groupKey + ".detach.icon"; source: strip.detachIconSource; resourceKey: strip.detachIconKey; imageComponent: strip.detachIconContent; glyph: strip.appearance.detachGlyph; tint: strip.appearance.accentText }
                    visible: strip.allowDetach && strip.showDetachButton
                    onActivated: strip.port.detachTab(tab.key)
                }
                ToolButton {
                    anchors.right: parent.right
                    anchors.rightMargin: strip.appearance.tabActionInset
                    anchors.verticalCenter: parent.verticalCenter
                    width: strip.appearance.tabActionSize
                    height: width
                    tag: "tabs.close"
                    displayText: ""; hideText: true; tooltipKey: "tabs.close"
                    contentItem: ActionIcon { tag: strip.groupKey + ".close.icon"; source: strip.closeIconSource; resourceKey: strip.closeIconKey; imageComponent: strip.closeIconContent; glyph: strip.appearance.closeGlyph; tint: strip.appearance.accentText }
                    visible: strip.closable
                    onActivated: strip.closeRequested(tab.key)
                }
                MouseArea {
                    id: drag
                    anchors.fill: select
                    anchors.rightMargin: tab.actionSpace
                    acceptedButtons: Qt.LeftButton
                    preventStealing: true
                    property real pressedX
                    property real pressedY
                    property bool initiated: false
                    onPressed: mouse => { pressedX = mouse.x; pressedY = mouse.y; initiated = false; strip.port.selectTab(tab.key) }
                    onPositionChanged: mouse => {
                        if (pressed && !initiated && Math.hypot(mouse.x - pressedX, mouse.y - pressedY) >= Qt.styleHints.startDragDistance) {
                            initiated = strip.port.beginDrag(tab.key, tab, mouse.x, mouse.y, pressedX, pressedY)
                        }
                    }
                    onReleased: initiated = false
                    onCanceled: initiated = false
                    onDoubleClicked: { if (strip.windowCaption) strip.captionDoubleClicked() }
                }
            }
        }
    }
}
