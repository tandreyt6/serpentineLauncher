import QtQuick
import Working.Gui

Item {
    id: control
    clip: true
    enum DetachMode { Locked, Allowed }
    required property string tag
    property string componentType: "DetachableTabs"
    property bool dockPresentation: false
    property Item captionItem: null
    property bool preserveOnClose: false
    signal panelCloseRequested(string key)
    signal captionDoubleClicked()
    property string groupKey: tag
    property var model: []
    property bool closable: true
    property bool contentSized: false
    property url closeIconSource
    property string closeIconKey: appearance.tabCloseIconKey
    property Component closeIconContent
    property url detachIconSource
    property string detachIconKey: appearance.tabDetachIconKey
    property Component detachIconContent
    property int detachMode: DetachableTabs.Allowed
    property bool existingGroup: false
    property bool showDetachButton: false
    property bool contentDropEnabled: false
    readonly property int count: tabPort.entries.length
    readonly property bool externalDockCaption: dockPresentation && captionItem !== null
    readonly property real contentTopMargin: (strip.visible && strip.parent === control ? strip.height : 0) + (groupHeader.visible && groupHeader.parent === control ? groupHeader.height : 0) + (panelHeader.visible && panelHeader.parent === control ? panelHeader.height : 0)
    readonly property bool dragging: tabPort.dragging
    readonly property string currentTitle: {
        const selected = tabPort.entries.find(tab => tab.selected)
        return selected ? selected.title : ""
    }
    readonly property alias appearance: tabPort.style
    readonly property alias instanceToken: tabPort.token
    property alias scopeKey: tabPort.scopeKey
    property alias floatingClosePolicy: tabPort.floatingClosePolicy
    property alias floatingEmptyPolicy: tabPort.floatingEmptyPolicy
    property alias floatingHeaderLeft: tabPort.floatingHeaderLeft
    property alias floatingHeaderRight: tabPort.floatingHeaderRight
    property alias floatingHeaderContent: tabPort.floatingHeaderContent
    property alias floatingBodyContent: tabPort.floatingBodyContent
    property alias ownerContextKey: tabPort.ownerContextKey
    property alias stateKey: tabPort.stateKey
    property alias density: tabPort.density
    property alias typographyRole: tabPort.typographyRole
    property alias textKey: tabPort.textKey
    property alias displayText: tabPort.displayText
    property alias useDisplayText: tabPort.useDisplayText
    readonly property alias currentKey: tabPort.currentKey
    QtObject {
        id: visualState
        readonly property var style: tabPort.paintStyle
        readonly property string stateKey: tabPort.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: tabPort.reducedMotion
        readonly property bool suspended: !control.visible
        readonly property bool dockPresentation: control.dockPresentation
        readonly property int count: control.count
        function assetUrl(key) { return tabPort.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: tabPort.visual; viewState: visualState }
    Rectangle {
        anchors.fill: parent
        visible: tabPort.entries.length === 0
        color: control.appearance.surface
        radius: control.appearance.radius
        border.color: control.appearance.border
        border.width: control.appearance.borderWidth
        UiText { anchors.centerIn: parent; tag: "tabs.empty"; width: parent.width; horizontalAlignment: Text.AlignHCenter }
    }
    function selectTab(key) { tabPort.selectTab(key) }
    function addTab(key, titleTag, source) { tabPort.addTab(key, titleTag, source.toString()) }
    function removeTab(key) { tabPort.removeTab(key) }
    function detachTab(key) { return tabPort.detachTab(key) }
    function reattachTab(key) { return tabPort.reattachTab(key) }
    function moveTab(key, index) { return tabPort.moveTab(key, groupKey, index) }
    function closeFloatingGroup() { tabPort.closeFloatingGroup() }
    function respondClose(accepted, policy) { return tabPort.respondClose(accepted, policy === undefined ? "default" : policy) }
    function hideDockPanel(key) { tabPort.hideDockPanel(key) }
    WorkspaceBridge { id: tabPort; componentType: control.componentType; tag: control.tag; textFromTag: false }
    DockCaption {
        id: panelHeader
        parent: control.externalDockCaption ? control.captionItem : control
        width: parent.width
        visible: control.dockPresentation && control.count === 1
        height: windowCaption ? parent.height : control.appearance.tabHeight
        windowCaption: control.externalDockCaption
        closable: control.closable
        port: tabPort; closeIconSource: control.closeIconSource; closeIconKey: control.closeIconKey; closeIconContent: control.closeIconContent
        tag: control.tag
        appearance: control.appearance
        onCloseRequested: key => { if (control.preserveOnClose) control.panelCloseRequested(key); else tabPort.removeTab(key) }
        onCaptionDoubleClicked: control.captionDoubleClicked()
    }
    DockGroupHeader {
        id: groupHeader
        parent: control.externalDockCaption && control.count > 1 ? control.captionItem : control
        width: parent.width
        visible: control.dockPresentation && control.count > 1
        height: visible ? windowCaption ? parent.height : control.appearance.dockTitleHeight : 0
        windowCaption: control.externalDockCaption
        port: tabPort; closeIconSource: control.closeIconSource; closeIconKey: control.closeIconKey; closeIconContent: control.closeIconContent
        tag: control.tag
        appearance: control.appearance
        onCaptionDoubleClicked: control.captionDoubleClicked()
    }
    TabStrip {
        id: strip
        anchors.top: parent.top
        anchors.topMargin: groupHeader.parent === control ? groupHeader.height : 0
        width: parent.width
        height: windowCaption ? parent.height : control.appearance.tabHeight
        visible: control.count > 0 && (!control.dockPresentation || control.count > 1)
        dockPresentation: control.dockPresentation
        contentSized: control.contentSized
        port: tabPort; closeIconSource: control.closeIconSource; closeIconKey: control.closeIconKey; closeIconContent: control.closeIconContent; detachIconSource: control.detachIconSource; detachIconKey: control.detachIconKey; detachIconContent: control.detachIconContent
        appearance: control.appearance
        allowDetach: control.detachMode === DetachableTabs.Allowed
        showDetachButton: control.showDetachButton
        closable: control.closable && !windowCaption
        onCloseRequested: key => { if (control.preserveOnClose) control.panelCloseRequested(key); else tabPort.removeTab(key) }
        onCaptionDoubleClicked: control.captionDoubleClicked()
    }
    TabContentHost {
        id: content
        anchors.fill: parent
        anchors.topMargin: control.contentTopMargin
        groupKey: tabPort.groupKey
        tabKey: tabPort.currentKey
    }
    SurfaceMotion { id: reveal; targetItem: content; appearance: control.appearance; reducedMotion: tabPort.reducedMotion; suspended: !control.visible }
    Connections { target: tabPort; function onWorkspaceChanged() { content.refreshPlacement() } }
    Connections { target: content; function onSelectionChanged() { reveal.restart() } }
    TabDropTarget {
        anchors.fill: parent
        anchors.topMargin: control.contentTopMargin
        groupKey: tabPort.groupKey
        visible: control.contentDropEnabled && tabPort.dragging
    }
    onDetachModeChanged: tabPort.setDetachable(detachMode === DetachableTabs.Allowed)
    Component.onCompleted: { tabPort.attach(control); tabPort.initialize(groupKey, model, detachMode === DetachableTabs.Allowed, existingGroup) }
    Component.onDestruction: { tabPort.releaseGroup(); tabPort.detach() }
}
