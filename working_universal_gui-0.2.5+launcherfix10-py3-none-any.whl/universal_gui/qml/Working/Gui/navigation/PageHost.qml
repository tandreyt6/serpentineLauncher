import QtQuick
import Working.Gui

Loader {
    id: host
    required property string tag
    required property string windowKey
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    source: { Gui.navigationRevision; return Gui.pageSource(windowKey) }
    ComponentBridge { id: bridge; componentType: "PageHost"; tag: host.tag; textFromTag: false }
    SurfaceMotion { id: reveal; targetItem: host; appearance: bridge.style; reducedMotion: bridge.reducedMotion; suspended: !host.visible }
    onLoaded: reveal.restart()
    Component.onCompleted: bridge.attach(host)
}
