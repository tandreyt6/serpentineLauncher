import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    componentType: "NavigationPanel"
    property url toggleIconSource
    property string toggleIconKey: appearance.toggleIconKey
    property Component toggleIconContent
    property var model: []
    property string selectedKey: ""
    property string revealMode: "hover+button"
    property string placement: "left"
    property string layoutMode: "overlay"
    property string alignment: "top"
    property bool opened: false
    property int animationDuration: control.setting("navigation.duration_ms")
    property int animationEasing: Easing.OutQuad
    property string labelPolicy: "clip"
    property real iconInset: appearance.navigationIconInset
    property real textInset: appearance.navigationTextInset
    readonly property bool expanded: revealMode === "always-open" || (revealMode === "button" || revealMode === "hover+button") && opened || (revealMode === "hover" || revealMode === "hover+button") && hover.hovered
    readonly property real reservedWidth: implicitWidth
    property real panelWidth: expanded ? appearance.navigationExpandedWidth : appearance.navigationCollapsedWidth
    signal pageRequested(string key)
    implicitWidth: layoutMode === "push" ? panelWidth : appearance.navigationCollapsedWidth
    width: implicitWidth
    Behavior on panelWidth { NumberAnimation { duration: control.reducedMotion || control.suspended ? 0 : control.animationDuration; easing.type: control.animationEasing } }
    background.width: panelWidth
    background.x: placement === "right" ? width - panelWidth : 0
    HoverHandler { id: hover; parent: control.contentItem }
    contentItem: ColumnLayout {
        width: Math.max(0, control.panelWidth - control.leftPadding - control.rightPadding)
        x: (control.placement === "right" ? control.width - control.panelWidth : 0) + control.leftPadding
        spacing: control.appearance.spacing
        ToolButton {
            tag: control.tag + ".expand"
            displayText: ""; hideText: true; contentItem: ActionIcon { tag: control.tag + ".toggleIcon"; source: control.toggleIconSource; resourceKey: control.toggleIconKey; imageComponent: control.toggleIconContent; glyph: control.appearance.comboGlyph; tint: control.appearance.accentText; stateKey: control.stateKey }
            tooltipKey: "framework.navigation.toggle"
            visible: control.revealMode === "button" || control.revealMode === "hover+button"
            onActivated: control.opened = !control.opened
        }
        Item { Layout.fillHeight: control.alignment === "center" }
        Repeater {
            model: control.model && control.model.get ? control.model.count : control.model
            delegate: NavigationButton {
                required property int index
                readonly property var entry: { if (control.model && control.model.get) { control.model.dataRevision; return control.model.get(index) }; return control.model[index] }
                tag: control.tag + ".entry"
                key: entry.key
                textKey: entry.text_key || entry.tag || ""
                displayText: entry.text === undefined ? "" : entry.text
                useDisplayText: !textKey.length
                enabled: entry.enabled !== false
                navigationIcon: entry.icon === undefined ? "" : entry.icon
                expanded: control.expanded
                labelPolicy: control.labelPolicy
                iconInset: control.iconInset
                textInset: control.textInset
                selected: key === control.selectedKey
                stateKey: entry.state_key === undefined ? selected ? "selected" : control.stateKey : entry.state_key
                tooltip: expanded ? "" : text
                Layout.fillWidth: true
                onActivated: control.pageRequested(key)
            }
        }
        Item { Layout.fillHeight: true }
    }
}
