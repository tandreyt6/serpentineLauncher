import QtQuick

Item {
    id: scroll
    required property Flickable flickable
    required property real step
    required property int duration
    required property int easing
    property bool reducedMotion: false
    property bool horizontalWheel: false

    function moveAxis(animation, propertyName, value, immediate) {
        animation.stop()
        if (immediate || reducedMotion || duration === 0) {
            flickable[propertyName] = value
            return
        }
        animation.from = flickable[propertyName]
        animation.to = value
        if (animation.from !== animation.to) animation.start()
    }

    function finishMotion() {
        if (horizontalMotion.running) horizontalMotion.complete()
        if (verticalMotion.running) verticalMotion.complete()
    }

    function applyWheel(event) {
        flickable.cancelFlick()
        let dx = event.pixelDelta.x
        let dy = event.pixelDelta.y
        const immediate = dx !== 0 || dy !== 0
        if (dx === 0 && dy === 0) {
            dx = event.angleDelta.x / 120 * step
            dy = event.angleDelta.y / 120 * step
        }
        if (horizontalWheel && dx === 0) { dx = dy; dy = 0 }
        const left = flickable.originX - flickable.leftMargin
        const top = flickable.originY - flickable.topMargin
        const right = Math.max(left, flickable.originX + flickable.contentWidth - flickable.width + flickable.rightMargin)
        const bottom = Math.max(top, flickable.originY + flickable.contentHeight - flickable.height + flickable.bottomMargin)
        if (dx !== 0) {
            const x = !immediate && horizontalMotion.running ? horizontalMotion.to : flickable.contentX
            moveAxis(horizontalMotion, "contentX", Math.max(left, Math.min(right, x - dx)), immediate)
        }
        if (dy !== 0) {
            const y = !immediate && verticalMotion.running ? verticalMotion.to : flickable.contentY
            moveAxis(verticalMotion, "contentY", Math.max(top, Math.min(bottom, y - dy)), immediate)
        }
        event.accepted = true
    }

    NumberAnimation {
        id: horizontalMotion
        target: scroll.flickable
        property: "contentX"
        duration: scroll.duration
        easing.type: scroll.easing
    }
    NumberAnimation {
        id: verticalMotion
        target: scroll.flickable
        property: "contentY"
        duration: scroll.duration
        easing.type: scroll.easing
    }
    Connections {
        target: scroll.flickable
        function onDraggingChanged() { if (scroll.flickable.dragging) { horizontalMotion.stop(); verticalMotion.stop() } }
    }
    TapHandler {
        parent: scroll.flickable
        onPressedChanged: { if (pressed) { horizontalMotion.stop(); verticalMotion.stop() } }
    }
    onReducedMotionChanged: { if (reducedMotion) finishMotion() }
    onVisibleChanged: { if (!visible) finishMotion() }

    WheelHandler {
        parent: scroll.flickable
        target: null
        enabled: scroll.flickable.interactive
        blocking: true
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        orientation: Qt.Vertical
        onWheel: event => scroll.applyWheel(event)
    }
    WheelHandler {
        parent: scroll.flickable
        target: null
        enabled: scroll.flickable.interactive
        blocking: true
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        orientation: Qt.Horizontal
        onWheel: event => scroll.applyWheel(event)
    }
}
