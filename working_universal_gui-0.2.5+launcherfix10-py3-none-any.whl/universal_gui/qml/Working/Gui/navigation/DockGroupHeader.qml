import Working.Gui

DockCaption {
    componentType: "DockGroupHeader"
    wholeGroup: true
}
