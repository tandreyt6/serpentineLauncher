import QtQuick
import Working.Gui

Item {
    id: control
    required property string tag
    property var model: []
    property bool dockingEnabled: true
    readonly property alias appearance: port.style
    readonly property alias instanceToken: port.token
    property alias stateKey: port.stateKey
    property alias density: port.density
    property alias typographyRole: port.typographyRole
    property alias textKey: port.textKey
    property alias displayText: port.displayText
    property alias useDisplayText: port.useDisplayText
    readonly property bool reducedMotion: port.reducedMotion
    readonly property alias layout: port.layout
    readonly property alias dropPreview: port.preview
    readonly property var previewSnapshot: port.preview
    clip: true
    DockBridge { id: port; componentType: "DockHost"; tag: control.tag; textFromTag: false }
    DockSurface {
        id: surface
        anchors.fill: parent
        readonly property real floatingInset: Window.window ? Window.window.frameInset : 0
        readonly property real floatingTitleHeight: Window.window ? Window.window.appearance.titlebarHeight : 0
    }
    ListModel { id: panels }
    ListModel { id: handles }
    function updateModel(target, rows) {
        for (let i = target.count - 1; i >= 0; --i) {
            if (!rows.some(row => row.key === target.get(i).key)) target.remove(i)
        }
        for (let i = 0; i < rows.length; ++i) {
            let found = -1
            for (let j = i; j < target.count; ++j) {
                if (target.get(j).key === rows[i].key) { found = j; break }
            }
            if (found < 0) target.insert(i, rows[i])
            else {
                if (found !== i) target.move(found, i, 1)
                target.set(i, rows[i])
            }
        }
    }
    function updateLayout() {
        const snapshot = port.layout
        updateModel(panels, snapshot.panels)
        updateModel(handles, snapshot.splits)
    }
    function resizeLayout() { port.resize(width, height, appearance.dockGap, appearance.dockMinimumSize) }
    function setSplitRatio(key, ratio) { port.setRatio(key, ratio) }
    function showPanel(key) { return port.showPanel(key) }
    function addPanel(key, titleTag, source, area = "center") { port.addPanel(key, titleTag, source.toString(), area) }
    function removePanel(key) { return port.removePanel(key) }
    QtObject {
        id: visualState
        readonly property var style: port.paintStyle
        readonly property string stateKey: port.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: port.reducedMotion
        readonly property bool suspended: !control.visible
        function assetUrl(key) { return port.assetUrl(key) }
    }
    VisualHost { anchors.fill: parent; source: port.visual; viewState: visualState }
    Repeater {
        model: panels
        delegate: DockWindow {
            id: panel
            required property string key
            required property bool modelVisible
            required property real modelX
            required property real modelY
            required property real modelWidth
            required property real modelHeight
            required property bool animate
            tag: control.tag
            groupKey: key
            existingGroup: true
            preserveOnClose: true
            onPanelCloseRequested: key => port.hidePanel(groupKey, key)
            visible: modelVisible
            x: modelX
            y: modelY
            width: modelWidth
            height: modelHeight
            detachMode: control.dockingEnabled ? DetachableTabs.Allowed : DetachableTabs.Locked
            objectName: "dock.panel." + key
            Behavior on x { enabled: panel.animate && !control.reducedMotion && !panel.dragging; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
            Behavior on y { enabled: panel.animate && !control.reducedMotion && !panel.dragging; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
        }
    }
    Repeater {
        model: handles
        delegate: MouseArea {
            required property string key
            required property bool horizontal
            required property real modelX
            required property real modelY
            required property real modelWidth
            required property real modelHeight
            required property real origin
            required property real span
            x: modelX
            y: modelY
            width: modelWidth
            height: modelHeight
            cursorShape: horizontal ? Qt.SplitHCursor : Qt.SplitVCursor
            objectName: "dock.split." + key
            property real grabOffset
            onPressed: mouse => grabOffset = horizontal ? mouse.x : mouse.y
            onPositionChanged: mouse => {
                if (pressed && span > 0) {
                    const point = mapToItem(control, mouse.x, mouse.y)
                    port.setRatio(key, ((horizontal ? point.x : point.y) - origin - grabOffset) / span)
                }
            }
            Rectangle { anchors.fill: parent; color: parent.pressed ? control.appearance.focus : parent.containsMouse ? control.appearance.border : control.appearance.background }
        }
    }
    Rectangle {
        id: preview
        visible: Object.keys(control.previewSnapshot).length > 0
        x: control.previewSnapshot.x || 0
        y: control.previewSnapshot.y || 0
        width: control.previewSnapshot.width || 0
        height: control.previewSnapshot.height || 0
        color: control.appearance.dropHighlight
        opacity: control.appearance.dockPreviewOpacity
        radius: control.appearance.radius
        border.color: control.appearance.focus
        border.width: control.appearance.focusWidth
        z: 2
        Behavior on x { enabled: !control.reducedMotion; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
        Behavior on y { enabled: !control.reducedMotion; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
        Behavior on width { enabled: !control.reducedMotion; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
        Behavior on height { enabled: !control.reducedMotion; NumberAnimation { duration: control.appearance.duration; easing.type: control.appearance.motionEasing } }
        Repeater {
            model: ["center", "left", "right", "top", "bottom"]
            delegate: UiText {
                required property string modelData
                anchors.centerIn: parent
                tag: "dock.preview." + modelData
                visible: modelData === control.previewSnapshot.edge
                width: parent.width
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.Wrap
            }
        }
    }
    Connections { target: port; function onLayoutChanged() { control.updateLayout() } function onStyleChanged() { control.resizeLayout() } }
    onWidthChanged: resizeLayout()
    onHeightChanged: resizeLayout()
    onDockingEnabledChanged: port.setEnabled(dockingEnabled)
    Component.onCompleted: { port.attach(control); port.initialize(tag, model, surface, dockingEnabled); resizeLayout() }
    Component.onDestruction: { port.release(); port.detach() }
}
