import QtQuick
import Working.Gui

Button {
    id: control
    componentType: "NavigationButton"
    hideText: true
    property string key: ""
    property bool expanded: true
    property bool selected: false
    property url navigationIcon
    property string labelPolicy: "clip"
    property real iconInset: appearance.navigationIconInset
    property real textInset: appearance.navigationTextInset
    property real labelWidth: appearance.navigationExpandedWidth - textInset
    property int labelAlignment: Text.AlignLeft
    property real iconSize: appearance.iconSize
    property color iconTint: appearance.accentText
    property color labelColor: appearance.accentText
    contentItem: Item {
        clip: true
        Icon { id: picture; tag: control.tag + ".icon"; source: control.navigationIcon; anchors.left: parent.left; anchors.leftMargin: control.iconInset; anchors.verticalCenter: parent.verticalCenter; width: control.iconSize; height: width; tint: control.iconTint; stateKey: control.stateKey }
        Text {
            x: control.textInset
            width: control.labelPolicy === "clip" ? control.labelWidth : Math.max(0, parent.width - x)
            anchors.verticalCenter: parent.verticalCenter
            text: control.text
            opacity: control.labelPolicy === "fade" ? control.expanded ? 1 : 0 : 1
            Behavior on opacity { NumberAnimation { duration: control.reducedMotion || control.suspended ? 0 : control.setting("navigation.duration_ms"); easing.type: Easing.OutQuad } }
            font.family: control.appearance.fontFamily
            font.pixelSize: control.appearance.fontSize
            color: control.labelColor
            horizontalAlignment: control.labelAlignment
            elide: control.labelPolicy === "clip" ? Text.ElideNone : Text.ElideRight
        }
    }
}
