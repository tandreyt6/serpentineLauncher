import QtQuick
import Working.Gui

AppWindow {
    id: window
    required property string groupKey
    property string scopeKey: "default"
    property var ownerContext: ({key: groupKey, scopeKey: scopeKey})
    property Component bodyComponent
    readonly property alias selectedKey: closePort.currentKey
    readonly property var windowContext: ({ownerKey: ownerContext.key, scopeKey: scopeKey, groupKey: groupKey, selectedKey: selectedKey})
    property bool dockPresentation: false
    minimumWidth: dockPresentation ? appearance.dockMinimumSize + frameInset * 2 : appearance.minimumWidth
    minimumHeight: dockPresentation ? appearance.dockMinimumSize + frameInset * 2 + appearance.titlebarHeight : appearance.minimumHeight
    customCaption: dockPresentation || captionComponent !== null
    title: { const tab = closePort.entries.find(tab => tab.selected); return tab ? textFor(tab.titleTag) : "" }
    function respondClose(accepted, policy) { return closePort.respondClose(accepted, policy === undefined ? "default" : policy) }
    WorkspaceBridge { id: closePort; componentType: "FloatingWindow"; tag: window.tag; textFromTag: false }
    Loader {
        id: content
        anchors.fill: parent
        active: !window.bodyComponent
        sourceComponent: window.dockPresentation ? dockContent : tabContent
    }
    Item {
        id: customBody
        anchors.fill: parent
        visible: window.bodyComponent !== null
        property Item page
        function build() {
            if (page) page.destroy()
            page = window.bodyComponent ? window.bodyComponent.createObject(customBody, {windowContext: window.windowContext, workspaceGroupKey: window.groupKey}) : null
            if (page) page.anchors.fill = customBody
        }
        Component.onCompleted: build()
        Connections { target: window; function onBodyComponentChanged() { customBody.build() } }
        Binding { target: customBody.page; property: "windowContext"; value: window.windowContext; when: customBody.page !== null }
    }
    Component {
        id: dockContent
        DockWindow {
            objectName: "floating.dock"
            tag: window.tag
            groupKey: window.groupKey
            existingGroup: true
            captionItem: window.nativeFrame ? null : window.captionItem
            preserveOnClose: true
            onPanelCloseRequested: key => hideDockPanel(key)
            onCaptionDoubleClicked: window.toggleMaximized()
        }
    }
    Component {
        id: tabContent
        DetachableTabs {
            objectName: "floating.tabs"
            tag: window.tag
            groupKey: window.groupKey
            existingGroup: true
        }
    }
    Component.onCompleted: closePort.initialize(groupKey, [], false, true)
    Component.onDestruction: closePort.releaseGroup()
    onClosing: close => { close.accepted = false; closePort.closeFloatingGroup() }
}
