import QtQuick
import QtQuick.Templates as T
import Working.Gui

Flickable {
    id: control
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    contentWidth: width
    contentHeight: contentItem.childrenRect.height
    ComponentBridge { id: bridge; componentType: "ScrollArea"; tag: control.tag; textFromTag: false }
    WheelScroll { flickable: control; step: control.appearance.scrollStep; duration: control.appearance.scrollDuration; easing: control.appearance.scrollEasing; reducedMotion: bridge.reducedMotion }
    T.ScrollBar.vertical: ScrollBar { tag: control.tag + ".scrollbar" }
    Component.onCompleted: bridge.attach(control)
}
