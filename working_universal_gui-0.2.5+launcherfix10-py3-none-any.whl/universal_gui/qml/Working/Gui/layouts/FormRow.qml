import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    textFromTag: true
    componentType: "FormRow"
    property string hint: ""
    property string validation: ""
    property real labelWidth: appearance.captionWidth
    property real narrowWidth: appearance.formNarrowWidth
    property int fieldAlignment: Qt.AlignRight | Qt.AlignVCenter
    default property alias field: fieldHost.data
    readonly property bool narrow: width < narrowWidth
    padding: 0
    contentItem: Item {
        readonly property real fieldsBottom: fieldHost.y + fieldHost.implicitHeight
        readonly property real mainBottom: Math.max(label.y + label.implicitHeight, fieldsBottom)
        implicitHeight: mainBottom + (hint.visible ? hint.implicitHeight + control.appearance.headingGap : 0)
        UiText { id: label; tag: control.tag + ".label"; displayText: control.caption; width: control.narrow ? parent.width : control.labelWidth; y: control.narrow ? 0 : control.fieldAlignment & Qt.AlignVCenter ? Math.max(0, (fieldHost.implicitHeight - implicitHeight) / 2) : control.fieldAlignment & Qt.AlignBottom ? Math.max(0, fieldHost.implicitHeight - implicitHeight) : 0 }
        ColumnLayout {
            id: fieldHost
            x: control.narrow ? 0 : control.labelWidth + control.appearance.spacing
            y: control.narrow ? label.implicitHeight + control.appearance.spacing : control.fieldAlignment & Qt.AlignVCenter ? Math.max(0, (label.implicitHeight - implicitHeight) / 2) : control.fieldAlignment & Qt.AlignBottom ? Math.max(0, label.implicitHeight - implicitHeight) : 0
            width: Math.max(0, parent.width - x)
            spacing: control.appearance.headingGap
            layoutDirection: control.fieldAlignment & Qt.AlignRight ? Qt.RightToLeft : Qt.LeftToRight
            height: implicitHeight
        }
        UiText { id: hint; tag: control.tag + ".hint"; displayText: control.validation.length ? control.validation : control.hint; typographyRole: "caption"; visible: text.length > 0; width: parent.width; y: parent.mainBottom + control.appearance.headingGap }
    }
}
