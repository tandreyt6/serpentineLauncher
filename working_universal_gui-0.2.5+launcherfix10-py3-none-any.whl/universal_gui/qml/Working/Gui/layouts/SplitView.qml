import QtQuick
import Working.Gui

Widget {
    id: control
    componentType: "SplitView"
    property bool ready: false
    clip: true
    property int orientation: Qt.Horizontal
    property var minimumSizes: []
    property var maximumSizes: []
    property var proportions: []
    property var preferredSizes: []
    property var collapsed: []
    property int activePane: 0
    default property alias panes: paneHost.data
    readonly property int count: paneHost.children.length
    signal proportionsChangedRequested(var values)
    padding: 0
    focus: true
    SplitLayout { id: solver }
    function sizes() { const result = []; for (let i = 0; i < count; ++i) result.push(orientation === Qt.Horizontal ? paneHost.children[i].width : paneHost.children[i].height); return result }
    function layoutPanes() {
        if (!ready || !count) return
        const available = Math.max(0, (orientation === Qt.Horizontal ? width : height) - appearance.splitHandleSize * (count - 1))
        const preferences = []
        for (let i = 0; i < count; ++i) preferences.push(preferredSizes[i] === undefined ? 1 : preferredSizes[i])
        const resolved = solver.solve(available, minimumSizes.slice(0, count), maximumSizes.slice(0, count), preferences, proportions.slice(0, count), collapsed.slice(0, count))
        let offset = 0
        for (let i = 0; i < count; ++i) {
            const pane = paneHost.children[i]
            const size = resolved[i]
            pane.x = orientation === Qt.Horizontal ? offset : 0
            pane.y = orientation === Qt.Vertical ? offset : 0
            pane.width = orientation === Qt.Horizontal ? size : width
            pane.height = orientation === Qt.Vertical ? size : height
            offset += size + appearance.splitHandleSize
        }
    }
    function resizeBoundary(index, delta) {
        if (index < 0 || index + 1 >= count) return
        const available = Math.max(1, (orientation === Qt.Horizontal ? width : height) - appearance.splitHandleSize * (count - 1))
        const ratios = []
        const measured = sizes()
        for (let i = 0; i < count; ++i) ratios.push(measured[i] / available)
        const total = (ratios[index] + ratios[index + 1]) * available
        const low = Math.max(minimumSizes[index] === undefined ? 0 : minimumSizes[index], total - (maximumSizes[index + 1] === undefined ? total : maximumSizes[index + 1]))
        const high = Math.min(maximumSizes[index] === undefined ? total : maximumSizes[index], total - (minimumSizes[index + 1] === undefined ? 0 : minimumSizes[index + 1]))
        const size = Math.max(0, Math.min(total, Math.max(low, Math.min(Math.max(low, high), ratios[index] * available + delta))))
        ratios[index] = size / available
        ratios[index + 1] = (total - size) / available
        proportions = ratios
        proportionsChangedRequested(ratios)
    }
    function setCollapsed(index, value) { if (index < 0 || index >= count) throw new Error("Unknown pane"); if (!proportions.length) proportions = saveLayout(); const values = collapsed.slice(); values[index] = value; collapsed = values }
    function saveLayout() { const values = sizes(); const total = values.reduce((sum, value) => sum + value, 0); return values.map(value => total ? value / total : 0) }
    function restoreLayout(values) { proportions = values.slice() }
    function saveState() { return ({proportions: proportions.length ? proportions.slice() : saveLayout(), collapsed: collapsed.slice(), orientation: orientation}) }
    function restoreState(value) { orientation = value.orientation; proportions = value.proportions.slice(); collapsed = value.collapsed.slice() }
    contentItem: Item { id: paneHost; onChildrenChanged: Qt.callLater(control.layoutPanes) }
    Repeater {
        model: Math.max(0, control.count - 1)
        delegate: Widget {
            required property int index
            componentType: "SplitHandle"
            tag: control.tag + ".handle." + index
            padding: 0
            parent: control
            x: control.orientation === Qt.Horizontal ? paneHost.children[index].x + paneHost.children[index].width : 0
            y: control.orientation === Qt.Vertical ? paneHost.children[index].y + paneHost.children[index].height : 0
            width: control.orientation === Qt.Horizontal ? control.appearance.splitHandleSize : control.width
            height: control.orientation === Qt.Vertical ? control.appearance.splitHandleSize : control.height
            interactionPressed: handle.pressed
            MouseArea {
                id: handle
                anchors.fill: parent
                property real previousPosition: 0
                cursorShape: control.orientation === Qt.Horizontal ? Qt.SplitHCursor : Qt.SplitVCursor
                onPressed: mouse => { previousPosition = control.orientation === Qt.Horizontal ? mapToItem(control, mouse.x, mouse.y).x : mapToItem(control, mouse.x, mouse.y).y; control.activePane = index; control.forceActiveFocus() }
                onPositionChanged: mouse => {
                    if (!pressed) return
                    const point = mapToItem(control, mouse.x, mouse.y)
                    const position = control.orientation === Qt.Horizontal ? point.x : point.y
                    control.resizeBoundary(index, position - previousPosition)
                    previousPosition = position
                }
            }
        }
    }
    Keys.onLeftPressed: resizeBoundary(activePane, -appearance.keyboardResizeStep)
    Keys.onRightPressed: resizeBoundary(activePane, appearance.keyboardResizeStep)
    Keys.onUpPressed: resizeBoundary(activePane, -appearance.keyboardResizeStep)
    Keys.onDownPressed: resizeBoundary(activePane, appearance.keyboardResizeStep)
    Keys.onSpacePressed: setCollapsed(activePane, collapsed[activePane] !== true)
    Component.onCompleted: { ready = true; Qt.callLater(layoutPanes) }
    onWidthChanged: layoutPanes()
    onHeightChanged: layoutPanes()
    onProportionsChanged: layoutPanes()
    onOrientationChanged: layoutPanes()
    onMinimumSizesChanged: layoutPanes()
    onMaximumSizesChanged: layoutPanes()
    onPreferredSizesChanged: layoutPanes()
    onCollapsedChanged: layoutPanes()
    onAppearanceChanged: layoutPanes()
}
