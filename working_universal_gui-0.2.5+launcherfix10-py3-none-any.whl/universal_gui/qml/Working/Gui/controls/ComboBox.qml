import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.ComboBox {
    id: control
    property bool searchable: false
    property url indicatorSource
    property string indicatorKey: appearance.comboIndicatorKey
    property Component indicatorContent
    property url searchIconSource
    property string searchIconKey: appearance.searchIconKey
    property Component searchIconContent
    property url clearIconSource
    property string clearIconKey: appearance.clearIconKey
    property Component clearIconContent
    property string searchText: ""
    property string selectedKey: ""
    property string secondaryRole: "secondary"
    property string iconRole: "icon"
    property string warningRole: "warning"
    property color warningColor: "#ef555f"
    property string enabledRole: "enabled"
    property string keyRole: "key"
    property string applicationValueRole: "value"
    property string searchOrder: "source"
    readonly property var selectedValue: selectedRecord[applicationValueRole]
    property real optionHeight: appearance.optionHeight
    property real optionPadding: appearance.optionPadding
    property real popupMaximumHeight: appearance.popupHeight
    property real popupWidth: width
    property real popupGap: appearance.popupGap
    property real popupRadius: appearance.radius
    property bool ready: false
    property bool modelChanging: false
    readonly property string resolvedTextRole: { search.source; return textRole === "tag" && !search.hasRole("tag") ? "text" : textRole }
    property string emptyText: { bridge.localeRevision; return bridge.textFor("framework.combo.empty") }
    readonly property var selectedRecord: { search.dataRevision; return search.sourceRow(currentIndex) }
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property alias textAlignment: selectedLabel.horizontalAlignment
    signal searchRequested(string query)
    signal selectionRequested(string key)
    signal valueRequested(string key, var value)
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias useDisplayText: bridge.useDisplayText
    implicitWidth: appearance.controlWidth
    implicitHeight: appearance.controlHeight
    padding: appearance.controlPadding
    rightPadding: appearance.controlPadding * 2
    textRole: "tag"
    valueRole: "key"
    displayText: { bridge.localeRevision; const key = rowTextKey(selectedRecord); return key.length ? bridge.textFor(key) : rowText(selectedRecord) }
    indicator: ActionIcon {
        tag: control.tag + ".indicator"
        x: control.width - control.padding - width
        y: (control.height - height) / 2
        source: control.indicatorSource
        resourceKey: control.indicatorKey
        imageComponent: control.indicatorContent
        glyph: control.appearance.comboGlyph
        tint: control.enabled ? control.appearance.foreground : control.appearance.disabledText
        stateKey: control.stateKey
    }
    wheelEnabled: false
    SearchProxy { id: search; source: control.model; query: control.searchable ? control.searchText : ""; textRole: control.resolvedTextRole; keyRole: control.keyRole; localeRevision: bridge.localeRevision; sortPolicy: control.searchOrder }
    function rowText(row) { return row[resolvedTextRole] === undefined ? "" : String(row[resolvedTextRole]) }
    function rowTextKey(row) { return row.text_key ? row.text_key : resolvedTextRole === "tag" && row.tag !== undefined ? String(row.tag) : "" }
    onSelectedKeyChanged: if (ready && !modelChanging) search.selectIndex(control, selectedKey.length ? search.sourceIndexOf(selectedKey) : -1)
    onCurrentIndexChanged: if (ready && !modelChanging && currentIndex >= 0) { const row = search.sourceRow(currentIndex); if (row[keyRole] !== undefined) search.selectKey(control, String(row[keyRole])) }
    function advanceOption(step) {
        for (let i = options.currentIndex + step; i >= 0 && i < options.count; i += step) {
            if (search.get(i)[enabledRole] !== false) { options.currentIndex = i; return }
        }
    }
    function positionPopup() {
        const window = Window.window
        if (!window) return
        popup.parent = window.contentItem
        const top = mapToItem(popup.parent, 0, 0)
        const point = mapToItem(popup.parent, 0, height + popupGap)
        const below = Math.max(0, popup.parent.height - point.y)
        const above = Math.max(0, top.y - popupGap)
        popup.placementHeight = Math.max(above, below)
        popup.x = Math.max(0, Math.min(point.x, popup.parent.width - popup.width))
        popup.y = below >= popup.height || below >= above ? point.y : top.y - popupGap - popup.height
        popup.y = Math.max(0, Math.min(popup.y, popup.parent.height - popup.height))
    }
    onSearchTextChanged: Qt.callLater(function() { options.currentIndex = -1; advanceOption(1) })
    function editSearch(text) {
        search.selectQuery(control, text)
        searchRequested(text)
    }
    function choose(index) {
        const row = search.get(index)
        if (!row || !Object.keys(row).length || row[enabledRole] === false) return
        search.selectKey(control, String(row[control.keyRole]))
        search.selectIndex(control, search.sourceIndexOf(selectedKey))
        selectionRequested(selectedKey)
        valueRequested(selectedKey, selectedValue)
        activated(currentIndex)
        popup.close()
        forceActiveFocus()
    }
    Connections {
        target: search
        function onSourceRowsAboutToChange() { control.modelChanging = true }
        function onSourceRowsChanged() {
            Qt.callLater(function() {
                const index = control.selectedKey.length ? search.sourceIndexOf(control.selectedKey) : -1
                search.selectIndex(control, index)
                if (index < 0) search.selectKey(control, "")
                control.modelChanging = false
            })
        }
    }
    Connections {
        target: control.Window.window
        function onWidthChanged() { if (control.popup.visible) control.positionPopup() }
        function onHeightChanged() { if (control.popup.visible) control.positionPopup() }
    }
    ComponentBridge { id: bridge; componentType: "ComboBox"; tag: control.tag; textFromTag: false }
    hoverEnabled: true
    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Accessible.name: currentIndex >= 0 ? displayText : bridge.text
    Accessible.description: enabled ? tooltip : disabledExplanation
    contentItem: RowLayout {
        spacing: control.appearance.iconGap
        Text {
            text: "⚠"
            font.family: "Segoe UI Symbol"
            color: control.warningColor
            font.pixelSize: control.appearance.fontSize
            visible: !!control.selectedRecord[control.warningRole]
            Accessible.name: String(control.selectedRecord[control.warningRole] || "")
        }
        Text {
        id: selectedLabel
        Layout.fillWidth: true
        text: control.currentIndex >= 0 ? control.displayText : bridge.text
        verticalAlignment: Text.AlignVCenter
        font.family: control.appearance.fontFamily
        font.pixelSize: control.appearance.fontSize
        color: control.enabled ? control.appearance.foreground : control.appearance.disabledText
        elide: Text.ElideRight
        }
    }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !control.visible || (control.Window.window && (!control.Window.window.visible || control.Window.window.visibility === Window.Minimized))
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    delegate: Button {
        required property int index
        readonly property var entry: search.sourceRow(index)
        tag: control.tag + ".nativeOption"
        componentType: "ComboBoxOption"
        textFromTag: false
        displayText: control.rowText(entry)
        textKey: control.rowTextKey(entry)
        useDisplayText: !textKey.length
        enabled: entry[control.enabledRole] !== false
        width: control.width
        onActivated: control.choose(search.indexOf(String(entry[control.keyRole])))
    }
    popup: PopupPanel {
        tag: control.tag + ".popup"
        cornerRadius: control.popupRadius
        scaleTransition: false
        property real placementHeight: control.Window.window ? control.Window.window.contentItem.height : control.popupMaximumHeight
        y: control.height + control.popupGap
        width: control.Window.window ? Math.min(control.popupWidth, control.Window.window.contentItem.width) : control.popupWidth
        height: Math.min(placementHeight, control.popupMaximumHeight, Math.max(control.optionHeight, options.contentHeight) + (control.searchable ? query.height + control.appearance.headingGap : 0) + padding * 2)
        padding: control.appearance.optionPopupPadding
        contentItem: Column {
            spacing: control.appearance.headingGap
            TextField {
                id: query
                tag: control.tag + ".search"
                textKey: "framework.combo.search"
                density: control.density
                prefixContent: Component { ActionIcon { tag: control.tag + ".search.icon"; source: control.searchIconSource; resourceKey: control.searchIconKey; imageComponent: control.searchIconContent; glyph: control.appearance.searchGlyph; tint: control.appearance.foreground } }
                actionContent: Component { ToolButton { implicitWidth: control.appearance.controlHeight; implicitHeight: control.appearance.controlHeight; tag: control.tag + ".clear"; displayText: ""; hideText: true; visible: query.text.length > 0; tooltipKey: "framework.combo.clear"; contentItem: ActionIcon { tag: control.tag + ".clear.icon"; source: control.clearIconSource; resourceKey: control.clearIconKey; imageComponent: control.clearIconContent; glyph: control.appearance.closeGlyph; tint: control.appearance.accentText } onActivated: { control.editSearch(""); query.forceActiveFocus() } } }
                width: parent.width
                visible: control.searchable
                text: control.searchText
                onTextEdited: control.editSearch(text)
                Keys.onEscapePressed: control.popup.close()
                Keys.onReturnPressed: control.choose(options.currentIndex)
                Keys.onDownPressed: control.advanceOption(1)
                Keys.onUpPressed: control.advanceOption(-1)
            }
            ListWidget {
                id: options
                tag: control.tag + ".options"
                width: parent.width
                height: Math.max(0, control.popup.height - (query.visible ? query.height + parent.spacing : 0))
                model: search
                spacing: control.appearance.optionSpacing
                currentIndex: 0
                Keys.onDownPressed: control.advanceOption(1)
                Keys.onUpPressed: control.advanceOption(-1)
                Keys.onReturnPressed: control.choose(currentIndex)
                Keys.onEscapePressed: control.popup.close()
                delegate: Button {
                    id: option
                    required property int index
                    property var row: { search.dataRevision; return search.get(index) }
                    width: options.width
                    tag: control.tag + ".option"
                    componentType: "ComboBoxOption"
                    textFromTag: false
                    displayText: control.rowText(row)
                    useDisplayText: !textKey.length
                    textKey: control.rowTextKey(row)
                    enabled: row[control.enabledRole] !== false
                    density: control.density
                    padding: control.optionPadding
                    rightPadding: padding + appearance.optionCheckWidth
                    implicitHeight: Math.max(control.optionHeight, contentItem.implicitHeight + topPadding + bottomPadding)
                    checked: String(row[control.keyRole]) === control.selectedKey
                    highlighted: options.currentIndex === index
                    stateKey: row.state_key === undefined ? control.stateKey : row.state_key
                    readonly property color optionForeground: !enabled ? appearance.disabledText : checked ? appearance.optionSelectedTextColor : hovered || highlighted ? appearance.optionHoveredTextColor : appearance.optionTextColor
                    tooltip: text
                    hideText: true
                    contentItem: RowLayout {
                        spacing: control.appearance.iconGap
                        Text {
                            objectName: "theme.warning"
                            text: "⚠"
                            font.family: "Segoe UI Symbol"
                            color: control.warningColor
                            font.pixelSize: control.appearance.fontSize
                            visible: !!option.row[control.warningRole]
                            Accessible.name: String(option.row[control.warningRole] || "")
                        }
                        Icon { tag: control.tag + ".option.icon"; source: option.row[control.iconRole] === undefined ? "" : option.row[control.iconRole]; tint: option.optionForeground; stateKey: option.stateKey; visible: String(source).length > 0 }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 0
                            UiText { tag: control.tag + ".option.label"; textFromTag: false; displayText: option.displayText; textKey: option.textKey; useDisplayText: option.useDisplayText; stateKey: option.stateKey; density: control.density; color: option.optionForeground; typographyRole: "button"; Layout.fillWidth: true; wrapMode: Text.NoWrap; elide: Text.ElideRight }
                            UiText { tag: control.tag + ".option.note"; textFromTag: false; displayText: option.row[control.secondaryRole] === undefined ? "" : option.row[control.secondaryRole]; stateKey: option.stateKey; density: control.density; color: option.enabled ? option.appearance.optionSecondaryTextColor : option.appearance.disabledText; typographyRole: "button-caption"; visible: text.length > 0; Layout.fillWidth: true; wrapMode: Text.NoWrap; elide: Text.ElideRight }
                        }
                    }
                    onActivated: control.choose(index)
                }
                UiText { anchors.centerIn: parent; tag: control.tag + ".empty"; displayText: control.emptyText; textFromTag: false; visible: options.count === 0; width: parent.width; horizontalAlignment: Text.AlignHCenter }
            }
        }
        onAboutToShow: control.positionPopup()
        onHeightChanged: if (visible) Qt.callLater(control.positionPopup)
        onOpened: { options.currentIndex = search.indexOf(control.selectedKey); if (options.currentIndex < 0) control.advanceOption(1); options.positionViewAtIndex(options.currentIndex, ListView.Contain); if (control.searchable) query.forceActiveFocus(); else options.forceActiveFocus() }
        onClosed: control.forceActiveFocus()
    }
    Component.onCompleted: { bridge.attach(control); ready = true; if (selectedKey.length) search.selectIndex(control, search.sourceIndexOf(selectedKey)); else if (currentIndex >= 0 && selectedRecord[keyRole] !== undefined) search.selectKey(control, String(selectedRecord[keyRole])) }
}
