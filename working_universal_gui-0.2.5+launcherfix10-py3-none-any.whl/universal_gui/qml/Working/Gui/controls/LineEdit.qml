import Working.Gui

TextField { componentType: "LineEdit" }
