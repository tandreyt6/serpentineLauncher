import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.CheckBox {
    id: control
    property url imageSource
    property alias iconSource: control.imageSource
    property string iconKey: ""
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property int textAlignment: Text.AlignLeft
    property real indicatorWidth: appearance.switchHeight
    property real indicatorHeight: appearance.switchHeight
    
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    ComponentBridge { id: bridge; componentType: "CheckBox"; tag: control.tag }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        readonly property string text: control.text
        readonly property bool checked: control.checked
        readonly property bool hovered: control.hovered
        readonly property bool pressed: control.down
        readonly property url imageSource: control.iconKey.length ? bridge.assetUrl(control.iconKey) : control.imageSource
        readonly property int textAlignment: control.textAlignment
        readonly property real indicatorWidth: control.indicatorWidth
        readonly property real leftPadding: control.leftPadding
        readonly property real rightPadding: control.rightPadding
        readonly property real indicatorHeight: control.indicatorHeight
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    Component.onCompleted: bridge.attach(control)

    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Accessible.description: enabled ? tooltip : disabledExplanation
    text: bridge.text
    readonly property real minimumWidth: indicatorWidth + leftPadding + rightPadding + (text.length ? appearance.spacing + labelMetrics.advanceWidth : 0)
    readonly property real minimumHeight: indicatorHeight + topPadding + bottomPadding
    TextMetrics { id: labelMetrics; text: control.text; font.family: control.appearance.fontFamily; font.pixelSize: control.appearance.fontSize }
    implicitWidth: text.length ? Math.max(appearance.controlWidth, minimumWidth) : minimumWidth
    implicitHeight: Math.max(appearance.controlHeight, minimumHeight)
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    indicator: Item { implicitWidth: control.indicatorWidth; implicitHeight: control.indicatorHeight }
    contentItem: Item {}
    background: VisualHost { source: bridge.visual; viewState: visualState }
}
