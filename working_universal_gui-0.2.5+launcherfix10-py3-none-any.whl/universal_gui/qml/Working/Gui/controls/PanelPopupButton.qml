import QtQuick
import Working.Gui

PanelButton {
    id: control
    componentType: "PanelPopupButton"
    property Component panelComponent
    property bool openAbove: true
    property real panelWidth: appearance.popupWidth
    property real panelHeight: appearance.popupHeight
    readonly property alias panel: popup
    readonly property alias panelItem: content.item
    PopupPanel {
        id: popup
        objectName: "panel." + control.tag
        tag: control.tag + ".panel"
        parent: control
        width: control.panelWidth
        height: control.panelHeight
        x: Math.min(0, control.width - width)
        y: control.openAbove ? -height - control.appearance.popupGap : control.height + control.appearance.popupGap
        contentItem: Loader { id: content; sourceComponent: control.panelComponent }
    }
    onActivated: { if (popup.visible) popup.close(); else popup.open() }
}
