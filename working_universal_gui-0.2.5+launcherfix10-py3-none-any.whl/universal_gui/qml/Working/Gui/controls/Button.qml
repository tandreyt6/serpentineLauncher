import Working.Gui

PanelButton { componentType: "Button" }
