import Working.Gui

PanelButton { componentType: "ToolButton" }
