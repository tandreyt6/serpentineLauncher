import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    componentType: "OperationRow"
    textFromTag: true
    property url expandIconSource
    property string expandIconKey: appearance.expandIconKey
    property Component expandIconContent
    property string key: ""
    property string detail: ""
    property string stage: ""
    property url iconSource
    property real progress: 0
    property real stageProgress: 0
    property bool indeterminate: false
    property bool paused: false
    property bool expanded: false
    property bool expandable: true
    property var actionModel: []
    property string iconKey: ""
    property alias actions: actionHost.data
    property alias detailsContent: detailHost.data
    signal actionRequested(string action, string key)
    implicitWidth: appearance.operationWidth
    readonly property bool narrow: availableWidth < appearance.controlWidth + (actions.count + 1) * (appearance.operationActionWidth + appearance.spacing)
    contentItem: GridLayout {
        columns: control.narrow ? 3 : 4
        columnSpacing: control.appearance.spacing
        rowSpacing: control.appearance.spacing
        Icon { tag: control.tag + ".icon"; source: control.iconSource; resourceKey: control.iconKey; visible: String(source).length > 0 || resourceKey.length > 0 }
        ColumnLayout {
            Layout.fillWidth: true
            UiText { tag: control.tag + ".title"; displayText: control.caption; stateKey: control.stateKey; density: control.density; wrapMode: Text.NoWrap; Layout.fillWidth: true; elide: Text.ElideRight }
            UiText { tag: control.tag + ".detail"; stateKey: control.stateKey; density: control.density; displayText: control.stage.length ? control.stage : control.detail; typographyRole: "caption"; wrapMode: Text.NoWrap; elide: Text.ElideRight; Layout.fillWidth: true }
            ProgressBar { tag: control.tag + ".total"; value: control.progress; indeterminate: control.indeterminate; paused: control.paused; stateKey: control.stateKey; Layout.fillWidth: true }
            ProgressBar { tag: control.tag + ".stage"; value: control.stageProgress; visible: control.stage.length > 0; Layout.fillWidth: true }
            Item { id: detailHost; clip: true; enabled: control.expanded; visible: control.expanded || implicitHeight > 0; Layout.fillWidth: true; implicitHeight: control.expanded ? childrenRect.height : 0; Behavior on implicitHeight { NumberAnimation { duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing } } }
        }
        ToolButton {
            tag: control.tag + ".expand"
            visible: control.expandable
            displayText: ""
            hideText: true
            implicitWidth: control.appearance.controlHeight
            stateKey: control.stateKey
            density: control.density
            contentItem: ActionIcon {
                tag: control.tag + ".expandIcon"
                source: control.expandIconSource
                resourceKey: control.expandIconKey
                imageComponent: control.expandIconContent
                glyph: control.appearance.comboGlyph
                tint: control.appearance.accentText
                stateKey: control.stateKey
            }
            onActivated: control.expanded = !control.expanded
        }
        GridLayout {
            Layout.row: control.narrow ? 1 : 0
            Layout.column: control.narrow ? 0 : 3
            Layout.columnSpan: control.narrow ? 3 : 1
            Layout.fillWidth: control.narrow
            columns: control.narrow ? Math.max(1, Math.floor((width + columnSpacing) / (control.appearance.operationActionWidth + columnSpacing))) : Math.max(1, actions.count)
            columnSpacing: control.appearance.spacing
            rowSpacing: control.appearance.spacing
            visible: actions.count > 0
            Repeater {
                id: actions
                model: control.actionModel
                delegate: ToolButton {
                    required property int index
                    readonly property var entry: { if (control.actionModel && control.actionModel.get) { control.actionModel.dataRevision; return control.actionModel.get(index) }; return control.actionModel[index] }
                    tag: control.tag + ".action"
                    implicitWidth: control.appearance.operationActionWidth
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    visible: entry.separator !== true
                    textKey: entry.text_key === undefined ? "" : entry.text_key
                    displayText: entry.text === undefined ? "" : entry.text
                    useDisplayText: !textKey.length
                    iconSource: entry.icon === undefined ? "" : entry.icon
                    stateKey: entry.state_key === undefined ? "" : entry.state_key
                    enabled: entry.enabled !== false
                    onActivated: control.actionRequested(entry.key, control.key)
                }
            }
        }
        Item { id: actionHost; Layout.row: 2; Layout.column: 0; Layout.columnSpan: control.narrow ? 3 : 4; Layout.fillWidth: true; visible: children.length > 0; implicitWidth: childrenRect.width; implicitHeight: childrenRect.height }
    }
}
