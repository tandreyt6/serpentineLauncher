import Working.Gui

TextField { componentType: "Line" }
