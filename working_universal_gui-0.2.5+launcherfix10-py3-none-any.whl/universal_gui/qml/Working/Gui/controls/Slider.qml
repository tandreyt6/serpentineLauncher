import QtQuick
import QtQuick.Templates as T
import Working.Gui

T.Slider {
    id: control
    
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    ComponentBridge { id: bridge; componentType: "Slider"; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        readonly property real position: control.visualPosition
        readonly property bool vertical: control.orientation === Qt.Vertical
        readonly property bool pressed: control.pressed
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    Component.onCompleted: bridge.attach(control)

    implicitWidth: orientation === Qt.Horizontal ? appearance.fieldWidth : appearance.controlHeight
    implicitHeight: orientation === Qt.Horizontal ? appearance.controlHeight : appearance.fieldWidth
    padding: appearance.sliderThumbSize / 2
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    handle: Item {
        width: control.appearance.sliderThumbSize
        height: width
        x: control.orientation === Qt.Horizontal ? control.leftPadding + control.visualPosition * control.availableWidth - width / 2 : (control.width - width) / 2
        y: control.orientation === Qt.Vertical ? control.topPadding + control.visualPosition * control.availableHeight - height / 2 : (control.height - height) / 2
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
}
