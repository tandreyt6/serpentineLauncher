import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.TextField {
    id: control
    required property string tag
    property string componentType: "TextField"
    property string previewState: ""
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property url iconSource
    property string iconKey: ""
    readonly property url resolvedIconSource: iconKey.length ? bridge.assetUrl(iconKey) : iconSource
    property alias textAlignment: control.horizontalAlignment
    property Component prefixContent
    property Component suffixContent
    property Component actionContent
    property string prefixText: ""
    property string suffixText: ""
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias textFromTag: bridge.textFromTag
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property alias appearance: bridge.style
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    signal committed(string value, string instanceToken)
    implicitWidth: bridge.style.fieldWidth
    implicitHeight: bridge.style.controlHeight
    padding: bridge.style.controlPadding
    leftPadding: padding + prefixSlot.width + iconSlot.width
    rightPadding: padding + suffixSlot.width + actionSlot.width
    color: bridge.style.foreground
    selectionColor: bridge.style.accent
    selectedTextColor: bridge.style.accentText
    placeholderTextColor: bridge.style.muted
    placeholderText: bridge.text
    font.family: bridge.style.fontFamily
    font.pixelSize: bridge.style.fontSize
    hoverEnabled: true
    selectByMouse: true
    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Accessible.description: enabled ? tooltip : disabledExplanation
    Accessible.role: Accessible.EditableText
    Accessible.name: bridge.text

    ComponentBridge {
        id: bridge
        componentType: control.componentType
        tag: control.tag
    }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus || control.previewState === "focused"
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    Loader { id: iconSlot; active: String(control.resolvedIconSource).length > 0; anchors.left: parent.left; anchors.leftMargin: control.padding; anchors.verticalCenter: parent.verticalCenter; width: active ? control.appearance.iconSize + control.appearance.iconGap : 0; height: control.appearance.iconSize; sourceComponent: Component { Icon { tag: control.tag + ".icon"; source: control.resolvedIconSource } } }
    Component { id: prefixLabel; UiText { tag: control.tag + ".prefix"; displayText: control.prefixText } }
    Component { id: suffixLabel; UiText { tag: control.tag + ".suffix"; displayText: control.suffixText } }
    TextMetrics { id: prefixMetrics; font: control.font; text: control.prefixText }
    TextMetrics { id: suffixMetrics; font: control.font; text: control.suffixText }
    Loader { id: prefixSlot; anchors.left: parent.left; anchors.leftMargin: control.padding + iconSlot.width; anchors.verticalCenter: parent.verticalCenter; sourceComponent: control.prefixContent ? control.prefixContent : control.prefixText.length ? prefixLabel : null; width: control.prefixContent ? item ? item.implicitWidth : 0 : prefixMetrics.advanceWidth }
    Loader { id: suffixSlot; anchors.right: actionSlot.left; anchors.verticalCenter: parent.verticalCenter; sourceComponent: control.suffixContent ? control.suffixContent : control.suffixText.length ? suffixLabel : null; width: control.suffixContent ? item ? item.implicitWidth : 0 : suffixMetrics.advanceWidth }
    Loader { id: actionSlot; anchors.right: parent.right; anchors.rightMargin: control.padding; anchors.verticalCenter: parent.verticalCenter; sourceComponent: control.actionContent; width: item ? item.implicitWidth : 0 }
    Text {
        anchors.fill: parent
        anchors.leftMargin: control.leftPadding
        anchors.rightMargin: control.rightPadding
        anchors.topMargin: control.padding
        anchors.bottomMargin: control.padding
        verticalAlignment: Text.AlignVCenter
        horizontalAlignment: control.horizontalAlignment
        visible: control.text.length === 0 && !control.preeditText
        text: bridge.text
        color: bridge.style.muted
        font: control.font
        elide: Text.ElideRight
    }
    GeometryOverlay {
        anchors.fill: parent
        visible: bridge.geometryVisible
        style: bridge.style
        focused: control.activeFocus
    }
    onAccepted: committed(text, instanceToken)
    onSuspendedChanged: bridge.suspend(suspended)
    Component.onCompleted: {
        bridge.attach(control)
        bridge.suspend(suspended)
    }
}
