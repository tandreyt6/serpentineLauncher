import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    textFromTag: true
    componentType: "SplitButton"
    property url secondaryIconSource
    property string secondaryIconKey: appearance.secondaryIconKey
    property Component secondaryIconContent
    property url iconSource
    property string iconKey: ""
    property real innerRadius: appearance.splitButtonInnerRadius
    property alias primary: primaryButton
    property alias secondary: secondaryButton
    property alias menu: popup
    property bool mainEnabled: true
    property bool secondaryEnabled: true
    property var actions: []
    property Component popupContent
    signal activated()
    signal expandedRequested()
    signal actionRequested(string key)
    padding: 0
    implicitWidth: appearance.controlWidth
    implicitHeight: appearance.controlHeight
    contentItem: RowLayout {
        spacing: control.appearance.splitButtonGap
        Button {
            id: primaryButton
            tag: control.tag + ".main"
            displayText: control.caption
            iconSource: control.iconSource
            iconKey: control.iconKey
            rightRadius: control.innerRadius
            stateKey: control.stateKey
            density: control.density
            enabled: control.mainEnabled
            Layout.fillWidth: true
            Layout.minimumWidth: control.appearance.controlHeight
            onActivated: control.activated()
        }
        ToolButton {
            id: secondaryButton
            tag: control.tag + ".expand"
            displayText: ""; hideText: true; contentItem: ActionIcon { tag: control.tag + ".secondaryIcon"; source: control.secondaryIconSource; resourceKey: control.secondaryIconKey; imageComponent: control.secondaryIconContent; glyph: control.appearance.comboGlyph; tint: secondaryButton.enabled ? secondaryButton.appearance.accentText : secondaryButton.appearance.disabledText; stateKey: control.stateKey }
            stateKey: control.stateKey
            density: control.density
            enabled: control.secondaryEnabled
            implicitWidth: control.appearance.controlHeight
            padding: Math.min(appearance.controlPadding, Math.max(0, (appearance.controlHeight - appearance.iconSize) / 2))
            leftRadius: control.innerRadius
            onActivated: { control.expandedRequested(); popup.popupAt(control, 0, control.height + control.appearance.popupGap, control.tag) }
        }
    }
    Keys.onDownPressed: if (secondaryEnabled) { expandedRequested(); popup.popupAt(control, 0, control.height + control.appearance.popupGap, control.tag) }
    Keys.onEscapePressed: popup.close()
    Menu {
        id: popup
        tag: control.tag + ".menu"
        parent: control
        y: control.height + control.appearance.popupGap
        model: control.actions
        onTriggered: key => control.actionRequested(key)
        contentItem: Loader { sourceComponent: control.popupContent ? control.popupContent : popup.defaultContent; focus: true }
    }
}
