import Working.Gui

Switch {
    componentType: "SwitchBox"
}
