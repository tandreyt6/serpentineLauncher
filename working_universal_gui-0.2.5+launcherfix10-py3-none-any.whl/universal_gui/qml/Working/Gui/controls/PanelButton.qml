import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.Button {
    id: control
    required property string tag
    property string componentType: "PanelButton"
    property url iconSource
    property string iconKey: ""
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property int textAlignment: appearance.buttonTextAlignment
    property real leftRadius: appearance.radius
    property real rightRadius: appearance.radius
    property bool hideText: false
    property string previewState: ""
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias textFromTag: bridge.textFromTag
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property alias appearance: bridge.style
    readonly property bool reducedMotion: bridge.reducedMotion
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    signal activated(string instanceToken)
    text: bridge.text
    implicitWidth: bridge.style.controlWidth
    implicitHeight: bridge.style.controlHeight
    padding: bridge.style.controlPadding
    hoverEnabled: true
    focusPolicy: Qt.StrongFocus
    Accessible.role: Accessible.Button
    Accessible.name: text
    Accessible.onPressAction: { if (control.enabled) control.clicked() }

    ComponentBridge {
        id: bridge
        componentType: control.componentType
        tag: control.tag
    }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property string text: control.hideText ? "" : control.text
        readonly property url iconSource: control.iconKey.length ? bridge.assetUrl(control.iconKey) : control.iconSource
        readonly property real leftPadding: control.leftPadding
        readonly property real rightPadding: control.rightPadding
        readonly property int textAlignment: control.textAlignment
        readonly property real leftRadius: control.leftRadius
        readonly property real rightRadius: control.rightRadius
        readonly property bool enabled: control.enabled
        readonly property bool hovered: control.hovered || control.previewState === "hovered"
        readonly property bool pressed: control.down || control.previewState === "pressed"
        readonly property bool focused: control.activeFocus || control.previewState === "focused"
        readonly property bool checked: control.checked
        readonly property bool highlighted: control.highlighted
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost {
        objectName: "visual." + control.tag
        source: bridge.visual
        viewState: visualState
    }
    contentItem: Item {}
    function setting(key) { bridge.settingsRevision; return bridge.setting(key) }
    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Accessible.description: enabled ? tooltip : disabledExplanation
    GeometryOverlay {
        anchors.fill: parent
        visible: bridge.geometryVisible
        style: bridge.style
        focused: control.activeFocus
    }
    onClicked: activated(instanceToken)
    onSuspendedChanged: bridge.suspend(suspended)
    Component.onCompleted: {
        bridge.attach(control)
        bridge.suspend(suspended)
    }
}
