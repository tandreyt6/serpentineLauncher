import QtQuick
import QtQuick.Templates as T
import Working.Gui

T.ScrollBar {
    id: control
    
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    ComponentBridge { id: bridge; componentType: "ScrollBar"; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        readonly property real position: control.visualPosition
        readonly property real size: control.visualSize
        readonly property bool vertical: control.orientation === Qt.Vertical
        readonly property bool active: control.active || control.hovered || control.pressed
        readonly property bool pressed: control.pressed
        
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    Component.onCompleted: bridge.attach(control)

    implicitWidth: appearance.scrollbarWidth
    implicitHeight: appearance.scrollbarWidth
    minimumSize: appearance.scrollbarMinimum
    policy: T.ScrollBar.AsNeeded
    visible: policy === T.ScrollBar.AlwaysOn || (policy === T.ScrollBar.AsNeeded && size < 1)
    hoverEnabled: true
    contentItem: Item {}
    background: VisualHost { source: bridge.visual; viewState: visualState }
}
