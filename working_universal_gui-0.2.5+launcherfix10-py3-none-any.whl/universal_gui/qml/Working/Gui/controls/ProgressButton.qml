import QtQuick
import Working.Gui

Button {
    id: control
    textFromTag: true
    componentType: "ProgressButton"
    hideText: true
    property real progress: 0
    property bool indeterminate: false
    property bool paused: false
    property string stage: ""
    property bool showProgress: true
    contentItem: Item {
        Text {
            anchors.fill: parent
            anchors.bottomMargin: control.showProgress ? control.appearance.progressHeight + control.appearance.headingGap : 0
            text: control.text + (control.stage.length ? " · " + control.stage : "")
            color: control.appearance.accentText
            font.family: control.appearance.fontFamily
            font.pixelSize: control.appearance.fontSize
            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
        }
        ProgressBar {
            tag: control.tag + ".progress"
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.bottom: parent.bottom
            visible: control.showProgress
            value: control.progress
            indeterminate: control.indeterminate; paused: control.paused
            stateKey: control.stateKey
        }
    }
}
