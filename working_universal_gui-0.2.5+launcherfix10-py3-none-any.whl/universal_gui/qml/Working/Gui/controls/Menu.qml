pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls as C
import Working.Gui

PopupPanel {
    id: control
    componentType: "Menu"
    padding: appearance.optionPopupPadding
    property var model: []
    property string contextKey: ""
    property string pendingAction: ""
    property var ownerItem: null
    property bool constrainedToWindow: false
    property var parentMenu: null
    property Component defaultContent: menuContent
    signal triggered(string key)
    signal actionRequested(string key, string context)
    width: constrainedToWindow && parent ? Math.min(appearance.popupWidth, parent.width) : appearance.popupWidth
    height: Math.min(appearance.popupHeight, modelCount(model) * (appearance.controlHeight + appearance.menuGroupHeight) + padding * 2, constrainedToWindow && parent ? parent.height : Infinity)
    function modelCount(value) { return value ? value.count !== undefined ? value.count : value.length : 0 }
    function actionAt(index) { if (index < 0 || index >= modelCount(model)) return ({}); return model.get ? model.get(index) : model[index] }
    function findAction(value, key) {
        for (let i = 0; i < modelCount(value); ++i) {
            const action = value.get ? value.get(i) : value[i]
            if (action.enabled === false || action.separator) continue
            if (action.key === key) return action
            const child = findAction(action.children, key)
            if (child) return child
        }
        return null
    }
    function popupAt(owner, localX, localY, context) {
        ownerItem = owner
        contextKey = context
        const window = owner.Window.window
        parent = window ? window.contentItem : owner
        constrainedToWindow = true
        const point = owner.mapToItem(parent, localX, localY)
        x = Math.max(0, Math.min(point.x, parent.width - width))
        y = Math.max(0, Math.min(point.y, parent.height - height))
        open()
    }
    function popupAtGlobal(owner, globalX, globalY, context) {
        const point = owner.mapFromGlobal(globalX, globalY)
        popupAt(owner, point.x, point.y, context)
    }
    function choose(key) { const action = findAction(model, key); if (pendingAction.length || !action || modelCount(action.children)) return false; pendingAction = key; close(); return true }
    onClosed: {
        const action = pendingAction
        pendingAction = ""
        if (action.length) { triggered(action); actionRequested(action, contextKey) }
        if (ownerItem) ownerItem.forceActiveFocus()
        if (parentMenu && !action.length) parentMenu.contentItem.forceActiveFocus()
    }
    contentItem: Loader { sourceComponent: control.defaultContent; focus: true }
    Component {
        id: menuContent
        ListWidget {
            id: entries
            tag: control.tag + ".items"
            model: control.model
            currentIndex: 0
            spacing: control.appearance.optionSpacing
            focus: true
            Keys.onEscapePressed: control.close()
            function advance(step) {
                for (let i = currentIndex + step; i >= 0 && i < count; i += step) {
                    const action = control.actionAt(i)
                    if (!action.separator && action.enabled !== false) { currentIndex = i; return }
                }
            }
            Keys.onReturnPressed: if (currentItem) currentItem.activate()
            Keys.onRightPressed: if (currentItem && control.modelCount(currentItem.entry.children)) currentItem.activate()
            Keys.onLeftPressed: if (control.parentMenu) control.close()
            Keys.onDownPressed: advance(1)
            Keys.onUpPressed: advance(-1)
            Keys.onPressed: event => {
                if (event.key === Qt.Key_Home) { currentIndex = -1; advance(1); event.accepted = true }
                else if (event.key === Qt.Key_End) { currentIndex = count; advance(-1); event.accepted = true }
            }
            delegate: Item {
                id: row
                required property int index
                property var entry: { if (control.model && control.model.dataRevision !== undefined) control.model.dataRevision; return control.actionAt(index) }
                readonly property bool hasGroup: entry.group !== undefined && entry.group.length > 0 && (index === 0 || control.actionAt(index - 1).group !== entry.group)
                width: ListView.view.width
                height: (entry.separator ? control.appearance.menuSeparatorHeight : control.appearance.controlHeight) + (hasGroup ? control.appearance.menuGroupHeight : 0)
                function activate() {
                    if (entry.enabled === false || entry.separator) return
                    entries.currentIndex = index
                    if (control.modelCount(entry.children)) {
                        submenuLoader.setSource(Qt.resolvedUrl("Menu.qml"), {tag: control.tag + ".submenu." + index, model: entry.children, contextKey: control.contextKey, parentMenu: control})
                        submenuLoader.active = true
                    } else control.choose(entry.key)
                }
                UiText { tag: control.tag + ".group"; textFromTag: false; displayText: row.entry.group === undefined ? "" : row.entry.group; typographyRole: "caption"; visible: row.hasGroup; width: parent.width; height: control.appearance.menuGroupHeight; wrapMode: Text.NoWrap; elide: Text.ElideRight }
                Button {
                    y: row.hasGroup ? control.appearance.menuGroupHeight : 0
                    width: parent.width
                    height: control.appearance.controlHeight
                    tag: control.tag + ".action"
                    componentType: "MenuAction"
                    textFromTag: false
                    highlighted: entries.currentIndex === row.index
                    textKey: row.entry.text_key !== undefined ? row.entry.text_key : row.entry.tag === undefined ? "" : row.entry.tag
                    displayText: row.entry.text === undefined ? "" : row.entry.text
                    useDisplayText: row.entry.text !== undefined && !row.entry.text_key
                    stateKey: row.entry.state_key === undefined ? "" : row.entry.state_key
                    iconSource: row.entry.icon === undefined ? "" : row.entry.icon
                    enabled: row.entry.enabled !== false
                    checkable: row.entry.checkable === true
                    checked: row.entry.checked === true
                    visible: !row.entry.separator
                    textAlignment: Qt.AlignLeft
                    onActivated: row.activate()
                }
                HoverHandler { id: rowHover }
                C.ToolTip.visible: rowHover.hovered && row.entry.enabled === false && row.entry.explanation !== undefined && row.entry.explanation.length > 0
                C.ToolTip.text: row.entry.explanation === undefined ? "" : row.entry.explanation
                Rectangle { anchors.centerIn: parent; width: parent.width; height: control.appearance.borderWidth; color: control.appearance.border; visible: row.entry.separator === true }
                Loader {
                    id: submenuLoader
                    active: false
                    onLoaded: { item.triggered.connect(control.choose); item.popupAt(row, row.width, 0, control.contextKey); if (item.x < row.mapToItem(item.parent, row.width, 0).x) item.x = Math.max(0, row.mapToItem(item.parent, 0, 0).x - item.width) }
                }
            }
        }
    }
}
