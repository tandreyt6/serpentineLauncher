import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.ProgressBar {
    id: control
    property bool paused: false
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property bool smooth: true
    property int smoothingDuration: appearance.duration
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    implicitWidth: appearance.fieldWidth
    implicitHeight: appearance.progressHeight
    ComponentBridge { id: bridge; componentType: "ProgressBar"; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property real position: control.visualPosition
        readonly property int smoothingDuration: control.smoothingDuration
        readonly property bool indeterminate: control.indeterminate
        readonly property bool paused: control.paused
        readonly property bool enabled: control.enabled
        readonly property bool reducedMotion: bridge.reducedMotion || !control.smooth
        readonly property bool suspended: !control.visible || (control.Window.window && (!control.Window.window.visible || control.Window.window.visibility === Window.Minimized))
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    hoverEnabled: true
    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    Accessible.description: enabled ? tooltip : disabledExplanation
    contentItem: Item {}
    Component.onCompleted: bridge.attach(control)
}
