import QtQuick.Templates as T
import Working.Gui

Frame {
    componentType: "ImageRadioGroup"
    property alias buttons: selection.buttons
    readonly property alias checkedButton: selection.checkedButton
    T.ButtonGroup { id: selection; exclusive: true }
}
