import Working.Gui

RadioButton {
    componentType: "ImageRadioButton"
}
