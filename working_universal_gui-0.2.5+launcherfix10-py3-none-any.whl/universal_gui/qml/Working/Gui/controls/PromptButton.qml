import QtQuick
import QtQuick.Layouts
import Working.Gui

PanelPopupButton {
    id: control
    componentType: "PromptButton"
    property var validator: null
    property string value: ""
    signal confirmed(string value)
    openAbove: false
    panelHeight: appearance.controlHeight + appearance.cardPadding * 2
    panelComponent: Component {
        RowLayout {
            spacing: control.appearance.spacing
            TextField {
                id: input
                tag: control.tag + ".input"
                Layout.fillWidth: true
                text: control.value
                validator: control.validator
                onCommitted: { if (acceptableInput) { control.value = text; control.confirmed(text); control.panel.close() } }
            }
            Button {
                tag: control.tag + ".confirm"
                enabled: input.acceptableInput
                implicitWidth: control.appearance.controlHeight
                onActivated: { control.value = input.text; control.confirmed(input.text); control.panel.close() }
            }
        }
    }
}
