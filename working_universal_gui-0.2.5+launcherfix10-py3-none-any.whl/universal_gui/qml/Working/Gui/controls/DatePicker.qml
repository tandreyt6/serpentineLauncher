pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    componentType: "DatePicker"
    property url previousIconSource
    property string previousIconKey: appearance.previousIconKey
    property Component previousIconContent
    property url nextIconSource
    property string nextIconKey: appearance.nextIconKey
    property Component nextIconContent
    property url calendarIconSource
    property string calendarIconKey: appearance.calendarIconKey
    property Component calendarIconContent
    property alias selectedDate: calendar.selectedDate
    property alias availableDates: calendar.availableDates
    property alias minimumDate: calendar.minimumDate
    property alias maximumDate: calendar.maximumDate
    property string localeName: locale.name
    readonly property var days: calendar.days
    property string cursorDate: selectedDate.length ? selectedDate : calendar.today
    signal dateRequested(string date)
    implicitWidth: appearance.calendarWidth
    implicitHeight: appearance.calendarHeight
    CalendarModel { id: calendar; locale: control.localeName }
    focus: true
    function moveCursor(delta) { cursorDate = calendar.moveDate(cursorDate, delta); calendar.showDate(cursorDate) }
    function choose(value) { cursorDate = value; if (calendar.selectDate(value)) dateRequested(value); forceActiveFocus() }
    function moveMonth(delta) { calendar.moveMonth(delta); cursorDate = calendar.displayedDate }
    onSelectedDateChanged: if (selectedDate.length) { cursorDate = selectedDate; calendar.showDate(selectedDate) }
    Keys.onLeftPressed: moveCursor(-1)
    Keys.onRightPressed: moveCursor(1)
    Keys.onUpPressed: moveCursor(-7)
    Keys.onDownPressed: moveCursor(7)
    Keys.onReturnPressed: choose(cursorDate)
    Keys.onEnterPressed: choose(cursorDate)
    Keys.onPressed: event => { if (event.key === Qt.Key_PageUp) { moveMonth(-1); event.accepted = true } else if (event.key === Qt.Key_PageDown) { moveMonth(1); event.accepted = true } }
    contentItem: ColumnLayout {
        RowLayout {
            ToolButton { tag: control.tag + ".previous"; displayText: ""; hideText: true; tooltipKey: "framework.calendar.previous"; contentItem: ActionIcon { tag: control.tag + ".previous.icon"; source: control.previousIconSource; resourceKey: control.previousIconKey; imageComponent: control.previousIconContent; glyph: control.appearance.previousGlyph; tint: control.appearance.accentText } implicitWidth: control.appearance.controlHeight; onActivated: control.moveMonth(-1) }
            Icon { tag: control.tag + ".calendar.icon"; source: control.calendarIconSource; resourceKey: control.calendarIconKey; visible: String(source).length > 0 || resourceKey.length > 0 }
            UiText { tag: control.tag + ".month"; displayText: calendar.title; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
            ToolButton { tag: control.tag + ".next"; displayText: ""; hideText: true; tooltipKey: "framework.calendar.next"; contentItem: ActionIcon { tag: control.tag + ".next.icon"; source: control.nextIconSource; resourceKey: control.nextIconKey; imageComponent: control.nextIconContent; glyph: control.appearance.nextGlyph; tint: control.appearance.accentText } implicitWidth: control.appearance.controlHeight; onActivated: control.moveMonth(1) }
        }
        GridLayout {
            columns: 7
            Layout.fillWidth: true
            Layout.fillHeight: true
            Repeater {
                model: 7
                delegate: UiText { required property int index; tag: control.tag + ".weekday." + index; displayText: calendar.weekdays[index]; typographyRole: "caption"; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true; Layout.minimumWidth: 0 }
            }
            Repeater {
                model: 42
                delegate: ToolButton {
                    required property int index
                    readonly property var modelData: control.days[index]
                    componentType: "CalendarDayButton"
                    tag: control.tag + ".day." + index
                    displayText: String(modelData.day)
                    padding: control.appearance.calendarCellPadding
                    density: control.density
                    stateKey: modelData.selected ? "selected" : modelData.date === control.cursorDate ? "focused" : modelData.currentMonth ? control.stateKey : "other-month"
                    enabled: modelData.enabled
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    Layout.minimumWidth: 0
                    Layout.minimumHeight: 0
                    implicitWidth: control.appearance.calendarCellSize
                    implicitHeight: control.appearance.calendarCellSize
                    onActivated: control.choose(modelData.date)
                }
            }
        }
    }
}
