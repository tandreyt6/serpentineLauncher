import QtQuick
import Working.Gui

Item {
    id: control
    required property string tag
    objectName: "drop." + tag
    property var mimeTypes: ["text/uri-list", "text/plain", "application/x-universal-gui-keys"]
    property int acceptedActions: Qt.CopyAction | Qt.MoveAction
    readonly property alias instanceToken: port.token
    property alias stateKey: port.stateKey
    property alias density: port.density
    property alias typographyRole: port.typographyRole
    property alias textKey: port.textKey
    property alias displayText: port.displayText
    property alias useDisplayText: port.useDisplayText
    readonly property alias appearance: port.style
    readonly property alias containsDrag: zone.containsDrag
    signal dropped(var payload)
    DataBridge { id: port; componentType: "DropZone"; tag: control.tag; textFromTag: false }
    Rectangle {
        anchors.fill: parent
        color: control.appearance.dropHighlight
        border.color: control.appearance.accent
        border.width: control.appearance.focusWidth
        radius: control.appearance.radius
        opacity: zone.containsDrag ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: port.reducedMotion ? 0 : control.appearance.duration } }
    }
    DropArea {
        id: zone
        anchors.fill: parent
        onEntered: drag => {
            const internal = drag.source && drag.source.keys !== undefined
            const formats = internal ? drag.source.formats : drag.formats
            drag.accepted = Boolean(drag.supportedActions & control.acceptedActions) && formats.some(format => control.mimeTypes.indexOf(format) >= 0)
        }
        onDropped: drop => {
            if (!(drop.supportedActions & control.acceptedActions)) return
            const internal = drop.source && drop.source.keys !== undefined
            const urls = internal ? drop.source.urls : Array.from(drop.urls, url => url.toString())
            const keys = internal ? JSON.stringify(drop.source.keys) : drop.getDataAsString("application/x-universal-gui-keys")
            const action = (drop.proposedAction & control.acceptedActions) ? drop.proposedAction : (drop.supportedActions & control.acceptedActions & Qt.CopyAction) ? Qt.CopyAction : Qt.MoveAction
            const payload = port.receiveDrop(internal ? drop.source.text : drop.text, urls, keys, action === Qt.MoveAction ? "move" : "copy")
            if (payload.action) { control.dropped(payload); drop.accept(action) }
        }
    }
    Component.onCompleted: port.attach(control)
}
