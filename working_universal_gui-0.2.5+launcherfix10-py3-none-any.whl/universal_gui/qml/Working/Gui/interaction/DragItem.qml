import QtQuick
import Working.Gui

Item {
    id: control
    required property string tag
    objectName: "drag." + tag
    property var keys: []
    property string text: ""
    property var urls: []
    readonly property var formats: ["application/x-universal-gui-keys", "text/plain"].concat(urls.length ? ["text/uri-list"] : [])
    property bool nativeDrag: false
    property bool moveVisual: true
    property int supportedActions: Qt.CopyAction | Qt.MoveAction
    property int acceptedButtons: Qt.LeftButton
    readonly property alias instanceToken: port.token
    property alias stateKey: port.stateKey
    property alias density: port.density
    property alias typographyRole: port.typographyRole
    property alias textKey: port.textKey
    property alias displayText: port.displayText
    property alias useDisplayText: port.useDisplayText
    readonly property alias appearance: port.style
    readonly property alias dragging: mouse.drag.active
    readonly property point pointerPosition: Qt.point(mouse.mouseX, mouse.mouseY)
    signal dragFinished(int action)
    signal clicked(int button, int modifiers)
    signal doubleClicked(int modifiers)
    ComponentBridge { id: port; componentType: "DragItem"; tag: control.tag; textFromTag: false }
    Drag.source: control
    Drag.active: mouse.drag.active
    Drag.dragType: nativeDrag ? Drag.Automatic : Drag.Internal
    Drag.supportedActions: supportedActions
    Drag.mimeData: { "application/x-universal-gui-keys": JSON.stringify(keys), "text/plain": text, "text/uri-list": urls.join("\r\n") }
    Drag.onDragFinished: action => control.dragFinished(action)
    property real originX
    property real originY
    Item { id: dragProbe }
    MouseArea {
        id: mouse
        anchors.fill: parent
        acceptedButtons: control.acceptedButtons
        preventStealing: true
        drag.target: control.moveVisual ? control : dragProbe
        onPressed: { control.originX = control.x; control.originY = control.y }
        onReleased: {
            if (!control.nativeDrag) control.dragFinished(control.Drag.drop())
            if (control.moveVisual) { control.x = control.originX; control.y = control.originY }
            dragProbe.x = 0
            dragProbe.y = 0
        }
        onCanceled: { if (control.moveVisual) { control.x = control.originX; control.y = control.originY }; dragProbe.x = 0; dragProbe.y = 0 }
        onClicked: mouse => control.clicked(mouse.button, mouse.modifiers)
        onDoubleClicked: mouse => control.doubleClicked(mouse.modifiers)
    }
    Component.onCompleted: port.attach(control)
}
