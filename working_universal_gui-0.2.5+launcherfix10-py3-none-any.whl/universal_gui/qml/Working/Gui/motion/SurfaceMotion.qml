import QtQuick

ParallelAnimation {
    id: motion
    required property Item targetItem
    required property var appearance
    property bool reducedMotion: false
    property bool suspended: false
    readonly property int effectiveDuration: reducedMotion || suspended ? 0 : appearance.surfaceDuration
    NumberAnimation {
        target: motion.targetItem
        property: "opacity"
        from: motion.appearance.surfaceOpacity
        to: 1
        duration: motion.effectiveDuration
        easing.type: motion.appearance.motionEasing
    }
    NumberAnimation {
        target: motion.targetItem
        property: "scale"
        from: motion.appearance.surfaceScale
        to: 1
        duration: motion.effectiveDuration
        easing.type: motion.appearance.motionEasing
    }
    onReducedMotionChanged: { if (reducedMotion && running) complete() }
    onSuspendedChanged: { if (suspended && running) complete() }
}
