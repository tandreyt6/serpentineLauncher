import QtQuick
import QtQuick.Templates as T
import Working.Gui

Window {
    id: window
    property url minimizeIconSource
    property string minimizeIconKey: appearance.minimizeIconKey
    property Component minimizeIconContent
    property url maximizeIconSource
    property string maximizeIconKey: appearance.maximizeIconKey
    property Component maximizeIconContent
    property url restoreIconSource
    property string restoreIconKey: appearance.restoreIconKey
    property Component restoreIconContent
    property url closeIconSource
    property string closeIconKey: appearance.closeIconKey
    property Component closeIconContent
    property Component captionLeft
    property Component captionRight
    property Component captionComponent
    required property string tag
    property string componentType: "AppWindow"
    default property alias contents: body.data
    property bool nativeFrame: false
    property bool resizeEnabled: true
    property bool moveEnabled: true
    property bool minimizeEnabled: true
    property bool maximizeEnabled: true
    property bool closeEnabled: true
    property bool alertBorder: false
    property bool nativeMaxHovered: false
    property bool nativeMaxPressed: false
    property bool nativeSnapped: false
    property bool customCaption: false
    readonly property alias captionItem: captionContent
    function alignToPixel(value) {
        const ratio = Screen.devicePixelRatio
        return Math.round(value * ratio) / ratio
    }
    readonly property real frameInset: nativeFrame || visibility !== Window.Windowed || nativeSnapped ? 0 : alignToPixel(appearance.windowShadowMargin)
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    width: initialGeometry.width
    height: initialGeometry.height
    minimumWidth: bridge.style.minimumWidth
    minimumHeight: bridge.style.minimumHeight
    flags: nativeFrame ? Qt.Window : Qt.Window | Qt.FramelessWindowHint
    color: nativeFrame ? bridge.style.background : "transparent"
    title: bridge.text
    ComponentBridge { id: bridge; componentType: window.componentType; tag: window.tag }
    function textFor(key) { bridge.localeRevision; return bridge.textFor(key) }
    WindowChromeBridge { id: chrome }
    QtObject {
        id: initialGeometry
        property real width: bridge.style.windowWidth
        property real height: bridge.style.windowHeight
    }
    function configureChrome() { if (instanceToken.length) chrome.configure(window) }
    function toggleMaximized() {
        if (!maximizeEnabled) return
        chrome.command(visibility === Window.Maximized ? "restore" : "maximize")
    }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: true
        readonly property bool focused: window.active
        readonly property bool maximized: window.visibility === Window.Maximized || window.visibility === Window.FullScreen
        readonly property real frameInset: window.frameInset
        readonly property bool alert: window.alertBorder
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !window.visible
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    VisualHost { parent: window.contentItem; anchors.fill: parent; visible: !window.nativeFrame; source: bridge.visual; viewState: visualState }
    Item {
        id: caption
        parent: window.contentItem
        visible: !window.nativeFrame && window.visibility !== Window.FullScreen
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.leftMargin: window.frameInset
        anchors.rightMargin: window.frameInset
        anchors.topMargin: window.frameInset
        height: window.alignToPixel(window.appearance.titlebarHeight)
        MouseArea {
            anchors.fill: parent
            visible: !window.customCaption
            onPressed: { if (window.moveEnabled) window.startSystemMove() }
            onDoubleClicked: window.toggleMaximized()
        }
        Text {
            visible: !window.customCaption
            anchors.left: leftSlot.right
            anchors.leftMargin: window.appearance.controlPadding
            anchors.right: rightSlot.left
            anchors.verticalCenter: parent.verticalCenter
            text: window.title
            color: window.appearance.foreground
            font.family: window.appearance.fontFamily
            font.pixelSize: window.appearance.fontSize
            elide: Text.ElideRight
        }
        Item {
            id: captionContent
            objectName: "window.caption.content"
            anchors.left: parent.left
            anchors.leftMargin: leftSlot.width
            anchors.right: rightSlot.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            visible: window.customCaption
            clip: true
            Loader { anchors.fill: parent; sourceComponent: window.captionComponent }
        }
        Loader {
            id: leftSlot
            anchors.left: parent.left
            height: parent.height
            width: item ? item.implicitWidth : 0
            sourceComponent: window.captionLeft
        }
        Loader {
            id: rightSlot
            anchors.right: buttons.left
            height: parent.height
            width: item ? item.implicitWidth : 0
            sourceComponent: window.captionRight
        }
        Row {
            id: buttons
            anchors.right: parent.right
            height: parent.height
            Repeater {
                model: ["minimize", "maximize", "close"]
                delegate: T.Button {
                    id: captionButton
                    required property string modelData
                    readonly property real cornerRadius: modelData === "close" && window.visibility !== Window.Maximized && window.visibility !== Window.FullScreen ? window.appearance.windowRadius : 0
                    objectName: "caption." + modelData
                    width: window.appearance.titlebarButtonWidth
                    height: caption.height
                    hoverEnabled: true
                    containmentMask: QtObject {
                        function contains(point: point): bool {
                            if (point.x < 0 || point.y < 0 || point.x >= captionButton.width || point.y >= captionButton.height) return false
                            const radius = Math.min(captionButton.cornerRadius, window.width / 2, window.height / 2)
                            if (radius <= 0 || point.x <= captionButton.width - radius || point.y >= radius) return true
                            const dx = point.x - (captionButton.width - radius)
                            const dy = point.y - radius
                            return dx * dx + dy * dy <= radius * radius
                        }
                    }
                    visible: modelData === "minimize" ? window.minimizeEnabled : modelData === "maximize" ? window.maximizeEnabled : window.closeEnabled
                    Accessible.name: { bridge.localeRevision; return bridge.textFor("window." + modelData) }
                    text: modelData === "minimize" ? window.appearance.minimizeGlyph : modelData === "maximize" ? window.visibility === Window.Maximized ? window.appearance.restoreGlyph : window.appearance.maximizeGlyph : window.appearance.closeGlyph
                    contentItem: ActionIcon {
                        tag: window.tag + ".caption." + captionButton.modelData
                        source: captionButton.modelData === "minimize" ? window.minimizeIconSource : captionButton.modelData === "close" ? window.closeIconSource : window.visibility === Window.Maximized ? window.restoreIconSource : window.maximizeIconSource
                        resourceKey: captionButton.modelData === "minimize" ? window.minimizeIconKey : captionButton.modelData === "close" ? window.closeIconKey : window.visibility === Window.Maximized ? window.restoreIconKey : window.maximizeIconKey
                        imageComponent: captionButton.modelData === "minimize" ? window.minimizeIconContent : captionButton.modelData === "close" ? window.closeIconContent : window.visibility === Window.Maximized ? window.restoreIconContent : window.maximizeIconContent
                        glyph: captionButton.text
                        tint: window.appearance.foreground
                        stateKey: window.stateKey
                    }
                    background: Rectangle {
                        anchors.fill: parent
                        anchors.topMargin: window.appearance.windowBorderWidth
                        anchors.rightMargin: captionButton.modelData === "close" ? window.appearance.windowBorderWidth : 0
                        topRightRadius: Math.max(0, captionButton.cornerRadius - anchors.rightMargin)
                        color: parent.down || (captionButton.modelData === "maximize" && window.nativeMaxPressed) ? window.appearance.accentPressed : parent.hovered || (captionButton.modelData === "maximize" && window.nativeMaxHovered) ? window.appearance.captionHover : "transparent"
                        Behavior on color { ColorAnimation { duration: bridge.reducedMotion || !window.visible ? 0 : window.appearance.duration } }
                    }
                    onClicked: {
                        if (modelData === "minimize") chrome.command("minimize")
                        else if (modelData === "maximize") window.toggleMaximized()
                        else window.close()
                    }
                }
            }
        }
    }
    Item {
        id: body
        objectName: "window.body"
        parent: window.contentItem
        anchors.fill: parent
        anchors.topMargin: window.alignToPixel(window.frameInset + (caption.visible ? caption.height : 0))
        anchors.leftMargin: window.nativeFrame ? 0 : window.alignToPixel(window.frameInset + window.appearance.windowBorderWidth)
        anchors.rightMargin: window.nativeFrame ? 0 : window.width - window.alignToPixel(window.width - window.frameInset - window.appearance.windowBorderWidth)
        anchors.bottomMargin: window.nativeFrame ? 0 : window.height - window.alignToPixel(window.height - window.frameInset - window.appearance.windowBorderWidth)
        clip: true
    }
    Repeater {
        parent: window.contentItem
        model: [Qt.LeftEdge, Qt.RightEdge, Qt.TopEdge, Qt.BottomEdge, Qt.LeftEdge | Qt.TopEdge, Qt.RightEdge | Qt.TopEdge, Qt.LeftEdge | Qt.BottomEdge, Qt.RightEdge | Qt.BottomEdge]
        delegate: MouseArea {
            required property int modelData
            parent: window.contentItem
            visible: !window.nativeFrame && window.resizeEnabled && window.visibility === Window.Windowed
            width: modelData & (Qt.LeftEdge | Qt.RightEdge) ? window.appearance.resizeMargin : window.width - window.frameInset * 2
            height: modelData & (Qt.TopEdge | Qt.BottomEdge) ? window.appearance.resizeMargin : window.height - window.frameInset * 2
            x: modelData & Qt.RightEdge ? window.width - window.frameInset - width : window.frameInset
            y: modelData & Qt.BottomEdge ? window.height - window.frameInset - height : window.frameInset
            cursorShape: modelData === Qt.LeftEdge || modelData === Qt.RightEdge ? Qt.SizeHorCursor : modelData === Qt.TopEdge || modelData === Qt.BottomEdge ? Qt.SizeVerCursor : modelData === (Qt.LeftEdge | Qt.TopEdge) || modelData === (Qt.RightEdge | Qt.BottomEdge) ? Qt.SizeFDiagCursor : Qt.SizeBDiagCursor
            onPressed: window.startSystemResize(modelData)
        }
    }
    SurfaceMotion { id: reveal; targetItem: body; appearance: window.appearance; reducedMotion: bridge.reducedMotion; suspended: !window.visible }
    onVisibleChanged: { if (visible) reveal.restart() }
    onNativeFrameChanged: configureChrome()
    onResizeEnabledChanged: configureChrome()
    onMoveEnabledChanged: configureChrome()
    onCustomCaptionChanged: configureChrome()
    onMinimizeEnabledChanged: configureChrome()
    onMaximizeEnabledChanged: configureChrome()
    onCloseEnabledChanged: configureChrome()
    Connections { target: bridge; function onStyleChanged() { window.configureChrome() } }
    Component.onCompleted: { bridge.attach(window); initialGeometry.width = initialGeometry.width; initialGeometry.height = initialGeometry.height; chrome.configure(window) }
}
