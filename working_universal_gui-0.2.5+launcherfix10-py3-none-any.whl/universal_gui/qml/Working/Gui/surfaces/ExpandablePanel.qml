import QtQuick
import Working.Gui

Frame {
    id: control
    componentType: "ExpandablePanel"
    property bool expanded: false
    property real collapsedHeight: appearance.controlHeight
    property real expandedHeight: appearance.popupHeight
    clip: true
    implicitHeight: expanded ? expandedHeight : collapsedHeight
    Behavior on implicitHeight {
        NumberAnimation { duration: control.reducedMotion || control.suspended ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing }
    }
}
