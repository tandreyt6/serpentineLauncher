import QtQml
import Working.Gui

QtObject {
    id: port
    readonly property QtObject backend: ObjectFactory.windowChromeBridge(port)
    function configure(window) { backend.configure(window) }
    function command(operation) { backend.command(operation) }
    function detach() { backend.detach() }
}
