import QtQuick
import QtQuick.Controls as C
import Qt5Compat.GraphicalEffects
import QtQuick.Templates as T
import Working.Gui

T.Frame {
    id: control
    required property string tag
    property string componentType: "Frame"
    property var collectionContext: ({})
    property url imageSource
    property string imageKey: ""
    property string tooltip: ""
    property string tooltipKey: ""
    property string disabledExplanation: ""
    property int imageFit: Image.PreserveAspectCrop
    property real imageOpacity: 1
    property bool clipContent: false
    property bool selected: false
    readonly property alias appearance: bridge.style
    readonly property alias caption: bridge.text
    readonly property alias visualSource: bridge.visual
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textFromTag: bridge.textFromTag
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    readonly property bool reducedMotion: bridge.reducedMotion
    readonly property bool suspended: !visible || (Window.window && (!Window.window.visible || Window.window.visibility === Window.Minimized))
    padding: appearance.cardPadding
    implicitWidth: contentWidth + leftPadding + rightPadding
    implicitHeight: contentHeight + topPadding + bottomPadding
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: bridge.paintStyle
        readonly property string stateKey: bridge.stateKey
        readonly property url imageSource: control.imageKey.length ? bridge.assetUrl(control.imageKey) : control.imageSource
        readonly property int imageFit: control.imageFit
        readonly property real imageOpacity: control.imageOpacity
        readonly property bool enabled: control.enabled
        readonly property bool selected: control.selected
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    hoverEnabled: true
    C.ToolTip.visible: hovered && (enabled ? tooltip.length > 0 || tooltipKey.length > 0 : disabledExplanation.length > 0)
    C.ToolTip.text: { bridge.localeRevision; return enabled ? tooltipKey.length ? bridge.textFor(tooltipKey) : tooltip : disabledExplanation }
    C.ToolTip.delay: { bridge.settingsRevision; return bridge.setting("ui.tooltip_delay_ms") }
    clip: clipContent
    layer.enabled: Gui.hardwareAcceleration && clipContent && appearance.radius > 0
    layer.textureSize: Qt.size(Math.ceil(width * Screen.devicePixelRatio), Math.ceil(height * Screen.devicePixelRatio))
    layer.smooth: false
    layer.effect: OpacityMask { maskSource: Rectangle { width: control.width; height: control.height; radius: control.appearance.radius } }
    function assetUrl(key) { return bridge.assetUrl(key) }
    Component.onCompleted: bridge.attach(control)
    function saveCollectionState() { return ({}) }
    function restoreCollectionState(values) {}
}
