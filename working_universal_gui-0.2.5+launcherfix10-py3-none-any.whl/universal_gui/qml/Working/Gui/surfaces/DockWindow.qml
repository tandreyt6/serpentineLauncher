import QtQuick
import Working.Gui

DetachableTabs {
    componentType: "DockWindow"
    dockPresentation: true
}
