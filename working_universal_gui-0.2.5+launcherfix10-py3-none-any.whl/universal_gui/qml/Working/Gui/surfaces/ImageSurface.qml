import QtQuick
import Qt5Compat.GraphicalEffects
import Working.Gui

Frame {
    id: control
    componentType: "ImageSurface"
    clipContent: false
    property bool backgroundImageEnabled: true
    property alias body: content.data
    default property alias surfaceContent: content.data
    QtObject {
        id: imageState
        readonly property var style: control.appearance
        readonly property string stateKey: control.stateKey
        readonly property url imageSource: control.backgroundImageEnabled ? control.imageKey.length ? control.assetUrl(control.imageKey) : control.imageSource : ""
        readonly property int imageFit: control.imageFit
        readonly property real imageOpacity: control.imageOpacity
        readonly property bool enabled: control.enabled
        readonly property bool selected: control.selected
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: control.reducedMotion
        readonly property bool suspended: control.suspended
        function assetUrl(key) { return control.assetUrl(key) }
    }
    background: VisualHost { source: control.visualSource; viewState: imageState }
    contentItem: Item { id: content; clip: true; implicitWidth: childrenRect.width; implicitHeight: childrenRect.height }
}
