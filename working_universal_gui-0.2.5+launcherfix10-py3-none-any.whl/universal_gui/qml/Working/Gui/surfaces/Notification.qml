import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    componentType: "Notification"
    property var queue: null
    textFromTag: queue === null
    readonly property var entry: queue ? queue.current : ({})
    property string message: queue ? entry.text === undefined ? "" : entry.text : caption
    property string messageKey: queue && entry.text_key !== undefined ? entry.text_key : ""
    property url iconSource: queue && entry.icon !== undefined ? entry.icon : ""
    property var actions: queue && entry.actions !== undefined ? entry.actions : []
    property int lifetime: queue && entry.lifetime !== undefined && entry.lifetime !== null ? entry.lifetime : setting("notifications.lifetime_ms")
    stateKey: queue && entry.state_key !== undefined ? entry.state_key : ""
    property bool opened: false
    signal dismissed()
    signal actionRequested(string key)
    visible: opened || opacity > 0
    opacity: opened ? 1 : 0
    implicitWidth: appearance.notificationWidth
    function open() { opened = true; if (lifetime > 0) timeout.restart(); else timeout.stop() }
    function close() { if (!opened) return; const key = entry.key; opened = false; timeout.stop(); dismissed(); if (queue && key !== undefined) queue.dismiss(key) }
    onQueueChanged: if (queue && queue.current.key !== undefined) open()
    Connections { target: control.queue; function onCurrentChanged() { if (control.entry.key !== undefined) control.open(); else { control.opened = false; timeout.stop() } } }
    Timer { id: timeout; interval: Math.max(1, control.lifetime); running: control.opened && control.lifetime > 0 && !control.suspended; onTriggered: control.close() }
    contentItem: GridLayout {
        columns: 2
        columnSpacing: control.appearance.spacing
        rowSpacing: control.appearance.spacing
        Icon { tag: control.tag + ".icon"; source: control.iconSource; visible: String(source).length > 0 }
        UiText { tag: control.tag + ".message"; textFromTag: false; displayText: control.message; textKey: control.messageKey; useDisplayText: !control.messageKey.length; Layout.fillWidth: true }
        GridLayout {
        Layout.column: 0
        Layout.columnSpan: 2
        Layout.fillWidth: true
        visible: control.actions.length > 0
        columns: Math.max(1, Math.floor((width + columnSpacing) / (control.appearance.controlWidth + columnSpacing)))
        columnSpacing: control.appearance.spacing
        rowSpacing: control.appearance.spacing
        Repeater {
            model: control.actions
            delegate: ToolButton { required property var modelData; tag: control.tag + ".action"; displayText: modelData.text === undefined ? "" : modelData.text; textKey: modelData.text_key === undefined ? "" : modelData.text_key; useDisplayText: !textKey.length; iconSource: modelData.icon === undefined ? "" : modelData.icon; stateKey: modelData.state_key === undefined ? "" : modelData.state_key; enabled: modelData.enabled !== false; Layout.fillWidth: true; Layout.minimumWidth: 0; onActivated: { control.actionRequested(modelData.key); control.close() } }
        }
        }
    }
    Behavior on opacity { NumberAnimation { duration: control.reducedMotion ? 0 : control.appearance.surfaceDuration } }
}
