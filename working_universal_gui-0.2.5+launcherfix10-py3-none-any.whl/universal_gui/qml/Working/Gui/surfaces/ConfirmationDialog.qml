import QtQuick
import QtQuick.Layouts
import Working.Gui

PopupPanel {
    id: control
    componentType: "ConfirmationDialog"
    property string heading: ""
    property string message: ""
    property string detail: ""
    property var actions: []
    property string defaultAction: ""
    property string cancelAction: ""
    property string acknowledgementPolicy: "close"
    property string pendingAction: ""
    property bool awaitingAcknowledgement: false
    property var focusReturnItem: null
    property var previousFocus: null
    property alias detailsContent: detailHost.data
    signal confirmationRequested(string key)
    signal actionRequested(string key)
    signal cancelled()
    modal: true
    readonly property real ownerWidth: parent ? parent.width : appearance.popupWidth
    readonly property real ownerHeight: parent ? parent.height : appearance.popupHeight
    width: Math.min(appearance.confirmationWidth, Math.max(0, ownerWidth))
    height: Math.min(body.implicitHeight + topPadding + bottomPadding, Math.max(0, ownerHeight))
    x: Math.max(0, (ownerWidth - width) / 2)
    y: Math.max(0, (ownerHeight - height) / 2)
    onAboutToShow: previousFocus = focusReturnItem ? focusReturnItem : parent && parent.Window.window ? parent.Window.window.activeFocusItem : null
    onOpened: {
        for (let i = 0; i < buttons.count; ++i) {
            const button = buttons.itemAt(i)
            if (button && button.enabled && button.modelData.key === defaultAction) { button.forceActiveFocus(); return }
        }
        contentItem.forceActiveFocus()
    }
    function choose(key) {
        if (pendingAction.length || awaitingAcknowledgement) return
        const action = actionAtKey(key)
        if (!action || action.enabled === false) return
        if (key === cancelAction) { close(); return }
        pendingAction = key
        if (acknowledgementPolicy === "wait") { awaitingAcknowledgement = true; confirmationRequested(key) }
        else close()
    }
    function actionAt(index) { return actions.get ? actions.get(index) : actions[index] }
    function actionAtKey(key) { const count = actions.count !== undefined ? actions.count : actions.length; for (let i = 0; i < count; ++i) { const action = actionAt(i); if (action.key === key) return action } return null }
    function acknowledge(success) {
        if (!awaitingAcknowledgement) return
        awaitingAcknowledgement = false
        if (success) close()
        else pendingAction = ""
    }
    onClosed: {
        const action = awaitingAcknowledgement ? "" : pendingAction
        pendingAction = ""
        awaitingAcknowledgement = false
        if (action.length) actionRequested(action)
        else cancelled()
        if (previousFocus) previousFocus.forceActiveFocus()
    }
    contentItem: ScrollArea {
        tag: control.tag + ".viewport"
        implicitHeight: body.implicitHeight
        ColumnLayout {
        id: body
        width: parent.width
        spacing: control.appearance.spacing
        Keys.onReturnPressed: if (control.defaultAction.length) control.choose(control.defaultAction)
        UiText { tag: control.tag + ".heading"; displayText: control.heading; typographyRole: "heading"; visible: control.heading.length > 0; Layout.fillWidth: true }
        UiText { tag: control.tag + ".message"; displayText: control.message; visible: control.message.length > 0; Layout.fillWidth: true }
        UiText { tag: control.tag + ".detail"; displayText: control.detail; typographyRole: "caption"; visible: control.detail.length > 0; Layout.fillWidth: true }
        Item { id: detailHost; Layout.fillWidth: true; implicitHeight: childrenRect.height; visible: children.length > 0 }
        GridLayout {
            Layout.fillWidth: true
            columns: Math.max(1, Math.floor((width + columnSpacing) / (control.appearance.controlWidth + columnSpacing)))
            columnSpacing: control.appearance.spacing
            rowSpacing: control.appearance.spacing
            Repeater {
                id: buttons
                model: control.actions
                delegate: Button {
                    required property int index
                    property var modelData: { if (control.actions.dataRevision !== undefined) control.actions.dataRevision; return control.actionAt(index) }
                    tag: control.tag + ".action"
                    displayText: modelData.text === undefined ? "" : modelData.text
                    textKey: modelData.text_key === undefined ? "" : modelData.text_key
                    useDisplayText: modelData.text !== undefined && !modelData.text_key
                    stateKey: modelData.state_key === undefined ? "" : modelData.state_key
                    enabled: modelData.enabled !== false && !control.awaitingAcknowledgement
                    iconSource: modelData.icon === undefined ? "" : modelData.icon
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    onActivated: control.choose(modelData.key)
                }
            }
        }
        }
    }
}
