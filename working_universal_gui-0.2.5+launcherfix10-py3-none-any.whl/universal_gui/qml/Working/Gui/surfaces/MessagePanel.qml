import QtQuick
import QtQuick.Layouts
import Working.Gui

Widget {
    id: control
    componentType: "MessagePanel"
    property var issues: []
    signal actionRequested(string issue, string action)
    signal copyRequested(string text)
    implicitWidth: appearance.notificationWidth
    implicitHeight: appearance.messagePanelHeight
    function issueAt(index) { return issues.get ? issues.get(index) : issues[index] }
    LocalStateStore { id: expansion; capacity: control.setting("collection.state_entries") }
    contentItem: ListWidget {
        tag: control.tag + ".issues"
        model: control.issues
        delegate: Frame {
            id: row
            required property int index
            property var modelData: { if (control.issues.dataRevision !== undefined) control.issues.dataRevision; return control.issueAt(index) }
            property string issueKey: ""
            property bool expanded: false
            tag: control.tag + ".issue"
            width: ListView.view.width
            stateKey: modelData.state_key === undefined ? "" : modelData.state_key
            onModelDataChanged: {
                if (issueKey === modelData.key) return
                if (issueKey.length) expansion.save(issueKey, {expanded: expanded})
                issueKey = modelData.key
                expanded = expansion.load(issueKey).expanded === true
            }
            ListView.onPooled: expansion.save(issueKey, {expanded: expanded})
            contentItem: ColumnLayout {
                Button { tag: row.tag + ".title"; displayText: row.modelData.title; Layout.fillWidth: true; onActivated: row.expanded = !row.expanded }
                UiText { tag: row.tag + ".reason"; displayText: row.modelData.reason; visible: row.expanded; Layout.fillWidth: true }
                UiText { tag: row.tag + ".context"; displayText: row.modelData.context; visible: row.expanded; typographyRole: "caption"; Layout.fillWidth: true }
                GridLayout {
                    Layout.fillWidth: true
                    columns: Math.max(1, Math.floor((width + columnSpacing) / (control.appearance.controlWidth + columnSpacing)))
                    columnSpacing: control.appearance.spacing
                    rowSpacing: control.appearance.spacing
                    visible: row.expanded
                    ToolButton { tag: row.tag + ".copy"; textKey: "framework.messages.copy"; Layout.fillWidth: true; Layout.minimumWidth: 0; onActivated: control.copyRequested(row.modelData.title + "\n" + row.modelData.reason + "\n" + row.modelData.context) }
                    Repeater { model: row.modelData.actions; delegate: ToolButton { required property var modelData; tag: row.tag + ".action." + modelData.key; displayText: modelData.text === undefined ? "" : modelData.text; textKey: modelData.text_key === undefined ? "" : modelData.text_key; useDisplayText: !textKey.length; enabled: modelData.enabled !== false; stateKey: modelData.state_key === undefined ? "" : modelData.state_key; iconSource: modelData.icon === undefined ? "" : modelData.icon; disabledExplanation: modelData.explanation === undefined ? "" : modelData.explanation; Layout.fillWidth: true; Layout.minimumWidth: 0; onActivated: control.actionRequested(row.modelData.key, modelData.key) } }
                }
            }
        }
    }
}
