import QtQuick
import QtQuick.Layouts
import Working.Gui

ImageSurface {
    id: control
    textFromTag: true
    componentType: "Card"
    property string key: ""
    property string imageLayout: "inline"
    property string titlePlacement: "above-image"
    property real imageHeight: appearance.cardImageHeight
    property real imageWidth: availableWidth
    property int imageAlignment: appearance.cardImageAlignment
    property Component imageContent
    property string overflowPolicy: "shrink-image"
    property real contentSpacing: appearance.spacing
    readonly property bool hasInlineImage: imageLayout === "inline" && (imageContent !== null || String(imageSource).length > 0 || imageKey.length > 0)
    readonly property real minimumContentWidth: Math.max(Math.min(captionHost.implicitWidth, appearance.cardMinimumTextWidth), slotWidth(header), slotWidth(badgeHost), slotWidth(bodyHost), slotWidth(actionHost))
    property real headerMinimumHeight: slotHeight(header)
    property real badgesMinimumHeight: slotHeight(badgeHost)
    property real bodyMinimumHeight: slotHeight(bodyHost)
    property real actionsMinimumHeight: slotHeight(actionHost)
    readonly property real nonImageHeight: captionHost.implicitHeight + headerMinimumHeight + badgesMinimumHeight + bodyMinimumHeight + actionsMinimumHeight
    readonly property int visibleRows: 1 + (hasInlineImage ? 1 : 0) + (header.visible ? 1 : 0) + (badgeHost.visible ? 1 : 0) + (bodyHost.visible ? 1 : 0) + (actionHost.visible ? 1 : 0)
    readonly property real minimumContentHeight: nonImageHeight + Math.max(0, visibleRows - 1) * contentSpacing
    readonly property real minimumWidth: minimumContentWidth + leftPadding + rightPadding
    readonly property real minimumHeight: minimumContentHeight + topPadding + bottomPadding
    readonly property real requiredHeight: minimumHeight + (hasInlineImage ? imageHeight : 0)
    readonly property bool layoutOverflow: availableWidth < minimumContentWidth || availableHeight < minimumContentHeight
    readonly property real effectiveImageHeight: overflowPolicy === "shrink-image" ? Math.min(imageHeight, Math.max(0, availableHeight - minimumContentHeight)) : imageHeight
    function slotHeight(host) { let size = 0; for (const child of host.children) if (child.visible) size = Math.max(size, child.implicitHeight); return size }
    function slotWidth(host) { let size = 0; for (const child of host.children) if (child.visible) size = Math.max(size, child.implicitWidth); return size }
    backgroundImageEnabled: imageLayout === "background"
    property string subtitle: ""
    property alias headerContent: header.data
    property alias badges: badgeHost.data
    property alias actions: actionHost.data
    property alias cardBody: bodyHost.data
    default property alias cardContent: bodyHost.data
    signal selectedRequested(string key)
    signal activated(string key)
    signal contextRequested(string key, real x, real y)
    implicitWidth: appearance.cardWidth
    implicitHeight: Math.max(appearance.cardHeight, requiredHeight)
    contentItem: GridLayout {
        clip: true
        columns: 1
        rowSpacing: control.contentSpacing
        columnSpacing: 0
        ColumnLayout {
            id: captionHost
            Layout.row: control.titlePlacement === "below-image" ? 1 : 0
            Layout.fillWidth: true
            spacing: control.appearance.headingGap
            UiText { tag: control.tag + ".title"; displayText: control.caption; stateKey: control.stateKey; density: control.density; Layout.fillWidth: true; elide: Text.ElideRight; maximumLineCount: 1 }
            UiText { tag: control.tag + ".subtitle"; displayText: control.subtitle; stateKey: control.stateKey; density: control.density; visible: control.subtitle.length > 0; typographyRole: "caption"; Layout.fillWidth: true; elide: Text.ElideRight; maximumLineCount: 1 }
        }
        Loader {
            Layout.row: control.titlePlacement === "below-image" ? 0 : 1
            Layout.preferredWidth: Math.min(control.availableWidth, control.imageWidth)
            Layout.maximumWidth: Math.max(0, control.imageWidth)
            Layout.minimumWidth: 0
            Layout.preferredHeight: control.effectiveImageHeight
            Layout.maximumHeight: Math.max(0, control.effectiveImageHeight)
            Layout.minimumHeight: 0
            Layout.alignment: control.imageAlignment
            active: control.hasInlineImage
            visible: active
            sourceComponent: control.imageContent ? control.imageContent : imagePresentation
        }
        Item { id: header; Layout.row: 2; Layout.fillWidth: true; Layout.minimumHeight: implicitHeight; visible: children.length > 0; implicitHeight: control.headerMinimumHeight }
        Item { id: badgeHost; Layout.row: 3; Layout.fillWidth: true; Layout.minimumHeight: implicitHeight; visible: children.length > 0; implicitHeight: control.badgesMinimumHeight }
        Item { id: bodyHost; Layout.row: 4; Layout.fillWidth: true; Layout.fillHeight: true; Layout.minimumHeight: implicitHeight; visible: children.length > 0; clip: true; implicitHeight: control.bodyMinimumHeight }
        Item { id: actionHost; Layout.row: 5; Layout.fillWidth: true; Layout.minimumHeight: implicitHeight; visible: children.length > 0; implicitHeight: control.actionsMinimumHeight }
    }
    Component {
        id: imagePresentation
        ImageSurface { tag: control.tag + ".image"; stateKey: control.stateKey; density: control.density; displayText: ""; imageSource: control.imageSource; imageKey: control.imageKey; imageFit: control.imageFit; imageOpacity: control.imageOpacity; padding: 0 }
    }
    TapHandler { acceptedButtons: Qt.LeftButton; gesturePolicy: TapHandler.ReleaseWithinBounds; onTapped: control.selectedRequested(control.key); onDoubleTapped: control.activated(control.key) }
    TapHandler { acceptedButtons: Qt.RightButton; onTapped: control.contextRequested(control.key, point.position.x, point.position.y) }
}
