import QtQuick
import QtQuick.Controls as C
import QtQuick.Templates as T
import Working.Gui

T.Popup {
    id: control
    required property string tag
    property string componentType: "PopupPanel"
    property real cornerRadius: appearance.radius
    property bool scaleTransition: true
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    width: appearance.popupWidth
    height: appearance.popupHeight
    padding: appearance.cardPadding
    focus: true
    closePolicy: T.Popup.CloseOnEscape | T.Popup.CloseOnPressOutside
    C.Overlay.modal: Rectangle { color: control.appearance.overlayColor }
    ComponentBridge { id: bridge; componentType: control.componentType; tag: control.tag; textFromTag: false }
    QtObject {
        id: visualState
        readonly property var style: Object.assign({}, bridge.paintStyle, {radius: control.cornerRadius})
        readonly property string stateKey: bridge.stateKey
        readonly property bool enabled: control.enabled
        readonly property bool focused: control.activeFocus
        readonly property bool reducedMotion: bridge.reducedMotion
        readonly property bool suspended: !control.visible
        function assetUrl(key) { return bridge.assetUrl(key) }
    }
    background: VisualHost { source: bridge.visual; viewState: visualState }
    enter: Transition {
        ParallelAnimation {
            id: enterMotion
            NumberAnimation { property: "opacity"; from: control.appearance.surfaceOpacity; to: 1; duration: bridge.reducedMotion ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing }
            NumberAnimation { property: "scale"; from: control.scaleTransition ? control.appearance.surfaceScale : 1; to: 1; duration: bridge.reducedMotion || !control.scaleTransition ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing }
        }
    }
    exit: Transition {
        ParallelAnimation {
            id: exitMotion
            NumberAnimation { property: "opacity"; to: control.appearance.surfaceOpacity; duration: bridge.reducedMotion ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing }
            NumberAnimation { property: "scale"; to: control.scaleTransition ? control.appearance.surfaceScale : 1; duration: bridge.reducedMotion || !control.scaleTransition ? 0 : control.appearance.surfaceDuration; easing.type: control.appearance.motionEasing }
        }
    }
    Connections {
        target: bridge
        function onOptionsChanged() { if (bridge.reducedMotion) { if (enterMotion.running) enterMotion.complete(); if (exitMotion.running) exitMotion.complete() } }
    }
    Component.onCompleted: bridge.attach(control)
}
