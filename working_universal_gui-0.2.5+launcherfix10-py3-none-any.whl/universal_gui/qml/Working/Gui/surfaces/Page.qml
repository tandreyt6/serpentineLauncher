import QtQuick
import Working.Gui

Item {
    id: page
    property var pageContext: typeof TabContext === "undefined" ? null : TabContext
    required property string tag
    readonly property alias appearance: bridge.style
    readonly property alias instanceToken: bridge.token
    property alias stateKey: bridge.stateKey
    property alias density: bridge.density
    property alias typographyRole: bridge.typographyRole
    property alias textKey: bridge.textKey
    property alias displayText: bridge.displayText
    property alias useDisplayText: bridge.useDisplayText
    ComponentBridge { id: bridge; componentType: "Page"; tag: page.tag; textFromTag: false }
    Component.onCompleted: bridge.attach(page)
}
