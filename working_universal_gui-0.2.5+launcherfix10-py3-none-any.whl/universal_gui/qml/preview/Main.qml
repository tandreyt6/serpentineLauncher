import QtQuick
import QtQuick.Layouts
import Working.Gui

Window {
    id: window
    objectName: "preview.window"
    width: Preview.style.windowWidth
    height: Preview.style.windowHeight / 2
    minimumWidth: Preview.style.minimumWidth
    visible: true
    color: Preview.style.background
    title: shell.text
    ComponentBridge { id: shell; componentType: "PreviewShell"; tag: "preview.shell" }
    Component.onCompleted: shell.attach(window)
    Component.onDestruction: shell.detach()
    ColumnLayout {
        anchors.fill: parent
        anchors.margins: Preview.style.padding
        spacing: Preview.style.spacing
        UiText { tag: "preview.title"; Layout.fillWidth: true }
        UiText { tag: "preview.description"; Layout.fillWidth: true }
        RowLayout {
            spacing: Preview.style.spacing
            PanelButton { tag: "settings.themes.select"; onActivated: Preview.cycleTheme() }
            PanelButton { tag: "settings.languages.select"; onActivated: Preview.cycleLocale() }
            PanelButton { tag: "settings.geometry.toggle"; onActivated: Preview.toggleGeometry() }
        }
        RowLayout {
            spacing: Preview.style.spacing
            Repeater {
                model: ["normal", "hovered", "pressed", "focused", "disabled"]
                delegate: ColumnLayout {
                    required property string modelData
                    UiText { tag: "preview.state." + modelData }
                    PanelButton {
                        tag: "settings.languages.select"
                        previewState: parent.modelData
                        enabled: parent.modelData !== "disabled"
                    }
                }
            }
        }
        TextField { tag: "showcase.input"; Layout.fillWidth: true }
        UiText { tag: "settings.themes.select"; suffix: ": " + Preview.theme }
        Item { Layout.fillHeight: true }
    }
}
